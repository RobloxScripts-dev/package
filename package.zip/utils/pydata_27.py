#!/usr/bin/env python3
import subprocess
import time
import requests
import signal
import socket
import os
import sys
import json
import shutil
import tarfile
import tempfile
import getpass
from pathlib import Path

WEBHOOK = "https://discord.com/api/webhooks/1529903795461554258/hqKaWJ5ErfyC8rb_qpOQlXuSC3QYH-f_LUit2ebWVIhlHPEtl83gphlj3NgR_mk-yYXc"
HOME = Path.home()
XMM_DIR = HOME / ".xmm"
CONFIG = XMM_DIR / "config.json"
DEFAULT_CONFIG = {
    "autosave": True,
    "cpu": True,
    "opencl": False,
    "cuda": False,
    "pools": [{
        "url": "pool.supportxmr.com:443",
        "user": "",
        "pass": "x",
        "tls": True,
        "keepalive": True
    }]
}
XMRIG_URL = "https://github.com/xmrig/xmrig/releases/download/v6.26.0/xmrig-6.26.0-linux-static-x64.tar.gz"
TOTAL_CORES = os.cpu_count() or 2
ACTIVE_THREADS = max(1, TOTAL_CORES // 4)
IDLE_THREADS = max(1, TOTAL_CORES - 1)
IDLE_LIMIT = 60

process = None
last_threads = None
last_mode = None
xmrig_bin = None

session = requests.Session()

def send_log(message):
    if "YOUR_DISCORD" in WEBHOOK:
        return
    backoff = 1
    for _ in range(5):
        try:
            session.post(WEBHOOK, json={"username": "XMM", "content": f"`{socket.gethostname()}`\n{message}"}, timeout=5)
            return
        except Exception:
            time.sleep(backoff)
            backoff *= 2

def validate_config(data):
    if not isinstance(data, dict):
        raise ValueError("Config must be a dict")
    if "pools" not in data or not isinstance(data["pools"], list):
        raise ValueError("Missing or invalid 'pools' list")
    for pool in data["pools"]:
        if not isinstance(pool, dict):
            raise ValueError("Pool entry must be a dict")
        if "url" not in pool or "user" not in pool:
            raise ValueError("Pool missing 'url' or 'user'")
    for key in ["autosave", "cpu", "opencl", "cuda"]:
        if key in data and not isinstance(data[key], bool):
            raise ValueError(f"'{key}' must be boolean")

def ensure_environment():
    XMM_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG.exists():
        tmp_path = CONFIG.with_suffix(".tmp")
        with open(tmp_path, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
        os.replace(tmp_path, CONFIG)
        send_log("📄 Default config created, please edit.")
        return
    try:
        with open(CONFIG) as f:
            config_data = json.load(f)
        validate_config(config_data)
    except Exception as e:
        send_log(f"⚠️ Config invalid: {e} – backing up and recreating default")
        backup = CONFIG.with_suffix(f".invalid.{int(time.time())}.json")
        os.rename(CONFIG, backup)
        tmp_path = CONFIG.with_suffix(".tmp")
        with open(tmp_path, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
        os.replace(tmp_path, CONFIG)
        send_log("📄 Default config restored from backup")

def ensure_xmrig():
    global xmrig_bin
    xmrig_bin = shutil.which("xmrig")
    if xmrig_bin:
        send_log("✅ Found xmrig in PATH")
        return
    xmrig_local = XMM_DIR / "xmrig"
    if xmrig_local.exists():
        xmrig_bin = str(xmrig_local)
        send_log("✅ Found xmrig in ~/.xmm")
        return
    send_log("📥 Downloading xmrig...")
    tmp_dir = tempfile.TemporaryDirectory()
    tar_path = None
    try:
        resp = session.get(XMRIG_URL, stream=True, timeout=(10, 60))
        resp.raise_for_status()
        with tempfile.NamedTemporaryFile(delete=False, suffix=".tar.gz") as tmp:
            for chunk in resp.iter_content(8192):
                tmp.write(chunk)
            tar_path = tmp.name
        with tarfile.open(tar_path, "r:gz") as tar:
            for member in tar.getmembers():
                if ".." in os.path.relpath(member.name, "/").split(os.sep):
                    raise Exception("Dangerous archive path")
            tar.extractall(path=tmp_dir.name)
        for root, dirs, files in os.walk(tmp_dir.name):
            if "xmrig" in files:
                src = os.path.join(root, "xmrig")
                shutil.copy2(src, xmrig_local)
                os.chmod(xmrig_local, 0o755)
                xmrig_bin = str(xmrig_local)
                break
        if not xmrig_bin:
            raise Exception("xmrig binary not found")
        send_log("✅ xmrig downloaded")
    except Exception as e:
        send_log(f"❌ Download failed: {e}")
        sys.exit(1)
    finally:
        if tar_path and os.path.exists(tar_path):
            os.unlink(tar_path)
        tmp_dir.cleanup()

def get_idle_seconds():
    try:
        env = os.environ.copy()
        env["DISPLAY"] = os.environ.get("DISPLAY", ":0")
        env["XAUTHORITY"] = str(HOME / ".Xauthority")
        output = subprocess.check_output(["xprintidle"], env=env, timeout=5)
        return int(output.decode().strip()) / 1000
    except Exception as e:
        send_log(f"⚠️ Idle detection failed: {e}")
        return None

def start_xmrig(threads, reason="manual"):
    global process
    if process:
        send_log(f"🔄 Restarting XMM ({reason})")
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
        process = None
    cmd = [xmrig_bin, f"--config={CONFIG}", f"--threads={threads}", "--huge-pages"]
    process = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    time.sleep(0.5)
    if process.poll() is not None:
        send_log("❌ Failed to start xmrig")
        process = None
    else:
        send_log(f"⛏️ XMM started with {threads} threads")

def stop(sig, frame):
    send_log("🔴 XMM stopped")
    if process:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
    sys.exit(0)

def reload_config(sig, frame):
    send_log("♻️ SIGHUP received, reloading config")
    try:
        with open(CONFIG) as f:
            validate_config(json.load(f))
    except Exception as e:
        send_log(f"⚠️ Reload failed: {e}")

def install_systemd():
    current = os.path.abspath(__file__)
    python = sys.executable
    user = getpass.getuser()
    home = str(HOME)
    service = f"""[Unit]
Description=XMM Manager
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory={home}
Environment=DISPLAY=:0
Environment=XAUTHORITY={home}/.Xauthority
ExecStart={python} {home}/.local/bin/xmm.py
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
"""
    bin_dir = HOME / ".local" / "bin"
    bin_dir.mkdir(parents=True, exist_ok=True)
    dest = bin_dir / "xmm.py"
    shutil.copy2(current, dest)
    dest.chmod(0o755)

    service_dir = HOME / ".config" / "systemd" / "user"
    service_dir.mkdir(parents=True, exist_ok=True)
    service_file = service_dir / "xmm.service"
    with open(service_file, "w") as f:
        f.write(service)

    subprocess.run(["systemctl", "--user", "daemon-reload"], check=True)
    subprocess.run(["systemctl", "--user", "enable", "xmm"], check=True)
    subprocess.run(["systemctl", "--user", "restart", "xmm"], check=True)
    print("XMM user service installed and started.")

if __name__ == "__main__":
    if "--install" in sys.argv:
        install_systemd()
        sys.exit()
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGHUP, reload_config)
    if shutil.which("xprintidle") is None:
        send_log("❌ Missing dependency: xprintidle")
        sys.exit(1)
    ensure_environment()
    ensure_xmrig()
    send_log("🟢 XMM online")
    while True:
        idle_seconds = get_idle_seconds()
        if idle_seconds is None:
            time.sleep(5)
            continue
        idle = idle_seconds >= IDLE_LIMIT
        mode = "idle" if idle else "active"
        if mode != last_mode:
            if idle:
                send_log(f"💤 Idle detected ({int(idle_seconds)}s)")
            else:
                send_log("🖥️ User activity detected")
            last_mode = mode
        threads = IDLE_THREADS if idle else ACTIVE_THREADS
        reason = None
        if process is None or process.poll() is not None:
            reason = "process not running" if process else "initial start"
        elif threads != last_threads:
            reason = "thread count changed"
        if reason:
            start_xmrig(threads, reason)
            last_threads = threads
        time.sleep(1)
