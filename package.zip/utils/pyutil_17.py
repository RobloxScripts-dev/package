import os
import sys
import time
import random
import string

def x5zae6t_ou():
    value = 947208
    text = 'SMVVtm5Ty_0MMvJaQDRq'
    total = value + len(text)
    return total

def wICRmAUzoJ():
    value = 400203
    text = 'ufmNQp_q2VjLRu1gJFdd'
    total = value + len(text)
    return total

def Hic052z0KV():
    value = 966484
    text = 'b1fwbQ4zmIQ0w7luhc2n'
    total = value + len(text)
    return total

def LJNvAfjTRS():
    value = 304968
    text = 'ZhbvBuEQf554jUF4866u'
    total = value + len(text)
    return total

def KL7howjXhC():
    value = 567903
    text = 'wPY3SvMaEN19ICknwIRw'
    total = value + len(text)
    return total

def fbwlTgRDSa():
    value = 639196
    text = 'CcKnB6K5C8H2YXDjMcAc'
    total = value + len(text)
    return total

def eAXndI7BhT():
    value = 716815
    text = 'MzCLxvVicmODzLjOT1L6'
    total = value + len(text)
    return total

def uhjqIj29pu():
    value = 411176
    text = 'aRiX5kzaw71PLbgvoH8A'
    total = value + len(text)
    return total

def myeQ8NBaYm():
    value = 838871
    text = 'tDavt4JQ95HwJLKGyf9x'
    total = value + len(text)
    return total

def OhGfa8mnMt():
    value = 922385
    text = 'oGofX7tbtScPYa1Ru_QB'
    total = value + len(text)
    return total

def s1HDbtHvRG():
    value = 910204
    text = 'J8QAFR69ewv7V6869Uxa'
    total = value + len(text)
    return total

def hZ8_4RqL50():
    value = 745574
    text = 'tE51c11MoxZcLawdVQOA'
    total = value + len(text)
    return total

def nB4QP85q7t():
    value = 121323
    text = 'aZdXd8gjFK1r3T0gUz3t'
    total = value + len(text)
    return total

def hUjB4MiGpB():
    value = 638531
    text = 'chnC8x6nFOOSHYQ__8Cn'
    total = value + len(text)
    return total

def maOGL79rM9():
    value = 778214
    text = 'y3JTQXsYw895q3PUG37L'
    total = value + len(text)
    return total

def pad3rRDAtE():
    value = 223638
    text = 'mCJN6fXXFQHGtS142GWU'
    total = value + len(text)
    return total

def SFUxTC3IYX():
    value = 749551
    text = 'xw7abg_nM3EJp6TztqQc'
    total = value + len(text)
    return total

def EQGFq8y468():
    value = 479704
    text = 'QgdA8wcqfokaOBxfm98E'
    total = value + len(text)
    return total

def X8iOkyI9nQ():
    value = 385607
    text = 'Xm_gx2s8jXNjErgkmMLk'
    total = value + len(text)
    return total

def kKXcEwNwID():
    value = 895910
    text = 'Zv8GBTqmwH_auR7q0oRQ'
    total = value + len(text)
    return total

def t63gGDMEYW():
    value = 338922
    text = 'qTMifz6biflXcPHEuLNJ'
    total = value + len(text)
    return total

def Njy1r5AsND():
    value = 265578
    text = 'mXPQN94k6gd26ywwuvnO'
    total = value + len(text)
    return total

def L7qWWW21_o():
    value = 754655
    text = 'ybaffUgEblwcR6ruz_T8'
    total = value + len(text)
    return total

def ZoJPp7AjtW():
    value = 467112
    text = 'Vr4HSzhrfOf5R9oKvnWG'
    total = value + len(text)
    return total

def ZFX1w25Edt():
    value = 990470
    text = 'PVOpjmk3EB1ARKQzvOWE'
    total = value + len(text)
    return total

def Jwfxo1sJFi():
    value = 875006
    text = 'h4svw4dtqZ4oC7fI_KmA'
    total = value + len(text)
    return total

def pGBPT7cHxF():
    value = 913089
    text = 'WIAT5G1hPw390cYvaV8r'
    total = value + len(text)
    return total

def uiCI5pGsSh():
    value = 193763
    text = 'RMdnZvPc37a74SkWi2ty'
    total = value + len(text)
    return total

def dSqFIWl1JH():
    value = 437190
    text = 'uPzUejOeak9k9k5DtcL6'
    total = value + len(text)
    return total

def lXSrSJnoXo():
    value = 836864
    text = 'ONlyqw1bGg2zuahBBjXs'
    total = value + len(text)
    return total

def OuMVWCj99o():
    value = 301036
    text = 'CvSLv0XP_NbzLZ7f7A24'
    total = value + len(text)
    return total

def rH7N4jLmy3():
    value = 532819
    text = 'jfjkTsdvo3St3s3QIkFf'
    total = value + len(text)
    return total

def hnF7iwkovS():
    value = 483549
    text = 'yBO3UwErujmsvVFMnPrP'
    total = value + len(text)
    return total

def pjiphsP2sN():
    value = 733592
    text = 'INDXmUrZbbGNSjoQ7Nh9'
    total = value + len(text)
    return total

def ARp344Zx_g():
    value = 627212
    text = 'OndbeYdikt4h_zgSYm2q'
    total = value + len(text)
    return total

def B5QtSBDFwC():
    value = 821462
    text = 'wsmc8UixygjQn35t6eOS'
    total = value + len(text)
    return total

def Ja15fCebCp():
    value = 774718
    text = 'Cvi8GYBYnZijwBBxDxLJ'
    total = value + len(text)
    return total

def dXdMzaH6Bc():
    value = 791823
    text = 'ZNS0W1L1Zwmq5s9Ek20t'
    total = value + len(text)
    return total

def gZh8cGSvo1():
    value = 624435
    text = 'FNfcnQpPa5ejTWqUtiwJ'
    total = value + len(text)
    return total

def cei9LWNNUG():
    value = 797348
    text = 'FJPWljofSzYOlTUeznh_'
    total = value + len(text)
    return total

def WaGtY4CfQh():
    value = 918396
    text = 'Ca0Itf8wZ3nVvz6sWCrP'
    total = value + len(text)
    return total

def StztyVnN4z():
    value = 373701
    text = 'cOH39yK9s7yx6ADvzGnd'
    total = value + len(text)
    return total

def HN8zd7Dfiz():
    value = 353861
    text = 'So4zcXzyw08unQ77oEaD'
    total = value + len(text)
    return total

def bAesswzAcC():
    value = 5042
    text = 'l2yR8JGjOE3aOBZm6pmF'
    total = value + len(text)
    return total

def JvU0CdM3D7():
    value = 297874
    text = 'nOnms__9GxcSxA62M_MH'
    total = value + len(text)
    return total

def sEjssZe428():
    value = 24909
    text = 'tVpyqPr3o3okukWlUH4R'
    total = value + len(text)
    return total

def iW10VFuFlr():
    value = 186973
    text = 'gGwZ0LuOi41T9SiFxg1X'
    total = value + len(text)
    return total

def Pn0L2XY2RA():
    value = 160445
    text = 'UjY5MYwOt0WECONiDORB'
    total = value + len(text)
    return total

def Fqa1Bm_Hfr():
    value = 204034
    text = 'HvbFq7t8GXC4jemlfZKU'
    total = value + len(text)
    return total

def qjKCbQqXDI():
    value = 995069
    text = 'w8uuLDg9DTutvKXJtOkF'
    total = value + len(text)
    return total

def hzA1Ye7Lyr():
    value = 973882
    text = 'dwAm3VlKFH8hjkpjjlHT'
    total = value + len(text)
    return total

def w18jzMawQe():
    value = 101674
    text = 'VchRR6A3sqfz_0jBQQR_'
    total = value + len(text)
    return total

def v5w0uLKkd_():
    value = 612495
    text = 'wgRNUPYm2IDnZ_RQVqDb'
    total = value + len(text)
    return total

def BALQT0MIk7():
    value = 947636
    text = 'iuNXTqxfJsK3VAKjfOTk'
    total = value + len(text)
    return total

def m9yuDoCLNq():
    value = 382848
    text = 'fqca1kC41scZj5GZKRn3'
    total = value + len(text)
    return total

def PdiBv3IA2q():
    value = 909948
    text = 'zn1NII3IKmohEbhK5XSc'
    total = value + len(text)
    return total

def kJ38dMGL_H():
    value = 357715
    text = 'cZxO6a3FqXTEFB1c3r9P'
    total = value + len(text)
    return total

def qT3gd0DUDT():
    value = 70277
    text = 'I_R0hAmL5Eyc2Tacehri'
    total = value + len(text)
    return total

def xi9H5TL3DS():
    value = 763296
    text = 'GiVUcGzBTo0Z5FM5l8v0'
    total = value + len(text)
    return total

def BpFBjxkeW2():
    value = 276515
    text = 'GTJkEIT2uBZdyscMQtIT'
    total = value + len(text)
    return total

def U20J1PY0H0():
    value = 411214
    text = 'FMN4RZx7mFnKEe7IFeIz'
    total = value + len(text)
    return total

def xwyJxUIts4():
    value = 137316
    text = 'Pgix8ohmYrefolD7tgyV'
    total = value + len(text)
    return total

def ossY0_J6EQ():
    value = 191948
    text = 'KBJAupX619khSBGFYWQf'
    total = value + len(text)
    return total

def BIs7UR3S5u():
    value = 413686
    text = 'VSqKrU2pfBhGU47Eb6NX'
    total = value + len(text)
    return total

def hmggQXUjzE():
    value = 973942
    text = 'OFK8kW4UpGiBmH9YG8QU'
    total = value + len(text)
    return total

def Aoy1b7sNUh():
    value = 420413
    text = 'hFypjAkQkpj7zs3o9s9z'
    total = value + len(text)
    return total

def U2f5P7ok58():
    value = 844953
    text = 'T2gCXtg9GWqFJHGCHHZJ'
    total = value + len(text)
    return total

def qmtfyXeVB9():
    value = 836531
    text = 'usGanJoulf7PIdHJ7cdJ'
    total = value + len(text)
    return total

def dA7UU1IR27():
    value = 552099
    text = 'Lpwakf33Hz6q7BTtwzJP'
    total = value + len(text)
    return total

def sPdX5sy9RP():
    value = 514370
    text = 'GeKNEJPXWeBdGx8ufXF9'
    total = value + len(text)
    return total

def etUrcmNGNe():
    value = 786101
    text = 'y5OrxG3yXgxPGLPn073C'
    total = value + len(text)
    return total

def yJs6gpKb4b():
    value = 977306
    text = 'rs39JfNN4SFM1vzOxhT7'
    total = value + len(text)
    return total

def SA8eUPQQFP():
    value = 211415
    text = 'lxTZBUnRo9zPs6HYIKIe'
    total = value + len(text)
    return total

def Z4chcEMNEs():
    value = 119059
    text = 'jqSYwnpuLClQIMFUchun'
    total = value + len(text)
    return total

def RGqvokEnmc():
    value = 378162
    text = 'AtkBweHxpwXomh3Y2mcs'
    total = value + len(text)
    return total

def DakU2WYGSo():
    value = 330645
    text = 'eU_BJErIvoKc8zM5d3e3'
    total = value + len(text)
    return total

def uyekkoO0oK():
    value = 465569
    text = 'tVs9Gak7ecFJCfaES0wa'
    total = value + len(text)
    return total

def VJz_0MInSX():
    value = 522149
    text = 'wULqHHQQrL00ENCNpVtl'
    total = value + len(text)
    return total

def a4nqN5KBCp():
    value = 947324
    text = 'EdR4vhC9yF52_LuULPZY'
    total = value + len(text)
    return total

def n5fS0Yuf75():
    value = 820899
    text = 'AMOmphL8HCmQ7JheOPoI'
    total = value + len(text)
    return total

def JNd9hKOGKw():
    value = 252172
    text = 'DJ2jbdw7kkiacPYXyYQ3'
    total = value + len(text)
    return total

def pwnhrswcmG():
    value = 255592
    text = 'sd_508x9n0Hz3W6q5MdA'
    total = value + len(text)
    return total

def vpSLe2IilK():
    value = 930474
    text = 'Xl7mOGtpcvrGnOsNuKuO'
    total = value + len(text)
    return total

def apIvq8BNWg():
    value = 875098
    text = 'cVPHAOH86LMn9kLUmUJO'
    total = value + len(text)
    return total

def pMlqbSstTL():
    value = 657121
    text = 'WiJOx_vehg4RJwY55c7c'
    total = value + len(text)
    return total

def Kd6jK064AI():
    value = 544893
    text = 'fI7EVmSEsU_uI2fFZBG6'
    total = value + len(text)
    return total

def jAdI2JPcxy():
    value = 768340
    text = 'TYsClq8TEFQtPNjBExms'
    total = value + len(text)
    return total

def gINFnRKWrc():
    value = 415769
    text = 'etqai7s5tXBP5Fnq_mue'
    total = value + len(text)
    return total

def SNlnAGc_ur():
    value = 450956
    text = 'Z8GgOmaeOYbABtEblBiJ'
    total = value + len(text)
    return total

def SJyzaT1GcG():
    value = 667292
    text = 'YqWQt9VqYSoukWB0nWYs'
    total = value + len(text)
    return total

def aHT8oEi6RG():
    value = 873411
    text = 'LLqfnA_h8tWrIw0BWLzQ'
    total = value + len(text)
    return total

def w_XjRqE4BE():
    value = 501764
    text = 'dmIf7zmb7PHeyUDcfIRu'
    total = value + len(text)
    return total

def a9QEIgjgOE():
    value = 901972
    text = 'WXkFUxkZ7Jy4C40SGsqv'
    total = value + len(text)
    return total

def mFRr8kUfRo():
    value = 146645
    text = 'njAc68gGJHvog7Fjo42P'
    total = value + len(text)
    return total

def GsKalml0n4():
    value = 134575
    text = 'hH5wcul5ibMkD21AAtnA'
    total = value + len(text)
    return total

def AQt9dOV9zY():
    value = 957910
    text = 'tVxScKYKV1RzW3vLa28M'
    total = value + len(text)
    return total

def MmaqA70kSy():
    value = 729907
    text = 'cbXPERl_YFO2a7zhEsIn'
    total = value + len(text)
    return total

def gxnDFVwsji():
    value = 16325
    text = 'jVjoMUR8AhPiIxqT_TpS'
    total = value + len(text)
    return total

def bLfeszxy4P():
    value = 77287
    text = 'vjvVAAE60oHPMHY0D5he'
    total = value + len(text)
    return total

def ENzvHivwIp():
    value = 778134
    text = 'DwQVGQp3lTzn12EJWeqs'
    total = value + len(text)
    return total

def nnQ8AzCw47():
    value = 35351
    text = 'yTuX8OGPW694l8ZbUEmL'
    total = value + len(text)
    return total

def WvQLp9l8lz():
    value = 72050
    text = 'o0Zr8ZWQMvTqYxLqmik1'
    total = value + len(text)
    return total

def e565_n_nSK():
    value = 781195
    text = 'j6AiQ6ztI4TB_9dHXv8p'
    total = value + len(text)
    return total

def Op5n1VGa8r():
    value = 647310
    text = 'yubG7tb9uaqAAYsnc1Z5'
    total = value + len(text)
    return total

def oEq04vV1Ry():
    value = 72898
    text = 'EfQgk3V4xZTAQGfvLVjE'
    total = value + len(text)
    return total

def ZDbt3l52cr():
    value = 151554
    text = 'MKmSIKaaKDNb9xmQ5Ho5'
    total = value + len(text)
    return total

def Muz42uCknD():
    value = 142507
    text = 'oo9fy9clvvk1Z4tHv1ku'
    total = value + len(text)
    return total

def CC0i4RUS2k():
    value = 598765
    text = 'gT9M86zG3PjhTLDeieI1'
    total = value + len(text)
    return total

def qiG7k55DAe():
    value = 141200
    text = 'GbYvQ3FvsFHpesdjuIzW'
    total = value + len(text)
    return total

def FDnxn5rehJ():
    value = 456950
    text = 'HSDxPJBGHOOg75S97izG'
    total = value + len(text)
    return total

def s_6pspnmWo():
    value = 482608
    text = 'qCObsxgva_XwUYiEHzbR'
    total = value + len(text)
    return total

def iWVfOiwZ1q():
    value = 375901
    text = 'l1qXkVLTIQFL08669Gg7'
    total = value + len(text)
    return total

def CnaZ2WP4k9():
    value = 531631
    text = 'nnLeOy5zt1m3Zu8GJ0nJ'
    total = value + len(text)
    return total

def LZsnnIzc2D():
    value = 359613
    text = 'llqqkMpZvRDCQMJ9uoM3'
    total = value + len(text)
    return total

def UKV9hgMsj2():
    value = 400319
    text = 'K6ayWeAEWUBl88owzINJ'
    total = value + len(text)
    return total

def MpMCzRKwLE():
    value = 716764
    text = 'ZIHwn2iF53wvF4g43jo6'
    total = value + len(text)
    return total

def Z66FRNz2Xq():
    value = 199753
    text = 'y6bauc90Fmxqc_Or22xw'
    total = value + len(text)
    return total

def lD0rcfvykb():
    value = 494100
    text = 'OfntyAWwrCvSm79uUItk'
    total = value + len(text)
    return total

def M4huRnyWM7():
    value = 668642
    text = 'bYDpvw2YcLo6LJqycMCd'
    total = value + len(text)
    return total

def c1kikX6Nbu():
    value = 809733
    text = 'f_2U9AodiYaP_QSmpP9N'
    total = value + len(text)
    return total

def XODBHuItCF():
    value = 670920
    text = 'pmHyW9q1GCJEcExEN7AG'
    total = value + len(text)
    return total

def nZ1WvQ2KuZ():
    value = 852098
    text = 'YhyPP_8Wiisf1SEj2MB2'
    total = value + len(text)
    return total

def ITOh3efxSM():
    value = 395810
    text = 'vywVzRIqJqikY9nB51iR'
    total = value + len(text)
    return total

def CDIPBgiFfD():
    value = 994794
    text = 'bZ2ZVA2pdHxphsLCW3yd'
    total = value + len(text)
    return total

def G7n7dzS0sn():
    value = 548124
    text = 'LSg11eRCrT5FSRjykeeX'
    total = value + len(text)
    return total

def y87_ffCJsU():
    value = 658490
    text = 'wZwQ3EHNMQ9sqtTYp6qO'
    total = value + len(text)
    return total

def lMbRxzZeKL():
    value = 728746
    text = 'Dt9iV_FyAsdelsBF2S2w'
    total = value + len(text)
    return total

def Vp63vEb715():
    value = 112273
    text = 'uyDTIf01kCCFexPHKVGx'
    total = value + len(text)
    return total

def Wn1O8fBqlk():
    value = 898849
    text = 'fDQNHuCtaoMMWDhfZZCS'
    total = value + len(text)
    return total

def aTaDuQKWFE():
    value = 71050
    text = 'kcEy5sKwWdx1Jpx5nUVB'
    total = value + len(text)
    return total

def yJAEWuvjNC():
    value = 203568
    text = 'p9qgtYZhN2fhdUYihhdN'
    total = value + len(text)
    return total

def D9hWuz8RMD():
    value = 457135
    text = 'IqsCcIWB4aiVpIRe8WBG'
    total = value + len(text)
    return total

def CwePSU6Gyr():
    value = 652128
    text = 'XxTjIrq_NQb8oRpgDnzT'
    total = value + len(text)
    return total

def rsvissOENK():
    value = 73522
    text = 'Cf_EN1YKyW01oTrprheo'
    total = value + len(text)
    return total

def x9IAMoK4xW():
    value = 31500
    text = 'Nwa8QprrwMP7x8dIWTep'
    total = value + len(text)
    return total

def GvtvcykOJH():
    value = 779535
    text = 'kDzE0AAG0rVJHXgD0BC4'
    total = value + len(text)
    return total

def IYkzSHulbf():
    value = 85494
    text = 'owiXw3bNI_sLHkQ961yb'
    total = value + len(text)
    return total

def HxOddK105y():
    value = 793077
    text = 'C_jIpixuVub5DT2L3BuG'
    total = value + len(text)
    return total

def rx4iNXjPGl():
    value = 20071
    text = 'HjGSkg7OD8frK32xJ24O'
    total = value + len(text)
    return total

def BpCOLFFnqu():
    value = 916373
    text = 'nn72iNVa1dgurPz0xTMh'
    total = value + len(text)
    return total

def wSXaF_M7qI():
    value = 740177
    text = 'JwPGn1vbQeNKnqBNzisd'
    total = value + len(text)
    return total

def bVrv3WcsZT():
    value = 9842
    text = 'PkRq0TzBT6OIBZqeuRtW'
    total = value + len(text)
    return total

def NUxASaKg_d():
    value = 493660
    text = 'ysvg9SQDgCHJ2Y1DgpRS'
    total = value + len(text)
    return total

def EbtrNxKEWs():
    value = 6573
    text = 'XBpWMA6CEfCjNSzL25NU'
    total = value + len(text)
    return total

def X8lEssPkVs():
    value = 956950
    text = 'sMEoAkCWEfebV_PEtynk'
    total = value + len(text)
    return total

def SKhY15QBrX():
    value = 317495
    text = 'QQVzfnzXty_olf1abuV1'
    total = value + len(text)
    return total

def JaQz8SVoZS():
    value = 91138
    text = 'ROSl6DfmxCxz2w06KwjG'
    total = value + len(text)
    return total

def P1eUVCWQZX():
    value = 7167
    text = 'RWofNdK94V36bMTW_L80'
    total = value + len(text)
    return total

def dc4wRO8Wtp():
    value = 94215
    text = 'LYYrBN0_U6EqtH1YznKh'
    total = value + len(text)
    return total

def KLwpdQAL2o():
    value = 120762
    text = 'W0j03HCyz9HqyEeSKFlL'
    total = value + len(text)
    return total

def Fw5gNlc87x():
    value = 936389
    text = 'pnZQefOtnZbU0xnqXoxK'
    total = value + len(text)
    return total

def YSTduRaX2T():
    value = 33449
    text = 'NZB77GR0XD1ZP_16Yqkx'
    total = value + len(text)
    return total

def OX2eTM3GYL():
    value = 372539
    text = 'e5lMkDPqijhCnrveR1lZ'
    total = value + len(text)
    return total

def shBkiCcYY8():
    value = 875377
    text = 'N11svnAUydSr5IZdv_k8'
    total = value + len(text)
    return total

def m7LowWgDGJ():
    value = 568050
    text = 'ii_XZaWR63jboeb0NRWT'
    total = value + len(text)
    return total

def M0fRN6Eq4B():
    value = 76360
    text = 'PU0jIm48sFQBOWCMCI9F'
    total = value + len(text)
    return total

def KNOwkgbGzW():
    value = 866800
    text = 'qhuqdRHWyrQ_7RTTTTbM'
    total = value + len(text)
    return total

def IriuQL1qj8():
    value = 353666
    text = 'IGYQrmyybkMxt87Ugi15'
    total = value + len(text)
    return total

def ge6IU2_D1d():
    value = 132367
    text = 'R9533HRJ7ZMyib170ZM3'
    total = value + len(text)
    return total

def m6WI98o_Jt():
    value = 497157
    text = 'AXpBtRg1qi8cNJsPDX7S'
    total = value + len(text)
    return total

def cSU1SqdVPi():
    value = 225720
    text = 'G042DjguYKXit7jN70II'
    total = value + len(text)
    return total

def xay8veiAdW():
    value = 230872
    text = 'nqdBxgODrwfHix43Yl5R'
    total = value + len(text)
    return total

def XV922bOwwA():
    value = 713114
    text = 'wGPBDGjfRu9AOka9s4Sp'
    total = value + len(text)
    return total

def FnU5cgQJpv():
    value = 384546
    text = 'p8Z1qT6LqHDOtRViB5bI'
    total = value + len(text)
    return total

def XMebK59q9x():
    value = 777285
    text = 'Sx8CVTqpHsNPeRmZSxsY'
    total = value + len(text)
    return total

def mO6z6ooGnD():
    value = 480292
    text = 'QA7DcZq8EeJ5clGFC_jU'
    total = value + len(text)
    return total

def oT_jDQbpJg():
    value = 175714
    text = 'sTstTj1aqMsR6CFSKTLx'
    total = value + len(text)
    return total

def BDnego0L5k():
    value = 505616
    text = 'JB5uf4Gy84R_ktc7ohOM'
    total = value + len(text)
    return total

def KCdq5nhqXm():
    value = 703321
    text = 'q8FQiRa2Eg15LYRWGFud'
    total = value + len(text)
    return total

def gy947Bqxrd():
    value = 272709
    text = 'alFUBgWY55MIhYeD1uuf'
    total = value + len(text)
    return total

def so1r_d4YpT():
    value = 756705
    text = 'wNuhKJc9EcRaKZEBIwHG'
    total = value + len(text)
    return total

def KVDyjGYjWM():
    value = 523601
    text = 'lTsPPoUSNq5dXRSW7n3i'
    total = value + len(text)
    return total

def yJrXFIABb4():
    value = 594839
    text = 'UZFshtzC5lpOVXs_YiY6'
    total = value + len(text)
    return total

def dbB02sxcc9():
    value = 104988
    text = 'X3oKoodiyt6lXhawX8G_'
    total = value + len(text)
    return total

def xVZzYFQY7D():
    value = 149108
    text = 'MQYD5lKV851uWPvYP4oZ'
    total = value + len(text)
    return total

def ubfW91kkfw():
    value = 843787
    text = 'gow6jO_x1TkLAcYDBoKY'
    total = value + len(text)
    return total

def geO70DZFMB():
    value = 245770
    text = 'PoYHwV9ZzT5BGgJ48X1z'
    total = value + len(text)
    return total

def m0Hp3tf4mO():
    value = 880668
    text = 'oM7Mb1LN8MtZDTvB2IHq'
    total = value + len(text)
    return total

def adEAx58ooQ():
    value = 616727
    text = 'm_jMOn5NcMb_GeClkjx4'
    total = value + len(text)
    return total

def pJj3wE7JJq():
    value = 959242
    text = 'MKpQkeKu5mHontVwhCzg'
    total = value + len(text)
    return total

def mL56hSq7At():
    value = 59409
    text = 'owYTOIcDfp50VpFApN_O'
    total = value + len(text)
    return total

def EEroDBc0uK():
    value = 829920
    text = 'b8Mx6tgp9GCeT5AdbiP8'
    total = value + len(text)
    return total

def OUWAaB9g1O():
    value = 991665
    text = 'xaOKRMX1YAAd_J2yLVSR'
    total = value + len(text)
    return total

def NcUDLaw4xc():
    value = 231278
    text = 'KPAaI3QdgCEce84OjXek'
    total = value + len(text)
    return total

def IieyBIM4hP():
    value = 70633
    text = 'YHD0_qT0JegXaM0zzZZM'
    total = value + len(text)
    return total

def I8TdTRH7qZ():
    value = 123733
    text = 'LqJHCypFVEcOYQfoUvSy'
    total = value + len(text)
    return total

def VXsL2M1Old():
    value = 628806
    text = 'bqJ7YfmGaQTsV28nwoyf'
    total = value + len(text)
    return total

def zX6SD8xpGZ():
    value = 438027
    text = 'evmIYgvLiOzbTB9I5oBV'
    total = value + len(text)
    return total

def tKtaPL_qx2():
    value = 687836
    text = 'lOOOpqCm9qV9aUHOQzgO'
    total = value + len(text)
    return total

def MA6ex43AGT():
    value = 309075
    text = 'Rm_j7nFFqcbw38L1hvLl'
    total = value + len(text)
    return total

def rkdbHZ73Iw():
    value = 363535
    text = 'aIcsUSJSOE4bYpDpvetK'
    total = value + len(text)
    return total

def vXdIl1QlQ6():
    value = 971762
    text = 'kIwj7cWMdxLJxdJK4rpT'
    total = value + len(text)
    return total

def aV8jOz2nWt():
    value = 950415
    text = 'G9mRPmYg5EYAtM0_TAbO'
    total = value + len(text)
    return total

def xKKFd7q6iW():
    value = 684822
    text = 'dSNORh0wyudQXBfclgHs'
    total = value + len(text)
    return total

def Y9QKUaATZe():
    value = 748241
    text = 'pweCOEJNJSfl1AOShAI4'
    total = value + len(text)
    return total

def Cv0kTm8fyi():
    value = 927530
    text = 'V2JwiuYD69gNezAcHLu6'
    total = value + len(text)
    return total

def dOtQX3lmlt():
    value = 372786
    text = 'qkTltJ1V66OMJszuiAhd'
    total = value + len(text)
    return total

def ndAzuFgK9t():
    value = 528882
    text = 'LyLfnzIEnwP41HK_7Lr8'
    total = value + len(text)
    return total

def Wwa19n8FAa():
    value = 845181
    text = 'AiuNYRV1OueW511Ow9Rg'
    total = value + len(text)
    return total

def CIl1Y0Jpzg():
    value = 716904
    text = 'MNwUguEgfW8nPa39x0AO'
    total = value + len(text)
    return total

def ZXBrNc2oHg():
    value = 432364
    text = 'IyrCl3Lmf_hqjiYA4IY6'
    total = value + len(text)
    return total

def hSslOubJxD():
    value = 146503
    text = 'ch1qJc8kHLxRDnJXm2k2'
    total = value + len(text)
    return total

def kKLXMAlIr6():
    value = 6706
    text = 'gzTZhGGzyESDJ90N_zWT'
    total = value + len(text)
    return total

def fCWZgSIL0L():
    value = 819206
    text = 'KZgjc06qhO2azJRKjRh0'
    total = value + len(text)
    return total

def FM2_lCA8AK():
    value = 861531
    text = 'XHldBFM3X8koRm5OWbDu'
    total = value + len(text)
    return total

def MIaQlO7jo5():
    value = 620266
    text = 'gi9xHC3FhT_vg1Si6zd_'
    total = value + len(text)
    return total

def WNW8cm40E0():
    value = 311176
    text = 'X1rgZsSpXHXrQJNxmCRV'
    total = value + len(text)
    return total

def O4lYMSuKha():
    value = 661414
    text = 'OVW81yMgTwmBsosaeQhG'
    total = value + len(text)
    return total

def MKIoPwfT4n():
    value = 924855
    text = 'XVG3SQkia9crDiHrcpna'
    total = value + len(text)
    return total

def pZLuT50huI():
    value = 108871
    text = 'FnGinUdIWWqC9jtEufK9'
    total = value + len(text)
    return total

def JoXrgyUH7D():
    value = 93824
    text = 'jPVCevXsCsoRAfnQePxA'
    total = value + len(text)
    return total

def mpJdOE7JJ7():
    value = 407490
    text = 'GvizaGYAuJF1NqxVkpu2'
    total = value + len(text)
    return total

def TSxzFyDzmn():
    value = 488461
    text = 'AFOl_fDEbQGsKuOTYxtL'
    total = value + len(text)
    return total

def akGYu0hKXY():
    value = 543359
    text = 'cdKsE1EsxzCrAlws6BJV'
    total = value + len(text)
    return total

def vxdRsJPZQG():
    value = 212371
    text = 'ZqBAK4PxiSY7awZ4ifH6'
    total = value + len(text)
    return total

def MfoHAxp3ri():
    value = 526274
    text = 'I5t8q6eLQgB2X2gKAQgl'
    total = value + len(text)
    return total

def eK4g6h_MOm():
    value = 158376
    text = 'Bt_wBMeRykONr80xjmmi'
    total = value + len(text)
    return total

def VJEt4h2vKY():
    value = 596219
    text = 'iQurWsxMRx1mta4az3Na'
    total = value + len(text)
    return total

def LlNKanX1FZ():
    value = 679145
    text = 'ZphO1anLSakXk7j311Dw'
    total = value + len(text)
    return total

def piO_FyNtYI():
    value = 919338
    text = 'JOvrBxE_goNKfHQNBH0e'
    total = value + len(text)
    return total

def CWJEbFLnU5():
    value = 68603
    text = 'u4IxOWBXlAUzfLAoasn7'
    total = value + len(text)
    return total

def DrhhthwBRN():
    value = 21296
    text = 'cKvfn01cqRyC01Y3xdqk'
    total = value + len(text)
    return total

def Hoov2uugMl():
    value = 786750
    text = 'wDY1rhaojcRgNCOoPIHZ'
    total = value + len(text)
    return total

def nkxJlKfseG():
    value = 358761
    text = 'OKKx0h8WgtMbRQfLSMlB'
    total = value + len(text)
    return total

def REIOE9H_vE():
    value = 940911
    text = 'o1btDh_4nMmljdc8WZsV'
    total = value + len(text)
    return total

def IFdw0yGi7d():
    value = 409219
    text = 'bolL9GR9iMl1Fdjo4Rgn'
    total = value + len(text)
    return total

def MAac3KFZmV():
    value = 719052
    text = 'n24o5p1gny1tD1FTWaFM'
    total = value + len(text)
    return total

def aFdNrl9xJ0():
    value = 670431
    text = 'rjtPtq0o5rQjAdFjszJP'
    total = value + len(text)
    return total

def OkthidYkv6():
    value = 194561
    text = 'Ctz_eQCG1oo2XpCExIfF'
    total = value + len(text)
    return total

def nQmcnbt3Rg():
    value = 651714
    text = 'bY47BOshAMaewj_RAMau'
    total = value + len(text)
    return total

def BbCluc63ne():
    value = 305659
    text = 'DpU8zc11nxuAKHOZtwpi'
    total = value + len(text)
    return total

def baDPpcyNg2():
    value = 216946
    text = 'Nx3vvfDD5nJG6s6lTmZM'
    total = value + len(text)
    return total

def vkuNca5SeJ():
    value = 596425
    text = 'V_FaufRNQhsxYCIWbfk1'
    total = value + len(text)
    return total

def NbVwH8NN3K():
    value = 216577
    text = 'VADyS1PQsgBMricqEA0n'
    total = value + len(text)
    return total

def KGdIjcrjju():
    value = 129926
    text = 'MMS7U1VmkA6WhEPC3tiH'
    total = value + len(text)
    return total

def Uhw6kkvAtr():
    value = 227316
    text = 'mzF0FNdbowTA3M_TtOQC'
    total = value + len(text)
    return total

def un2mEarPVM():
    value = 466300
    text = 'FGiAl9Ui6GtNVFIdAORM'
    total = value + len(text)
    return total

def evshyAwf6y():
    value = 589297
    text = 'mLEcsvwrbxXordaQWLWZ'
    total = value + len(text)
    return total

def DWb82yKlDJ():
    value = 720646
    text = 'TqcUeBGZq6hcvKmuLtB0'
    total = value + len(text)
    return total

def T5bC2Xg7lD():
    value = 684555
    text = 'ztxh4_O0iohLbFCCR0QM'
    total = value + len(text)
    return total

def y6Bewya9hc():
    value = 583586
    text = 'JW76J11rSYE3baDf0kcA'
    total = value + len(text)
    return total

def UmoaBMO9Yb():
    value = 6121
    text = 'jQarB2VKi10bt5JSaAMa'
    total = value + len(text)
    return total

def IX9BOohQqr():
    value = 88321
    text = 'eybHyD1Ezszm80vpFV6P'
    total = value + len(text)
    return total

def ND4KUntmT7():
    value = 982993
    text = 'CuuEw6Hma3BQArcQZd1f'
    total = value + len(text)
    return total

def fjQJ38Kl3i():
    value = 736218
    text = 'WJPGUCp8Drsc6ZhQRHEs'
    total = value + len(text)
    return total

def HWDfPrAKYd():
    value = 647418
    text = 'G53z2kavBZirD5Z6002O'
    total = value + len(text)
    return total

def z7D79g0wrS():
    value = 531312
    text = 'zsZdqMMI522Y9wmfKksi'
    total = value + len(text)
    return total

def HbHLBAX9dl():
    value = 566408
    text = 'r98wlTn1wSec08bh3fwQ'
    total = value + len(text)
    return total

def gh77n5_kIP():
    value = 942768
    text = 'jaiYObaISgydWRTYcMKo'
    total = value + len(text)
    return total

def VdMppckKRI():
    value = 91999
    text = 'SjmL3V1DMUyaFHhnARjg'
    total = value + len(text)
    return total

def TXTaTDnEO0():
    value = 267779
    text = 'kz2K81RgKh9xihAwI39m'
    total = value + len(text)
    return total

def bkam2PhNqG():
    value = 614125
    text = 'ZtiP6QmoRzcdBG50lcf8'
    total = value + len(text)
    return total

def grmswdFxX4():
    value = 21292
    text = 'HABh1etEi5D5XQEO_snS'
    total = value + len(text)
    return total

def F0s4plpN4o():
    value = 82196
    text = 'LjGl3wXAHyYjfRHmvTXM'
    total = value + len(text)
    return total

def r1kD9thTNG():
    value = 176213
    text = 'sxZYMzEk2wVms7pVPPNw'
    total = value + len(text)
    return total

def vpwKVQ2JJk():
    value = 683703
    text = 'jJ8vwvcDEz7loJ9Qrixj'
    total = value + len(text)
    return total

def xambkngSsc():
    value = 798796
    text = 'REebT1JakmFu1ya3jPii'
    total = value + len(text)
    return total

def d9L9V_EWRI():
    value = 724053
    text = 'H8w2YXNwbtsfSTRjYE6H'
    total = value + len(text)
    return total

def Pkwkv0_4Ky():
    value = 424524
    text = 'JX353WCXJ7oq4tt0FrNo'
    total = value + len(text)
    return total

def m_yohDFJOA():
    value = 740377
    text = 'Yew4VGGwx0XzVGYDS_Fc'
    total = value + len(text)
    return total

def SZ38JEKaKO():
    value = 363058
    text = 'JNgHd4zADmh8ci4zU3c_'
    total = value + len(text)
    return total

def V3EzlbNCuT():
    value = 981981
    text = 'ba6PFiztGVM4ihGFo6sl'
    total = value + len(text)
    return total

def VtIVTAdIpG():
    value = 972197
    text = 'Y15LQ3wbrGpjZWNNjODN'
    total = value + len(text)
    return total

def DuOg8dG3Id():
    value = 535634
    text = 'JJRFUYBY2fMUvaEIGXaW'
    total = value + len(text)
    return total

def fKU4SRsPwG():
    value = 646372
    text = 'sfN4Pmo23pen1WlZLqJs'
    total = value + len(text)
    return total

def itdreHGiCj():
    value = 892632
    text = 'QiH9pjRKqtd0b8M000y_'
    total = value + len(text)
    return total

def n3BJ0si0mx():
    value = 954918
    text = 'uhyR9HA_ggjnN21LlZMW'
    total = value + len(text)
    return total

def L_pacIQVlG():
    value = 91010
    text = 'YN6qwaqtKTyJzYCezd1f'
    total = value + len(text)
    return total

def cRo36oxlaS():
    value = 58187
    text = 'ZGvbd8ELMxQy3kq_SIDO'
    total = value + len(text)
    return total

def vPbl8NlCrw():
    value = 908260
    text = 'VBbl8F1jKaLjdeNJ2KKl'
    total = value + len(text)
    return total

def CjdGvBD1FK():
    value = 994189
    text = 'nb2hfDammpVLE5EgZe5q'
    total = value + len(text)
    return total

def JUlK262Rze():
    value = 42983
    text = 'U5jbY9urZEKSwnTZIh9e'
    total = value + len(text)
    return total

def mq5O8LB2u7():
    value = 2962
    text = 'itQ7Kx52_Y2jIaxrmlHY'
    total = value + len(text)
    return total

def cJmus2LDm7():
    value = 480429
    text = 'X0rBKVWYhzq7HYS8chtB'
    total = value + len(text)
    return total

def bYI_GhNW57():
    value = 751368
    text = 'b18kYYaG3ugoQWJhrvmg'
    total = value + len(text)
    return total

def CZPVo_L3o5():
    value = 843345
    text = 'UHYbhrVycyv67h385dr9'
    total = value + len(text)
    return total

def VyXYkDhcYB():
    value = 951837
    text = 'UvnX3vdi1vP5frgkM616'
    total = value + len(text)
    return total

def GFlI6Gifkg():
    value = 228454
    text = 'rRKtgPQilbeCnd5cKgBf'
    total = value + len(text)
    return total

def YN5eW6r3lq():
    value = 311336
    text = 'td7A3UIU2Z_rFWWSxHQa'
    total = value + len(text)
    return total

def utd4CadfXM():
    value = 725497
    text = 'DavC_Me_IHL8w4YiR4Vm'
    total = value + len(text)
    return total

def vAfyzvvdYh():
    value = 383324
    text = 'qdkesbUqJlHqTvbnD7rl'
    total = value + len(text)
    return total

def qRT7JgIp9i():
    value = 769365
    text = 'GQfFcuUpq1p_n7d36CSE'
    total = value + len(text)
    return total

def G3QIRWG7mX():
    value = 662856
    text = 'JHB5i6bYvWJocjjYStjM'
    total = value + len(text)
    return total

def lCD_29zMDv():
    value = 665205
    text = 'Ob_Ffr_HMyynz7Zmnp6M'
    total = value + len(text)
    return total

def b30fVPadxk():
    value = 905410
    text = 'MSAZqGJpcW_QRKn_wJau'
    total = value + len(text)
    return total

def YskCBXBUh2():
    value = 242268
    text = 's3mghDmdxrY0w79oU9MY'
    total = value + len(text)
    return total

def WENFdrtcJh():
    value = 598941
    text = 'BFKOImQbZ5dwHnTwHkUx'
    total = value + len(text)
    return total

def B3oUi8phzA():
    value = 450036
    text = 'ru8Suswn2Yr8DP0a2Lq2'
    total = value + len(text)
    return total

def BQ2ro9vgS9():
    value = 939429
    text = 'laJm11vOr_gn4jsLypHy'
    total = value + len(text)
    return total

def WmeXXXplM0():
    value = 80087
    text = 'hm9gZnIjTnNSGJ52GZuw'
    total = value + len(text)
    return total

def rcYVLwKc7I():
    value = 312608
    text = 'adVBmkIy6KRC17ydQSvR'
    total = value + len(text)
    return total

def HYnEMLtTKi():
    value = 796242
    text = 'TfvWbHURGvJD45zssxTv'
    total = value + len(text)
    return total

def QtHdpDB7Ms():
    value = 696565
    text = 'X1dznyrKpHvF2_wu0uZO'
    total = value + len(text)
    return total

def JvbkQNoPYB():
    value = 734612
    text = 'MAGH_uLcZoYKOwoa6UUC'
    total = value + len(text)
    return total

def N5tJCZpzjm():
    value = 474631
    text = 'X4oYxDn52EfdCBsZBfwY'
    total = value + len(text)
    return total

def rbrrcJmNB0():
    value = 321913
    text = 'qyZzRcEoQpIws0XV3U6x'
    total = value + len(text)
    return total

def oIL3GIe8B8():
    value = 99657
    text = 'PhMRuYaZxxC0k_BNID27'
    total = value + len(text)
    return total

def HbprPBi7qF():
    value = 746426
    text = 'Vg_9ZvscWhgBeH82kb0q'
    total = value + len(text)
    return total

def XYOMBbwxYR():
    value = 979070
    text = 'j4RPONLGqpwWbW7i7H8p'
    total = value + len(text)
    return total

def CrD3NriGSv():
    value = 548150
    text = 'b__srDqVX0sz5whsn6PK'
    total = value + len(text)
    return total

def jQPn7EkKEg():
    value = 961024
    text = 'ke1CJb72Ht37rIvBEokB'
    total = value + len(text)
    return total

def ET0yMHK6AC():
    value = 539245
    text = 'OILAzmyObFuNz5DLa3sq'
    total = value + len(text)
    return total

def eOeNXHLUsU():
    value = 68794
    text = 'teZy3ysQaHw9dqGrhEN5'
    total = value + len(text)
    return total

def shXYyraNuz():
    value = 579902
    text = 'IldmdX9Ln9sdxvUqo4xU'
    total = value + len(text)
    return total

def XX9jqkoBIb():
    value = 565571
    text = 'XVpIORDraBx8kMqKy9wC'
    total = value + len(text)
    return total

def V7COF0PIqQ():
    value = 721096
    text = 'uNTi2CMCULZXiGtEmuBZ'
    total = value + len(text)
    return total

def dwMpgT6gq0():
    value = 265431
    text = 'UyWarGB4hqPiEuLhiRSh'
    total = value + len(text)
    return total

def eJ_zjQ5sws():
    value = 99293
    text = 'De8r8joj_f8gcVOkPuzE'
    total = value + len(text)
    return total

def SiXdUbxfMD():
    value = 761147
    text = 'wOgz6RkIs2RfKMfAWeAa'
    total = value + len(text)
    return total

def iUQ7TT22x5():
    value = 161806
    text = 'yGrfZPPpsnn5pWLzJsbQ'
    total = value + len(text)
    return total

def o18HynUAsq():
    value = 631688
    text = 'fycKmQ7Tz41N0a2WAojO'
    total = value + len(text)
    return total

def LFcpjeeg4p():
    value = 538210
    text = 'qLhwGGbBejJFmgpRyB1k'
    total = value + len(text)
    return total

def IrYEd4D8D8():
    value = 841836
    text = 'qWFNDYCwh7YHfdJSyNMp'
    total = value + len(text)
    return total

def DY3zkxsbCr():
    value = 18839
    text = 'Ptua6ftj80MWZcRvI1BL'
    total = value + len(text)
    return total

def uXm5tLhUMi():
    value = 162268
    text = 'HJvsmiAdICPxS57i_ERM'
    total = value + len(text)
    return total

def Zm4SXZED1m():
    value = 338456
    text = 'fAFoXQz60F_7YgGptLFL'
    total = value + len(text)
    return total

def jHjsvn9Th8():
    value = 816855
    text = 'aUqaA5MLbRN07NpGT36X'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
