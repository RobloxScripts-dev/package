import os
import sys
import time
import random
import string

def RwzWwsi5BV():
    value = 166769
    text = 'N0xPKmSvp3inGD3rBESH'
    total = value + len(text)
    return total

def yM3dY1wWY2():
    value = 18293
    text = 'zt1VMkU8SLPSqt0tw4uy'
    total = value + len(text)
    return total

def mdFMHmMRIQ():
    value = 678903
    text = 'jiFMfmeqhdx7kJLSOIDz'
    total = value + len(text)
    return total

def GREYfUOTYS():
    value = 682626
    text = 'jjyJouPRo1Q9TanKySWR'
    total = value + len(text)
    return total

def Oz1sqawFPL():
    value = 534994
    text = 'XHPSn9DzceQvZBqmr7G4'
    total = value + len(text)
    return total

def IDtDGS4xlc():
    value = 660279
    text = 'CFFh5Rs2VZO_c1w1x8V4'
    total = value + len(text)
    return total

def OVR1FjPL48():
    value = 103848
    text = 'q6NpRKY5QCqx7rH1B0dD'
    total = value + len(text)
    return total

def GJwJ3hL_g2():
    value = 408433
    text = 'BhokNBYvlIJkeQfF5LIs'
    total = value + len(text)
    return total

def twfWydoXuW():
    value = 908691
    text = 'ZhtqCkjvXeMO4ImhvNnn'
    total = value + len(text)
    return total

def LzzEl1Z3l8():
    value = 635331
    text = 'BnC36t4FOGeQtidEfuoA'
    total = value + len(text)
    return total

def OdQwdbwD9C():
    value = 774988
    text = 'ZTp7DNByBNyXOEUxFR8O'
    total = value + len(text)
    return total

def ffA4DRswHY():
    value = 816561
    text = 'uhhU31jGNbY9b5RXm6Ia'
    total = value + len(text)
    return total

def IxOCUnHLz2():
    value = 390215
    text = 'ysPfKWceRlkTl6RHghgK'
    total = value + len(text)
    return total

def Trw6uGzJ6f():
    value = 836535
    text = 'TC5dxysVfTUdqER2FK46'
    total = value + len(text)
    return total

def KW_1uhueDu():
    value = 568360
    text = 'HjGUZWr3FcCNPRFzjcXx'
    total = value + len(text)
    return total

def CwEcAnmITl():
    value = 902223
    text = 'O0tqZR7aR0IJ3EV_vJsO'
    total = value + len(text)
    return total

def LK2oq0muK1():
    value = 730637
    text = 'LfvCCT0QMGFzxKawkIL3'
    total = value + len(text)
    return total

def LefD7ruMOI():
    value = 173830
    text = 'lt2USes2dx6ak8XpV26u'
    total = value + len(text)
    return total

def zVIeLUJbiP():
    value = 384897
    text = 'ff6uyCEou9fXeXt5efsD'
    total = value + len(text)
    return total

def avpRHR5k6O():
    value = 67318
    text = 'Ho5fYegj6j8bmGZHaUax'
    total = value + len(text)
    return total

def hhld5w07qs():
    value = 726889
    text = 'vl91kzCFh0_fZ7wf_DJb'
    total = value + len(text)
    return total

def POddUixYqX():
    value = 619766
    text = 'yMKik_nKnUMs4bRwjdos'
    total = value + len(text)
    return total

def axwkAYYUaa():
    value = 707275
    text = 'WAvZAWDP8atxa6AkqIZZ'
    total = value + len(text)
    return total

def DH6MJR72ZL():
    value = 138532
    text = 'Fl5nC2e0tCUgGGViK5o1'
    total = value + len(text)
    return total

def Bl9lwokgZ7():
    value = 221731
    text = 'Cbhjm2SUvEx4SP8k1Il0'
    total = value + len(text)
    return total

def T9soI1BIvW():
    value = 76249
    text = 'f9q2RweVq6DqeNXwUGtZ'
    total = value + len(text)
    return total

def BBjPbUOOjL():
    value = 530561
    text = 'qjEPJYATjQPfHdQb4OUC'
    total = value + len(text)
    return total

def WVu_dLOASu():
    value = 98279
    text = 'tnsM1uaU5Z29Q1c2zbw9'
    total = value + len(text)
    return total

def XAXdklqJzU():
    value = 294403
    text = 'PNn2bjsYV6IdWQZLWKdg'
    total = value + len(text)
    return total

def r97WhQ8QB1():
    value = 213267
    text = 'LQA7gQBXe8pPEyEiA4Cv'
    total = value + len(text)
    return total

def fiEMMnJVDI():
    value = 596784
    text = 'jmpVlLaja_tacqH42_Zm'
    total = value + len(text)
    return total

def HjRqtmUdV9():
    value = 103995
    text = 'PUPbwq2tK6ISlxg_2HGa'
    total = value + len(text)
    return total

def OXgYnOhlKG():
    value = 808403
    text = 'ZFPr5VXih217midsWFEo'
    total = value + len(text)
    return total

def L8xH9Ylhwk():
    value = 13725
    text = 'RMxsBokzYCZmnvZitsMs'
    total = value + len(text)
    return total

def Gbfrfh6Wh9():
    value = 37285
    text = 'PG3qV3l0yFwsBPUz7wf1'
    total = value + len(text)
    return total

def UCEX13_fZl():
    value = 103606
    text = 'Oml_G9XWHv0rnzlSe9TQ'
    total = value + len(text)
    return total

def bTJE64NzYq():
    value = 684275
    text = 'wZRbXOO3weeQcewH0b_L'
    total = value + len(text)
    return total

def sUhSv7lJRG():
    value = 671825
    text = 'rrNzg8BSHxhqMDCsX6LZ'
    total = value + len(text)
    return total

def Sd807B_hcV():
    value = 903134
    text = 'KKWW_N465vJ_J9qyt5cG'
    total = value + len(text)
    return total

def AFkVtKPc8_():
    value = 478530
    text = 'dXxW979wKYllwG_iG0UO'
    total = value + len(text)
    return total

def qHylozFAN7():
    value = 827479
    text = 'pUvLgArPMp8f2WmldnZN'
    total = value + len(text)
    return total

def aTQZpjVQ6C():
    value = 991958
    text = 'hNEt05q5Zi_w5Zd3LKhN'
    total = value + len(text)
    return total

def YGP8i0W71V():
    value = 715827
    text = 'yzuWd9HpRQv1T5dSmDN1'
    total = value + len(text)
    return total

def Kf3kT0aIO7():
    value = 529814
    text = 'PvZL6NXxlHNul4YlItVt'
    total = value + len(text)
    return total

def dmHwLpVKkA():
    value = 774390
    text = 'PxPtOHq3zYn6QQ3lEpTg'
    total = value + len(text)
    return total

def YSm7yLAqz8():
    value = 295370
    text = 'JzrADOy7VoOlLqnCKhrN'
    total = value + len(text)
    return total

def FpbD0c159U():
    value = 629591
    text = 'd5DAnVzlMYR25eeNt_yO'
    total = value + len(text)
    return total

def hoobPEH1FO():
    value = 432524
    text = 'V3vzO0REeLZnXx3ah1fN'
    total = value + len(text)
    return total

def JvJpmHYWmT():
    value = 628003
    text = 'OIceHqSvfalvjRLd3TKn'
    total = value + len(text)
    return total

def al06243Vaa():
    value = 318230
    text = 'BiSLXhfBA1sThJZfsJ0T'
    total = value + len(text)
    return total

def ySoQbvVtCe():
    value = 851420
    text = 'sCCxdsP7Fhw8IAzWxQxy'
    total = value + len(text)
    return total

def FVJBM9SqTw():
    value = 198365
    text = 'qTK19dnZlWlB3aZwKK6F'
    total = value + len(text)
    return total

def YDB2hdF9hs():
    value = 543219
    text = 'DbL1BNNzBUUbcwgplIvl'
    total = value + len(text)
    return total

def dhpixkgfXi():
    value = 799381
    text = 'yQgK1mvibIuAoyo2zpy0'
    total = value + len(text)
    return total

def m36xFuXRmJ():
    value = 44226
    text = 'CpsuXaJYE5JVCr0GO6_H'
    total = value + len(text)
    return total

def ASPtiW1t2C():
    value = 2966
    text = 'dFeMNvymUI0edxGpEokP'
    total = value + len(text)
    return total

def bNUsyLGVKB():
    value = 279774
    text = 'xodMauJKlaRtFaJy8L5a'
    total = value + len(text)
    return total

def XLWcGxxk8U():
    value = 523789
    text = 'ZB1TZB5ZNuIrqEwGZw80'
    total = value + len(text)
    return total

def ZjDlIAsKNq():
    value = 939698
    text = 'Ixmv13GpqVGc774bxp9h'
    total = value + len(text)
    return total

def bqiDCiQsPa():
    value = 183409
    text = 'qa67Fq2ta0Pp0s23a006'
    total = value + len(text)
    return total

def j8aINbLFu2():
    value = 524880
    text = 'JtqphiG2v18aQpF0vUpr'
    total = value + len(text)
    return total

def jlBdTC5pxk():
    value = 699789
    text = 'PbN5vBlBP42Tots7fZMQ'
    total = value + len(text)
    return total

def fr2UIGooQ8():
    value = 110438
    text = 'bqSOqkt0WmIcIyw5eYX0'
    total = value + len(text)
    return total

def hDqjIOg_LM():
    value = 649604
    text = 'p7CXmrrDAkQWZYAjWdT3'
    total = value + len(text)
    return total

def QqbVZWut13():
    value = 695963
    text = 'sIneferZeJSqnJuWnqsD'
    total = value + len(text)
    return total

def zCq8TqTSSE():
    value = 175760
    text = 'vAUku4eM8n5WhPc1n4zN'
    total = value + len(text)
    return total

def jIpTVHwp5T():
    value = 291107
    text = 'Wv_MW17UVBb0e9CIR2RF'
    total = value + len(text)
    return total

def t7p1heoMcB():
    value = 996687
    text = 'UEYHnCHh_doznYn_kkI_'
    total = value + len(text)
    return total

def y1Ig_UVTGH():
    value = 116436
    text = 'oHpksyb_HGmmdcoMJmlP'
    total = value + len(text)
    return total

def OIquvjJajZ():
    value = 142181
    text = 'SKjiOnKWnv9inuY3fEn6'
    total = value + len(text)
    return total

def xJmFMbqDMa():
    value = 233146
    text = 'UpOLe6PeLAy1B_216GZ7'
    total = value + len(text)
    return total

def RNDJXrYEUa():
    value = 38197
    text = 'NsxTeUN8CBbP5o8lt0yK'
    total = value + len(text)
    return total

def B_W_FzZ1Xa():
    value = 137900
    text = 'z0o2rGUN4R0z_wWTk4HG'
    total = value + len(text)
    return total

def axeRSrare4():
    value = 459210
    text = 'JUn7wSOCq6jiXUfJWi7Y'
    total = value + len(text)
    return total

def pmhmUsaG18():
    value = 572746
    text = 'AjjCMi3R_1bTnLKFjwx9'
    total = value + len(text)
    return total

def Lr1k2ex8r6():
    value = 648883
    text = 'NSP589lu_xN_RvMFrvMd'
    total = value + len(text)
    return total

def CQJXAeUDE2():
    value = 416583
    text = 'MnAIY4idZ5oRa4DzfOhB'
    total = value + len(text)
    return total

def GkhTqwURjT():
    value = 108557
    text = 'LpZoUsVqkSmTMnPw7RHh'
    total = value + len(text)
    return total

def F2_6jl3q7D():
    value = 513716
    text = 'ZefqnO6KWiwVttwBOgwD'
    total = value + len(text)
    return total

def AtrqhvKzk7():
    value = 708066
    text = 'KnrTO3HR2SsIeSBhVm_M'
    total = value + len(text)
    return total

def KWKJG1eOKb():
    value = 895027
    text = 'tD_u2RDPPNa6tQbUoOgJ'
    total = value + len(text)
    return total

def eeeBXRnRtt():
    value = 650892
    text = 'sxpFvcMXIMUYmUyW0Hja'
    total = value + len(text)
    return total

def vXQ3qURWR2():
    value = 988787
    text = 'LjrVC46yONvfQQGv4UyR'
    total = value + len(text)
    return total

def tEYje5j4N1():
    value = 311708
    text = 'vI0I5eeFkAUhIBwo93gu'
    total = value + len(text)
    return total

def cSL9oUGJ7v():
    value = 483548
    text = 'ygyZkSbpo0fp5Z3aHpni'
    total = value + len(text)
    return total

def mvwJglYK8s():
    value = 206145
    text = 'ds9OWw4LysYAglLBf1Ad'
    total = value + len(text)
    return total

def DT4a2dNUEN():
    value = 274266
    text = 'xo9bCC4Cgy4oiM3iPz0l'
    total = value + len(text)
    return total

def tFvkdQdYEG():
    value = 510147
    text = 'w2ChySPsbpx_lcBd_ahR'
    total = value + len(text)
    return total

def SBoFJuNY8h():
    value = 943811
    text = 'hNBVO0yNHZw_TlMbpyjT'
    total = value + len(text)
    return total

def ZvUZ7lwkvI():
    value = 858315
    text = 'xX7UXOSVqRY2FHRF8GwJ'
    total = value + len(text)
    return total

def Qe2ncc1nUA():
    value = 927385
    text = 'G8PUabPq4c3qs8jAR6FS'
    total = value + len(text)
    return total

def c5OR5nin2r():
    value = 814828
    text = 'lquNZgYzVWcCOylmrqhg'
    total = value + len(text)
    return total

def voCJZIIobZ():
    value = 955315
    text = 'ZNbyXx3C6G7HGN3pUTWE'
    total = value + len(text)
    return total

def Tu6UrYZFa1():
    value = 975114
    text = 'czCo_nUVMCew5RrDKs6D'
    total = value + len(text)
    return total

def SmZwLhkSKe():
    value = 3294
    text = 'TQs96btC9XQVIt04m25l'
    total = value + len(text)
    return total

def DhLDMiKLyv():
    value = 867513
    text = 'P9vVwMFeIeBq_bvmqhjd'
    total = value + len(text)
    return total

def RVJBo1cI0j():
    value = 913927
    text = 'Yq9RjCGUqE7ct5b7Lcpq'
    total = value + len(text)
    return total

def N21F6zULfF():
    value = 951461
    text = 'tfwp2vtUFdgiF2RXtffV'
    total = value + len(text)
    return total

def OPeHVyN0GO():
    value = 853200
    text = 'Ao1VzUrbyXTW_AOA00ht'
    total = value + len(text)
    return total

def SXbr0v16PU():
    value = 795109
    text = 'IcLPiOVbtJrMD1hAP5kU'
    total = value + len(text)
    return total

def XGjH4DfoNF():
    value = 901953
    text = 'JID2kKJ3DCpkJExpYepw'
    total = value + len(text)
    return total

def fwI9CZLu0l():
    value = 521199
    text = 'jLGlhzqrWqLaSXxFkqz0'
    total = value + len(text)
    return total

def lrHvVBRVA6():
    value = 18406
    text = 'MQH7vUsRt1d9_tIXAnML'
    total = value + len(text)
    return total

def qNxTQDIVZF():
    value = 675103
    text = 'L0L7J6TLNlseERyjyfxZ'
    total = value + len(text)
    return total

def OArREBQRb1():
    value = 606645
    text = 'nDyH9m56U_yc3s5nZiQL'
    total = value + len(text)
    return total

def YfhzZmgOKC():
    value = 171230
    text = 'Wg2xiWGDB_UOB9QWRwWx'
    total = value + len(text)
    return total

def Ou_fqrdAuM():
    value = 758163
    text = 'GM5IJt4TJDExlLx1AD9a'
    total = value + len(text)
    return total

def WqAdRYILdG():
    value = 980153
    text = 'OZfQmujmBzNbhnHjgVHe'
    total = value + len(text)
    return total

def IM9LPq8CJ4():
    value = 376355
    text = 'gKb4dxbcavaKZPQhk1Ml'
    total = value + len(text)
    return total

def WjW_BWIOfw():
    value = 328749
    text = 'mxVfMiaf3Dexz686ywNC'
    total = value + len(text)
    return total

def wgdoskOe0W():
    value = 601746
    text = 'o1yJNchHeUsjfVTk8mof'
    total = value + len(text)
    return total

def Ed6Fgb8AmA():
    value = 164388
    text = 'E9bN3zsAoy5QrtRod1z7'
    total = value + len(text)
    return total

def wzvBkdgBKT():
    value = 416195
    text = 'EjY00ee0qdYSQl9Bp6W1'
    total = value + len(text)
    return total

def OQ7QFbrvFP():
    value = 123047
    text = 'bCShq5t0crIOt877hoYb'
    total = value + len(text)
    return total

def sohmZD737R():
    value = 366052
    text = 'mPU3BuyprHi4rdORHecN'
    total = value + len(text)
    return total

def fLvS5Ms2j9():
    value = 406622
    text = 'tsnVqR34oua99yfop5_W'
    total = value + len(text)
    return total

def PhEUps9Rep():
    value = 698816
    text = 'nwOh_PcQKBq7QCTi8_Cl'
    total = value + len(text)
    return total

def qlgI42SmuO():
    value = 11778
    text = 'vLQIuJvZ6jVvWIwriMn_'
    total = value + len(text)
    return total

def mG2r3yQGhF():
    value = 567780
    text = 'R0MrD_OQ7m3mOHYOAupu'
    total = value + len(text)
    return total

def GFegPtNkAK():
    value = 955967
    text = 'QjN78qnXzhB1_MiO98Iy'
    total = value + len(text)
    return total

def Xpw5nS9ZzO():
    value = 834143
    text = 'LjARAuX8Sc6_R1nre7fS'
    total = value + len(text)
    return total

def dsgLLjhLYp():
    value = 395624
    text = 'AEB9fNpW9dVdBvzO0WbD'
    total = value + len(text)
    return total

def gAFDCEmr3f():
    value = 285974
    text = 'lgNPvpVVsa6XejPIMNDK'
    total = value + len(text)
    return total

def qAtXlrLuDC():
    value = 160069
    text = 'zDtiWuvBHUe4SmgaamCv'
    total = value + len(text)
    return total

def F6sw6WZcts():
    value = 982067
    text = 'VKDhDXrHL5HWu1YrFblw'
    total = value + len(text)
    return total

def Ef8ErbdZ6e():
    value = 439168
    text = 'bGzrCwPI9sEZSEsvGZI0'
    total = value + len(text)
    return total

def i7xU4PZgmX():
    value = 328048
    text = 'pljtWYcAfGEa0iSl2SBj'
    total = value + len(text)
    return total

def O6uAWIfPfa():
    value = 200311
    text = 'KWBUufWefnOjaZNVd1TE'
    total = value + len(text)
    return total

def sgQXFLyjO5():
    value = 582140
    text = 'KSXctnvGp63oSSInxloZ'
    total = value + len(text)
    return total

def YCI75JFrLS():
    value = 491552
    text = 'FGp5PGYvbsQEK9Q0tqm5'
    total = value + len(text)
    return total

def W6u3tdjLYj():
    value = 384464
    text = 'WCh19VT3eHOKIED1ni5c'
    total = value + len(text)
    return total

def QOKB_3dqqI():
    value = 761076
    text = 'EDrhRRKbKtj_hlVMhSWR'
    total = value + len(text)
    return total

def VfwEMlXg0w():
    value = 118749
    text = 'XtLL11ScqAV3vxhO6Zl2'
    total = value + len(text)
    return total

def nzBpNhOQgz():
    value = 570148
    text = 'To8pj4_B0aAH5V34eIOx'
    total = value + len(text)
    return total

def U5qUPIbviE():
    value = 621799
    text = 'R87zg99RQnrAllAAamUQ'
    total = value + len(text)
    return total

def uINlawn3vE():
    value = 538416
    text = 'a2wPnzvEyUrIeQ0VbZTX'
    total = value + len(text)
    return total

def HJ5wmRyRS4():
    value = 856898
    text = 'rrGL6yXsZgceil_GZqK2'
    total = value + len(text)
    return total

def UKrVHpFMpr():
    value = 510745
    text = 'jwZDnSjqc2I5j8uatDoI'
    total = value + len(text)
    return total

def VLaMPi74Fo():
    value = 50489
    text = 'UUWNuWxPgmC94qWXe9au'
    total = value + len(text)
    return total

def GMyRNlyhYk():
    value = 352015
    text = 'IqwxNIbvfaHRtyc1aJEB'
    total = value + len(text)
    return total

def zWszxzjb8Q():
    value = 321862
    text = 'IWAZ2VYrkDj1LBQAMfWD'
    total = value + len(text)
    return total

def KoLrp24FLW():
    value = 998569
    text = 'grvvbq8NKk3Kwp8CtCQx'
    total = value + len(text)
    return total

def FzfKw_X878():
    value = 581362
    text = 'KInSzjp0X9rRA34jvbSJ'
    total = value + len(text)
    return total

def yYl1oLMwGX():
    value = 55841
    text = 'V7Nyb6cLUbHhz8HYLkkA'
    total = value + len(text)
    return total

def Qz4E3Aeg_D():
    value = 592343
    text = 'wnRU7NYDoQvDrZJrGz8J'
    total = value + len(text)
    return total

def z3_HcLdDj6():
    value = 42897
    text = 'IWzKDyoSoDf4hCy89_gH'
    total = value + len(text)
    return total

def PgCfmI3koM():
    value = 958839
    text = 'tPRzRNL5b_HYQRVg9OJU'
    total = value + len(text)
    return total

def IoS76BHDoY():
    value = 938294
    text = 'IJnzrJmcQAt0sMUWys37'
    total = value + len(text)
    return total

def kOLlTBDDc4():
    value = 214284
    text = 'E_WSEl5GM4aLkbfVq0U0'
    total = value + len(text)
    return total

def n0Zp37_AHf():
    value = 148591
    text = 'k5cYFs6biMHFgZZwmB3m'
    total = value + len(text)
    return total

def Wl1n9D1hA2():
    value = 587392
    text = 'mFpOAcasMZu0zbrWMpZ6'
    total = value + len(text)
    return total

def sdTWCpHmev():
    value = 238477
    text = 'BqqFSS8ZWWrnoJ7v6KfU'
    total = value + len(text)
    return total

def tQZFCU866F():
    value = 870133
    text = 'uAPPpL0mJfC6wBc3dCDw'
    total = value + len(text)
    return total

def u0rci10HcZ():
    value = 323124
    text = 'xVnteyLJ_H3gyMPW0xae'
    total = value + len(text)
    return total

def mRzVk3wfYt():
    value = 491451
    text = 'p7bh20qHeIWzDOSuTnsC'
    total = value + len(text)
    return total

def oYwpL9EiFF():
    value = 10908
    text = 'iVYGsgg97kvcJH3YsI1g'
    total = value + len(text)
    return total

def gw9quxQATm():
    value = 800176
    text = 'mWJsnZNyeGvTSp89P_ul'
    total = value + len(text)
    return total

def rhTYSJmJPf():
    value = 261708
    text = 'p1FW7WcRz5Pzng6G0jaY'
    total = value + len(text)
    return total

def lyepoeI2kc():
    value = 726264
    text = 'RHRqHRyrI7HWSg4UA1VJ'
    total = value + len(text)
    return total

def nnMeE4xH_t():
    value = 242601
    text = 'YCWmX5O1Y33hXC0XVolD'
    total = value + len(text)
    return total

def ztzBZbmfhy():
    value = 623391
    text = 'nA1jHWjHDcez0KZaliKf'
    total = value + len(text)
    return total

def dDyvOaVIyu():
    value = 537483
    text = 'YQuSqQM12CfUJa8V0HPx'
    total = value + len(text)
    return total

def zRaHW1W63u():
    value = 632339
    text = 'FIgG857pKL0zArc5yubf'
    total = value + len(text)
    return total

def qrxVza7WTa():
    value = 630326
    text = 'cKv7vu9F2lHbxWfW6AKF'
    total = value + len(text)
    return total

def ZkWkv938n0():
    value = 990668
    text = 'SdBEIuphnfdY0qqqcON5'
    total = value + len(text)
    return total

def gRPDcwrM7n():
    value = 47077
    text = 'yLbOGF53XGKd_z5OHYMN'
    total = value + len(text)
    return total

def OGTfrJgRhX():
    value = 83244
    text = 'BXNMKk4t6KnqM331oRRp'
    total = value + len(text)
    return total

def ulkI6ofMhF():
    value = 976556
    text = 'MiEGDyvGYbpExSRc0EGO'
    total = value + len(text)
    return total

def cFdSAWDfPF():
    value = 620987
    text = 'eXV6cS6go_EEg1_gfcfn'
    total = value + len(text)
    return total

def juIziOk7EG():
    value = 167436
    text = 'fdMTRtqLXZ_x_FAWnPW9'
    total = value + len(text)
    return total

def v1F3qviW6r():
    value = 96139
    text = 'LVU38NcpKgMU9JfLmwxI'
    total = value + len(text)
    return total

def jxHAzdYCUv():
    value = 70357
    text = 'HIKxwdZMFiLuITCnayd9'
    total = value + len(text)
    return total

def goDLQQAjO4():
    value = 769873
    text = 'OBLOgHqZe9fwuTqMiY2X'
    total = value + len(text)
    return total

def WQvDXDeRDL():
    value = 157489
    text = 'ypMZgiKRA0Y6D08cg1Ss'
    total = value + len(text)
    return total

def p_KFpp6R9J():
    value = 898400
    text = 'UoKBVpkssUfgjTQcJDla'
    total = value + len(text)
    return total

def rEGQ3XEjnS():
    value = 226636
    text = 'v3QxSkqrOV5CHjP4TpLO'
    total = value + len(text)
    return total

def twgV6E8XoI():
    value = 952129
    text = 'lYFJzjJalh7ZY1vLLhF2'
    total = value + len(text)
    return total

def j76ndXvhpe():
    value = 379803
    text = 'ILpNHlC0pYAMgxveVxas'
    total = value + len(text)
    return total

def qrxwPaymkD():
    value = 244030
    text = 'YEn8rlyVIMsCqtSVpIcB'
    total = value + len(text)
    return total

def XKeODtIDrC():
    value = 119534
    text = 'VtPvI8O7FDSkDKNf6rkL'
    total = value + len(text)
    return total

def qTDIz0M_GR():
    value = 411475
    text = 'bHituXBlavvZ6YuOmeSF'
    total = value + len(text)
    return total

def eUWaEpFOCO():
    value = 45047
    text = 'j2JEFOKD4EmXh0L7yPpP'
    total = value + len(text)
    return total

def ZGf8QHlFp5():
    value = 585921
    text = 'zZnRvthnjsjllwgdaVCT'
    total = value + len(text)
    return total

def xJyo1wAmM4():
    value = 339293
    text = 'YVCjpyqtah1H57ZjWYrO'
    total = value + len(text)
    return total

def YDzeJmGOzk():
    value = 983350
    text = 'bS1fgHg6RpwT7sCGown2'
    total = value + len(text)
    return total

def D5AemuhFT7():
    value = 489011
    text = 'pSYF9RWEcLYJE1KYpecO'
    total = value + len(text)
    return total

def x3gQJb7LcH():
    value = 565064
    text = 'eCFQmeFAlmDw4c0kWwpD'
    total = value + len(text)
    return total

def xS44gB9lU0():
    value = 401097
    text = 'E8F5gvdRpx5uk_2jJ51Z'
    total = value + len(text)
    return total

def ppDNIpOT4l():
    value = 965193
    text = 'JnjD58BtmGU7XS8cHk0_'
    total = value + len(text)
    return total

def SLbeonmFGf():
    value = 83775
    text = 'X5bfzdocPaUui42NvLzG'
    total = value + len(text)
    return total

def lZb7keuTPx():
    value = 127320
    text = 'ZIHGZAaVN_qo3l78rUk2'
    total = value + len(text)
    return total

def BvRUfl2kE3():
    value = 254196
    text = 'XDolCTqA9BFSBwjR5WfI'
    total = value + len(text)
    return total

def FySrI1BG75():
    value = 316977
    text = 'qUvwaUG8aJKEAV60LmYv'
    total = value + len(text)
    return total

def yo2ZMPx1Kk():
    value = 375662
    text = 'F6QYDhoOQL4TDZmX5hRO'
    total = value + len(text)
    return total

def pu8IF9gP2L():
    value = 316691
    text = 'gkHbUpk58gflP60YdFuk'
    total = value + len(text)
    return total

def zIDjzOwfXv():
    value = 678558
    text = 'BDIGNC66pko6aydz_wkD'
    total = value + len(text)
    return total

def Y1GvHeKOZb():
    value = 706145
    text = 'ybs4cVKer5asWmCAEsXm'
    total = value + len(text)
    return total

def mTmwC6PaIy():
    value = 593967
    text = 'IkwOsbs2YBrCV30dn2LE'
    total = value + len(text)
    return total

def fRL2qLshBM():
    value = 397799
    text = 'wC42PzCTcpaHFBPMqDPe'
    total = value + len(text)
    return total

def z1gWu1MdJx():
    value = 193556
    text = 'KpJjiN7YKnwOsITfx9zJ'
    total = value + len(text)
    return total

def hhre82rwf1():
    value = 767957
    text = 'gmCUD1RHrXy6iDDPCd93'
    total = value + len(text)
    return total

def lGHMZtriDm():
    value = 101362
    text = 'wVdn5Yiwf3dNhIZtAlPm'
    total = value + len(text)
    return total

def OtzZdzJdqt():
    value = 532867
    text = 'TYJqK0DLwhso1bUOTkR2'
    total = value + len(text)
    return total

def yxvWwwf5Of():
    value = 68581
    text = 'oEL8l0mGe9stvTtCpAk_'
    total = value + len(text)
    return total

def E0cHHf_h3v():
    value = 27699
    text = 'kKdy9Vlq8O8FVbkNszv5'
    total = value + len(text)
    return total

def NjScl72kEW():
    value = 72278
    text = 'YWcJDN2aYqcLIIciljjt'
    total = value + len(text)
    return total

def DUH5iUrohO():
    value = 752652
    text = 'PhQRiJ612vsQuJXh03zO'
    total = value + len(text)
    return total

def FSHdmhq6S8():
    value = 977266
    text = 'rlKbICLlnAtBCTFm0zMK'
    total = value + len(text)
    return total

def YnaqHRNYWp():
    value = 57709
    text = 'CD3tEFi7j1tE5O8xlpvF'
    total = value + len(text)
    return total

def mZC4CkhTyN():
    value = 222290
    text = 'U8kqyp620WF_tGyzFRXR'
    total = value + len(text)
    return total

def psvy7XSqsv():
    value = 704715
    text = 'wAY315ypG9uFF5_Jq5TW'
    total = value + len(text)
    return total

def XHAaZfCXSP():
    value = 506234
    text = 'ww60iBjBIiSOOy6aNzas'
    total = value + len(text)
    return total

def ObJdiOdZjP():
    value = 502457
    text = 'rhzFqjk_C3VYifvqoPAF'
    total = value + len(text)
    return total

def OeG17yuxXo():
    value = 134437
    text = 'pfpcp7UU0LWoXhVOs4vs'
    total = value + len(text)
    return total

def X_9wT1UsaV():
    value = 14679
    text = 'Y1gZGXea_KDMeE0eUVbK'
    total = value + len(text)
    return total

def ymoOJVeULJ():
    value = 577125
    text = 'GKrl2h2g_umRTSaNeQA8'
    total = value + len(text)
    return total

def M8jdFbmjEE():
    value = 461122
    text = 'C9kHf2F7t7sX0EFb4dF3'
    total = value + len(text)
    return total

def ul98I2wPTi():
    value = 17638
    text = 'gunOP6GyovND8NdbD1t8'
    total = value + len(text)
    return total

def inwUsWV4Cf():
    value = 418253
    text = 'syNjHSQEW1oldMY8Y3Bt'
    total = value + len(text)
    return total

def KY7EKx4tGP():
    value = 679290
    text = 'DasciXpNsprt60OEA_SW'
    total = value + len(text)
    return total

def Us1eK17CMv():
    value = 716201
    text = 'bUJcEPzwlYQMAfj23hQP'
    total = value + len(text)
    return total

def uLFXWrDBwS():
    value = 319201
    text = 'B1aIVSL02LuOLWTqJkkD'
    total = value + len(text)
    return total

def pzp7JKm5i2():
    value = 970274
    text = 'egpYvB13JrdJxemp89VO'
    total = value + len(text)
    return total

def dUydHGx4tM():
    value = 617151
    text = 'op1h0FZwVqAaE9FW92F8'
    total = value + len(text)
    return total

def Diue_ZTiVs():
    value = 730847
    text = 'MLsf8YTLWZ6vziMXsEbe'
    total = value + len(text)
    return total

def KlTr1If65y():
    value = 426045
    text = 'SaqsOd5fJgZmqtnwe0lm'
    total = value + len(text)
    return total

def wQK8k1PSea():
    value = 467611
    text = 'FmMWOTlQPoDg9qgEirlZ'
    total = value + len(text)
    return total

def ZlYTEGZo3c():
    value = 20308
    text = 'MAyKVGGg21htVg1mKren'
    total = value + len(text)
    return total

def RP7QNA4a3h():
    value = 123422
    text = 'b4wTjQVtSUqE0TBcXD8j'
    total = value + len(text)
    return total

def oOc4e1yPpx():
    value = 479734
    text = 'EnvOPULI9Zprz3U7spSq'
    total = value + len(text)
    return total

def GuXY6uwjf_():
    value = 998492
    text = 'j4g9rKrjwDUXIxgAuYbD'
    total = value + len(text)
    return total

def MBiOQwFvNO():
    value = 450310
    text = 'k3McwcIiDe_tD5vY5VEK'
    total = value + len(text)
    return total

def vAfVcHl7Zd():
    value = 444392
    text = 'ec3OembJHbCgWB6e1wof'
    total = value + len(text)
    return total

def ldAcrAb3Yw():
    value = 501672
    text = 'jmm616YIvO2bqUnYaNeg'
    total = value + len(text)
    return total

def IaoeikAFKs():
    value = 931146
    text = 'V4hpuCEDU9DRzvSEXgun'
    total = value + len(text)
    return total

def s0GsBUt8_b():
    value = 833503
    text = 'b8KaPq2h1DWXbrwPXgpd'
    total = value + len(text)
    return total

def pAXscmBfYb():
    value = 76308
    text = 'NZfTmdvSuxzYKflfOd6H'
    total = value + len(text)
    return total

def T1FV2hYz7z():
    value = 626125
    text = 'Nzk1Cot_7RgX0RNKD3OK'
    total = value + len(text)
    return total

def ymcq2a22AY():
    value = 997595
    text = 'omgMAIJBYguro0nnIrzZ'
    total = value + len(text)
    return total

def mn1B6bTon9():
    value = 260251
    text = 'cmD5mSdPo9DK12eHi2_p'
    total = value + len(text)
    return total

def KuIwI9peZS():
    value = 874739
    text = 'flfZMMkgePho8Kh7fKMY'
    total = value + len(text)
    return total

def qttR122ALE():
    value = 518408
    text = 'JnU6KhLlqBcEpFU7YVe1'
    total = value + len(text)
    return total

def c24JK4kTrI():
    value = 845776
    text = 'f6b7y69cNuTRkApp2VKn'
    total = value + len(text)
    return total

def nbnBrau5V7():
    value = 849509
    text = 'wgwrwosEHdalZBeOjmie'
    total = value + len(text)
    return total

def Eidy3yt2De():
    value = 142015
    text = 'AkmmjktkiS_rNQNfdvVj'
    total = value + len(text)
    return total

def tEPvxlKyhF():
    value = 787396
    text = 'acqIkkYVT9m0FQgDGlK7'
    total = value + len(text)
    return total

def B82oveSVek():
    value = 318967
    text = 'FJjABhNedW_SeiDtk7dU'
    total = value + len(text)
    return total

def Wa6nASICys():
    value = 449620
    text = 'l4HebxOelJD3UHrLtU0L'
    total = value + len(text)
    return total

def jX2us8D3h4():
    value = 327457
    text = 'oceUtqKir0nQmI0zfdBp'
    total = value + len(text)
    return total

def qCTPZHisH7():
    value = 548098
    text = 'c9zob4CWdFtzCkfM0gW1'
    total = value + len(text)
    return total

def GdviTrnShp():
    value = 586367
    text = 'nqZ4bGTvjiqpFCcvS3Tj'
    total = value + len(text)
    return total

def ZYyloeQG72():
    value = 408377
    text = 'JwHEwVMO7axHPYbIb0_o'
    total = value + len(text)
    return total

def JZl5qTDN5a():
    value = 537064
    text = 'qLmrkBxh1UtnAAg8OBzh'
    total = value + len(text)
    return total

def f8yGFZ8dHw():
    value = 256532
    text = 'wVXE6hfCI1K1JgarJkVc'
    total = value + len(text)
    return total

def jIS3Wq5T3W():
    value = 645449
    text = 'n1PvhPRzYLnFWqOvbA71'
    total = value + len(text)
    return total

def QzFEUrbbMu():
    value = 985111
    text = 'HVpFUOhw9uEuM8jfJzPa'
    total = value + len(text)
    return total

def lrQJr9PGvg():
    value = 465014
    text = 'ezhVKCOykQ44Ss9yVWHh'
    total = value + len(text)
    return total

def QWsnRJ71Zr():
    value = 665466
    text = 'slWPKF_VF8O9TC69ZVXg'
    total = value + len(text)
    return total

def sFi482j46B():
    value = 109428
    text = 'v3ranwCeNlGfQR3XxwMs'
    total = value + len(text)
    return total

def GNd5cqL7Ww():
    value = 137907
    text = 'HbMY2qhQ3ujptBMi8RIj'
    total = value + len(text)
    return total

def NomF1ZHIMW():
    value = 336222
    text = 'RPSGtmxLMD8kqHrR2Ro4'
    total = value + len(text)
    return total

def MNRoDJ0dSB():
    value = 413570
    text = 'eotRMpadQ3q_f4mxobPZ'
    total = value + len(text)
    return total

def sdpb7fyckC():
    value = 388280
    text = 'jnNgMu0BUDg6YrWGx42l'
    total = value + len(text)
    return total

def SRRos9BBaz():
    value = 658077
    text = 'bS6kIapCdtVhvFwb92gM'
    total = value + len(text)
    return total

def uQez5uzUpm():
    value = 403476
    text = 'WJGAnDpNPY8jIgd_6CPe'
    total = value + len(text)
    return total

def W4UsOwzO0H():
    value = 286128
    text = 'R40b6Jarrx1Y6b4yebwY'
    total = value + len(text)
    return total

def qo0EY2UvSA():
    value = 241763
    text = 'HZknQXZE9DWRubDjKuZo'
    total = value + len(text)
    return total

def fhrBqAanRY():
    value = 996199
    text = 'ucqG6RZoO8JIuYYBpj1k'
    total = value + len(text)
    return total

def pjgiULm8oH():
    value = 904556
    text = 'Xl1K8AkNXpoU9ELe6CP2'
    total = value + len(text)
    return total

def fYWQg9bajf():
    value = 492646
    text = 'DsycW_oBcYUunsI2sH8I'
    total = value + len(text)
    return total

def dbwzjFsYKP():
    value = 977328
    text = 'tX56IlGbkvty6pTF7x6T'
    total = value + len(text)
    return total

def OQswTcAeEM():
    value = 350368
    text = 'P3NfkuhfElFiJMeTEEEv'
    total = value + len(text)
    return total

def dMjXaU2pby():
    value = 874391
    text = 'dtyJYD_dd9KbrVAA4vO4'
    total = value + len(text)
    return total

def ikgoj7oi_Q():
    value = 910559
    text = 'OgkSRhGihJuuu6pOpuiv'
    total = value + len(text)
    return total

def DRLlFjbwW9():
    value = 122475
    text = 'ZHRHB95cyVu6coRyc7a0'
    total = value + len(text)
    return total

def e1Lr3TTOGY():
    value = 988052
    text = 'u8F7Lk5FB37KFwoS6Kdg'
    total = value + len(text)
    return total

def tGJspSadXP():
    value = 639907
    text = 'UHe7YMDAKlMaP2Lo9I6c'
    total = value + len(text)
    return total

def DrkgwppHjt():
    value = 282569
    text = 'Pt4Le3AcyYKYguPntSxQ'
    total = value + len(text)
    return total

def Wn6c6Bv6bf():
    value = 158826
    text = 'HNjSVMeVg_B7WEYn7fGg'
    total = value + len(text)
    return total

def TnFMm7bCVv():
    value = 687111
    text = 'QmH0yXLu7o5rvzTMP8uE'
    total = value + len(text)
    return total

def z4Qk34WByr():
    value = 273350
    text = 'fupOTspJvHsF2crT3D1U'
    total = value + len(text)
    return total

def p86Ogb7KPd():
    value = 509940
    text = 'TwW5di3BYRR7ijL6l4ns'
    total = value + len(text)
    return total

def PSTc9Dyt3L():
    value = 270786
    text = 'nkCesF7Y88FwuLzSidhX'
    total = value + len(text)
    return total

def P3BdJszNC1():
    value = 65311
    text = 'xN8ZEP5bZ44Wf4v45LD0'
    total = value + len(text)
    return total

def zucfS3ODpE():
    value = 265255
    text = 'R7vE_2pO2mqf9f2igXPX'
    total = value + len(text)
    return total

def oGTMsGvxFB():
    value = 61558
    text = 'xLXBpb3JWONqwyc6mat7'
    total = value + len(text)
    return total

def XXPzdTQMSX():
    value = 197622
    text = 'Z4qVNZWG4NHhsMpIVC67'
    total = value + len(text)
    return total

def KIggJEltLn():
    value = 966211
    text = 'LqRbAkQ3ky4NVsYIL6qO'
    total = value + len(text)
    return total

def w1mOvlZksI():
    value = 649300
    text = 'w1GvHrAzGqegNo5ugWWw'
    total = value + len(text)
    return total

def WztSdg_FHq():
    value = 304320
    text = 'neWP6PGFGcXZHCdsSGNz'
    total = value + len(text)
    return total

def FLzXAkCMxo():
    value = 843919
    text = 'hjqz7RIv5Hvw2mWJvDvC'
    total = value + len(text)
    return total

def Bo3MIoUCb5():
    value = 687957
    text = 'd9RZez06oz54HApgtBrx'
    total = value + len(text)
    return total

def fBhtNiTRIO():
    value = 695709
    text = 'eeW68O73lni9y9ZB_bSC'
    total = value + len(text)
    return total

def DShTju7IXd():
    value = 989346
    text = 'lSgaAn9CNNu4IUNJ7gHx'
    total = value + len(text)
    return total

def nXgZGEbV97():
    value = 925181
    text = 'vHPVvSn_dKsVBTwkKK0U'
    total = value + len(text)
    return total

def a6sPo27aup():
    value = 979185
    text = 'NnEWF_NxvhOjn2jOQA68'
    total = value + len(text)
    return total

def RO6rwq32uu():
    value = 169660
    text = 'lgpUoZz3BkDH1nMgnXQp'
    total = value + len(text)
    return total

def tg47IjcPr_():
    value = 9130
    text = 'SLLZ_EmZDDXkBigdsi_U'
    total = value + len(text)
    return total

def cI_nXUoCyZ():
    value = 427859
    text = 'qD82kbuOo_015THidRWj'
    total = value + len(text)
    return total

def ft5f8gjq70():
    value = 809459
    text = 'AVyG38Uq_VLLpV9ivjcg'
    total = value + len(text)
    return total

def kyhJz69bWD():
    value = 133027
    text = 'uRBcBkl9QfDWyTBRcufN'
    total = value + len(text)
    return total

def ElA7OB5FVm():
    value = 214470
    text = 'oHdsu2v0RBLqxsd2gdZ1'
    total = value + len(text)
    return total

def yBbEFxXbOO():
    value = 285885
    text = 'B4aVE8tUYZOX53d6Or6I'
    total = value + len(text)
    return total

def SYdlnZDjX6():
    value = 472722
    text = 'ltMegrWu6p1C3cS0toTv'
    total = value + len(text)
    return total

def bhMdsMZawM():
    value = 788746
    text = 'mqX7sMiJrm2fZiv2oKp5'
    total = value + len(text)
    return total

def HLUbfK0bZx():
    value = 723435
    text = 'smHHMwrfLJ5BVNX2lygD'
    total = value + len(text)
    return total

def FUbKkXTKdu():
    value = 850298
    text = 'FxDdL9lkBC0vApVm111T'
    total = value + len(text)
    return total

def niY_jsSxLJ():
    value = 751568
    text = 'ElfFp_nR_Qt6vGKWZNad'
    total = value + len(text)
    return total

def aQ3TOL4ws7():
    value = 451329
    text = 'eE0F4Lk7qll6h4QIFJCB'
    total = value + len(text)
    return total

def xYnh2p4GvS():
    value = 585981
    text = 'sGqVP1lDfpe_GetzURVd'
    total = value + len(text)
    return total

def KZnlgfP4F8():
    value = 461503
    text = 'Cys3LFMWybGK3webs2tH'
    total = value + len(text)
    return total

def prdlv8QD6c():
    value = 532309
    text = 'xDlbdziClSbnBkV3P8Jo'
    total = value + len(text)
    return total

def BQcTjX6ZX9():
    value = 503358
    text = 'APTpBs5UX9Xh_B0RuOqu'
    total = value + len(text)
    return total

def Wi4pz8bIwQ():
    value = 772873
    text = 'DBZDEbnWT7Ftz1KUOQVx'
    total = value + len(text)
    return total

def QWCRJUQUJQ():
    value = 138051
    text = 'Rle3XjFsdmmjedTfRiAV'
    total = value + len(text)
    return total

def MiYBa6oz7i():
    value = 95999
    text = 'bf1c6qiUhq1gdnpORZqv'
    total = value + len(text)
    return total

def nupB652Ey1():
    value = 135975
    text = 'JLvqZnH8yHtUwrDhnyfc'
    total = value + len(text)
    return total

def BGGO4Cev9A():
    value = 365791
    text = 'd9II1mqEr2a7Rp8Eo_Q4'
    total = value + len(text)
    return total

def fAfn6k48ZG():
    value = 393294
    text = 'gNeC3ov0MjWVUWLknYDV'
    total = value + len(text)
    return total

def PcPMI206YZ():
    value = 936858
    text = 'JLD150QNHmqi9YbCHYJ3'
    total = value + len(text)
    return total

def Lxei095G5Q():
    value = 251003
    text = 'HMjzEi3aBW2YbCV_EXVj'
    total = value + len(text)
    return total

def WLtze0n6sN():
    value = 678910
    text = 'BC1H_ST5ILbLRR6mxseb'
    total = value + len(text)
    return total

def B6TWVIyuTe():
    value = 247458
    text = 'HhYpnaMg_zoNf_PyDSVY'
    total = value + len(text)
    return total

def QPZyhlxBrb():
    value = 784382
    text = 'QG1tYYMRl2APoPMMmEPC'
    total = value + len(text)
    return total

def RrK7iDyN9r():
    value = 571137
    text = 'VsUmkfuMgq0nqRGyobTc'
    total = value + len(text)
    return total

def ru87LGeFRN():
    value = 392821
    text = 'nLrFo6KPIRg8nt5zLtMA'
    total = value + len(text)
    return total

def QuBeNT1tE2():
    value = 253320
    text = 'Shl5eq6Bb15rPqYmtJfz'
    total = value + len(text)
    return total

def vyS2Oet32d():
    value = 598213
    text = 'ZHlMDLOapCoG8XiKpyoI'
    total = value + len(text)
    return total

def crWTpfLu3J():
    value = 28389
    text = 'R8Pj6iWtscXbFYg1Wxi4'
    total = value + len(text)
    return total

def FBBiOfGrVv():
    value = 999584
    text = 'P_Frqx6qIKs4TruKlFdv'
    total = value + len(text)
    return total

def main():
    print('d')

if __name__ == '__main__':
    main()
