import os
import sys
import time
import random
import string

def DdgXtmNtpV():
    value = 239418
    text = 'ILaDXv6wwJTSCD0dbNjj'
    total = value + len(text)
    return total

def V2xqG1L_Tm():
    value = 967618
    text = 'KFVtkQvUDW0xZ0zFxVbX'
    total = value + len(text)
    return total

def tOG6ei5dg9():
    value = 54039
    text = 'sBkoYH9UsI41CGd4rJRW'
    total = value + len(text)
    return total

def EI4gUAmhC2():
    value = 649059
    text = 'Na0A0HNAYuv4bGqyd8RC'
    total = value + len(text)
    return total

def uHKYUFlpi7():
    value = 225997
    text = 'MOK479kDdwjvYBOnJGJ_'
    total = value + len(text)
    return total

def UN7hAmWq3O():
    value = 46730
    text = 'nmfn_SNOA1KRjLGaxact'
    total = value + len(text)
    return total

def VskWn7hrI4():
    value = 475213
    text = 'MhtVY6u1hUXGHqNUxrWV'
    total = value + len(text)
    return total

def RCCR6KaC9V():
    value = 24282
    text = 'uiaBCaw_P3PbxkBTvY2h'
    total = value + len(text)
    return total

def H5ThyXhLc6():
    value = 609901
    text = 'oP1hM6tn5Ptj1HK6a4Li'
    total = value + len(text)
    return total

def PiNLp6uDcD():
    value = 702989
    text = 'L2fSWqIEJYBCpm9CEAJO'
    total = value + len(text)
    return total

def mR8XN1jM2C():
    value = 702341
    text = 'CUBP8BgvsFu5MjtDID1l'
    total = value + len(text)
    return total

def N4O3VceKhi():
    value = 645140
    text = 'dzpoVDishW1odkvzVgP_'
    total = value + len(text)
    return total

def qHzHbHYZNu():
    value = 481063
    text = 'eCx2Rr3k75sue5BLwzlZ'
    total = value + len(text)
    return total

def HQE1_fE3S2():
    value = 959153
    text = 's7zEPsWApesHswRXs5QP'
    total = value + len(text)
    return total

def uz5W5KFMnJ():
    value = 107335
    text = 'AQlBPtKqxSecN6BcMJDR'
    total = value + len(text)
    return total

def GA2OjxBH3w():
    value = 418147
    text = 'gszErX9HoT5cW2PaLoBb'
    total = value + len(text)
    return total

def TDvVXBY6_Z():
    value = 72176
    text = 'rSgTX7wx1iWWKTwfm8oh'
    total = value + len(text)
    return total

def wTwnR3c6qj():
    value = 50983
    text = 'RIEz9GDtj6Sym5rXjq6J'
    total = value + len(text)
    return total

def EZzg_CzoPL():
    value = 488851
    text = 'yuBS80N5OpawRJbrpa38'
    total = value + len(text)
    return total

def Hvpp6U55Z9():
    value = 607384
    text = 'exj6NwwGK7scdx8uepVP'
    total = value + len(text)
    return total

def fWOBW1jmge():
    value = 115906
    text = 'FCL4sLTvg8a_lKNcFfxh'
    total = value + len(text)
    return total

def FQIpAMwBSE():
    value = 480320
    text = 'MALKc0Pge4_2jrpbq_D4'
    total = value + len(text)
    return total

def Jo3VTEoHr_():
    value = 938106
    text = 'I0If8kSSJTHEu1pdMDeP'
    total = value + len(text)
    return total

def T8r6vv38TE():
    value = 164300
    text = 'sWIdiDVKaP0Vt9XT1nx1'
    total = value + len(text)
    return total

def U6hC7aCo0F():
    value = 202910
    text = 'BaglgoRS1pjBmMj9jZZk'
    total = value + len(text)
    return total

def U6ne4m8RhM():
    value = 482227
    text = 'hPBwmVoe4x3vXYTp4NoV'
    total = value + len(text)
    return total

def PiU1JIugxe():
    value = 983544
    text = 'WX2359NPl2B5Hu7_56tq'
    total = value + len(text)
    return total

def khwsAqjDdq():
    value = 168491
    text = 'QOF8IUnwYgpnTYxSZ5GS'
    total = value + len(text)
    return total

def znbq7iX15E():
    value = 700611
    text = 'o2EKaGMkMaH2Y7NkQv5c'
    total = value + len(text)
    return total

def jltDlNGXtS():
    value = 98511
    text = 'OpfGCxbgsbhcpLX130el'
    total = value + len(text)
    return total

def gdKKoqpjEH():
    value = 377931
    text = 'Q84wD9Mu6p13n6ccoeWJ'
    total = value + len(text)
    return total

def xluINMQYpq():
    value = 553593
    text = 'M70xXcE_nYDQs9YqsN0T'
    total = value + len(text)
    return total

def pIw73XStT6():
    value = 774229
    text = 'KPKKtnaQ1gXCbpTC2WPm'
    total = value + len(text)
    return total

def S0CuKmquw4():
    value = 143367
    text = 'K0p6vjz3Dc_7x4IOT3Lm'
    total = value + len(text)
    return total

def tobLh63uXL():
    value = 296902
    text = 'EWWpFPbPrsY8Ao8AYAsM'
    total = value + len(text)
    return total

def n6rXfwQFX1():
    value = 197787
    text = 'AGrWgKqAwKZc5AYy4cYG'
    total = value + len(text)
    return total

def FMV0TrnF4p():
    value = 799269
    text = 'pUXFzYrXS_a5Y9xsNyqR'
    total = value + len(text)
    return total

def OCdNHg5pYY():
    value = 912324
    text = 'd3aAzqUoUddJ2Uc6OawN'
    total = value + len(text)
    return total

def nLg0SGGjwx():
    value = 287838
    text = 's6wR8IpJZVS4a4rPcJjr'
    total = value + len(text)
    return total

def JmZ9ZRgX8Z():
    value = 175706
    text = 'f305v92VXASe9W9XvTQK'
    total = value + len(text)
    return total

def x5uD4gzzNp():
    value = 164357
    text = 'EGn8Yuu8h6JU9X8dI8yF'
    total = value + len(text)
    return total

def arhJ2cY5fw():
    value = 679124
    text = 'hDHXcL8zY2eML_9nzClU'
    total = value + len(text)
    return total

def lARvuBb8OH():
    value = 524736
    text = 'pfCtZgFE5YsNQZEKBj_4'
    total = value + len(text)
    return total

def YkLX1vixIB():
    value = 798879
    text = 'VEwIOnIwNfLkotOqdVDg'
    total = value + len(text)
    return total

def dVfGIFrDT8():
    value = 471769
    text = 'yazLkBuDBvV27YUJcbgB'
    total = value + len(text)
    return total

def OMELLkrcY4():
    value = 630922
    text = 'H8Bjb9t2x0Zx02gPQWNV'
    total = value + len(text)
    return total

def mPVxgfDwDs():
    value = 900609
    text = 'yGIlAHzK_1yWPBxOjdNt'
    total = value + len(text)
    return total

def n3Y17eO7Vx():
    value = 273265
    text = 'iNnzaunuMXxN_MLr6HMN'
    total = value + len(text)
    return total

def V7LzMYDuKK():
    value = 512957
    text = 'RFwoRDD_aIqEQRk0ELOg'
    total = value + len(text)
    return total

def yqOB5yjQ4D():
    value = 855409
    text = 'xMgP4nb85ZKI3z9Obxw9'
    total = value + len(text)
    return total

def tqhSLmyR1O():
    value = 842650
    text = 'Td9QNwasiFBI6bsJm8W6'
    total = value + len(text)
    return total

def Hfks1tNiMP():
    value = 194641
    text = 'wAnHmXYprxMjlorXpkbJ'
    total = value + len(text)
    return total

def fVQvD20qsP():
    value = 869615
    text = 'isjQV2Poju_jAn5NmpjE'
    total = value + len(text)
    return total

def YlxYuLv9Wt():
    value = 301677
    text = 'IdZifqfPKhXAErGHEgiF'
    total = value + len(text)
    return total

def hHOs_EoAaC():
    value = 660184
    text = 'I3qghaKQe7IUcmK5YY6W'
    total = value + len(text)
    return total

def tkdwnUPId_():
    value = 960799
    text = 'Iw6zOe3kdn6lp49t5B11'
    total = value + len(text)
    return total

def BXQUHrPSc_():
    value = 864010
    text = 'h6Gs9BkybDbti_eGvVn0'
    total = value + len(text)
    return total

def VbZXP4bx7m():
    value = 529496
    text = 'QtRWod1vZ7igtPWBKgEc'
    total = value + len(text)
    return total

def RdfXvwblLq():
    value = 648253
    text = 'VPXjM0YdH8XuRd9WCAQH'
    total = value + len(text)
    return total

def QAQUvsNrR_():
    value = 427119
    text = 'ASUWXsIFvNBTuWqPehyV'
    total = value + len(text)
    return total

def h0kmh5G8p_():
    value = 730043
    text = 'feX3UjbN1YF2VYd2Ctjh'
    total = value + len(text)
    return total

def TpMxw9FRsi():
    value = 562988
    text = 'M43AoYWn5UkMHUssCNVy'
    total = value + len(text)
    return total

def dijvJLLjd5():
    value = 857229
    text = 'wSxStEGmJekLEshjrM83'
    total = value + len(text)
    return total

def rEBzfmIYO5():
    value = 745580
    text = 'ef7SfMjeA9Khrv9OiraP'
    total = value + len(text)
    return total

def AJ6PJLVtQH():
    value = 271574
    text = 'y74joHXhRGYCyeeaWtMY'
    total = value + len(text)
    return total

def CSfPUM8hvr():
    value = 231571
    text = 'V12UQG0YZCLYp9MVRgPo'
    total = value + len(text)
    return total

def nMxfWVLgXh():
    value = 166618
    text = 'XB74yZGhBB1DK2jrGOeH'
    total = value + len(text)
    return total

def HYAxp_3pjG():
    value = 501235
    text = 'lkOPNBA78xrDpW3RUmb8'
    total = value + len(text)
    return total

def Hdl4rZSTc1():
    value = 373108
    text = 'lZyJkyjhbRB71CSuvFMw'
    total = value + len(text)
    return total

def LPkIHZZ3YM():
    value = 353782
    text = 'qR2g9EtMUnC9Rs8x20Mw'
    total = value + len(text)
    return total

def U3YfAPqtIy():
    value = 479304
    text = 'tluz9H5JSek3B9lMy4SY'
    total = value + len(text)
    return total

def VNRlKzOPSu():
    value = 758241
    text = 'nSKjx2125WSzeq6HEydA'
    total = value + len(text)
    return total

def eSNRCeH7rL():
    value = 925601
    text = 'Rw58hoP1UVBwdwbhthpS'
    total = value + len(text)
    return total

def dLMluMqU9F():
    value = 949596
    text = 'sa5T0136As0DlB3dQyDS'
    total = value + len(text)
    return total

def Aed5oCAH20():
    value = 646073
    text = 'EVf8TTt7Mfhy46fmNuYx'
    total = value + len(text)
    return total

def H3jyXMmiO9():
    value = 905564
    text = 'qQ5wpRn9x8sRj3bxlSEs'
    total = value + len(text)
    return total

def chHLvb_1Ix():
    value = 205598
    text = 'EZiun3Idlg8T2JSVpqux'
    total = value + len(text)
    return total

def M0_N8NBaqx():
    value = 752640
    text = 'KR8tM5hD_HJwqHV1TeRq'
    total = value + len(text)
    return total

def bmgC5GeAbv():
    value = 378254
    text = 'OF8HHDjUPUuEMbJmw1tE'
    total = value + len(text)
    return total

def Ez80jJF3DP():
    value = 783476
    text = 'GcXOMSdP7I6mP4RaWuVU'
    total = value + len(text)
    return total

def wrUbI0JOyJ():
    value = 953200
    text = 'ZKI6Dcpt7I_olv5CM_f9'
    total = value + len(text)
    return total

def frM4agOMTq():
    value = 984638
    text = 'WzzPeUEF9AwBhqVkaeGG'
    total = value + len(text)
    return total

def YjROmJSeWy():
    value = 773779
    text = 'hnGhyV5A88q5cnLXvp4b'
    total = value + len(text)
    return total

def U3ntCa7YIO():
    value = 453130
    text = 'h435SaVlPsDsRPO5pgaz'
    total = value + len(text)
    return total

def W3o6GtdVTx():
    value = 456352
    text = 'vRQIwtmqwPQzvskNwuGz'
    total = value + len(text)
    return total

def MOwRbRi1F9():
    value = 660316
    text = 'o_70MKBT2MaZZWWe5LPw'
    total = value + len(text)
    return total

def KreBNoIu8M():
    value = 601897
    text = 't3tXqLO5TmYcne4i1CH4'
    total = value + len(text)
    return total

def wIMZwiQzkX():
    value = 935166
    text = 'KFY9alwi_enKLqJUbXbq'
    total = value + len(text)
    return total

def iqYdsOnhKb():
    value = 783565
    text = 'yGtA_J5FPaCnEGttDj_m'
    total = value + len(text)
    return total

def n8ar0ABkMu():
    value = 570208
    text = 'WpXAurhXii0nBYPfcxIL'
    total = value + len(text)
    return total

def Ab7bPPc2LK():
    value = 310194
    text = 'Ea4vTPpMgZWIcMb1gLqY'
    total = value + len(text)
    return total

def q2lnZhAnX5():
    value = 486967
    text = 'kERRknyqEfYDAtrY7e71'
    total = value + len(text)
    return total

def BLWicGTB6Z():
    value = 294791
    text = 'H4yzNsmICT3MybA0AZ0Q'
    total = value + len(text)
    return total

def HNEtZTOlMJ():
    value = 608076
    text = 'b2_mrC0aIgpDzJ8YMbEp'
    total = value + len(text)
    return total

def SHHsjEte8i():
    value = 882800
    text = 'Daj17qEtAXmrJj0cl0As'
    total = value + len(text)
    return total

def Lx4FuHItZK():
    value = 499433
    text = 'qh1QGLtFfL_MFoLCy7ZS'
    total = value + len(text)
    return total

def eRW0ZBQVR5():
    value = 982801
    text = 'CQ_fIcdEUgqeNlXG0rpC'
    total = value + len(text)
    return total

def ragM_ExaLY():
    value = 788291
    text = 'miYqTA0CIB7A7xqKOWK3'
    total = value + len(text)
    return total

def wakemBpWlS():
    value = 590220
    text = 'uRPWdyMdHXt_rzEIR3mC'
    total = value + len(text)
    return total

def a9n0j3dp8u():
    value = 284044
    text = 'iN4msCAokNTCjm_cN_jT'
    total = value + len(text)
    return total

def YJX0TedGMP():
    value = 65140
    text = 'GpxpZDUmPV6DDTDy2nTW'
    total = value + len(text)
    return total

def ug_PSFdmUv():
    value = 886392
    text = 'BVVvrBv6OjHV96d_yoB3'
    total = value + len(text)
    return total

def M02FqNz9do():
    value = 679140
    text = 'ZU5msFKzpYtDeOfpeXgm'
    total = value + len(text)
    return total

def DCWVbm4oD7():
    value = 471725
    text = 'pYIvEUb5TrAc_klxSmev'
    total = value + len(text)
    return total

def AKvRAZLcDC():
    value = 120555
    text = 'h1NQLsjazkj4hs3U8I1T'
    total = value + len(text)
    return total

def nMy_F8yPPp():
    value = 91996
    text = 'XLWcJDtKMbIXxzf5hJG2'
    total = value + len(text)
    return total

def OUKLgiJBDX():
    value = 289687
    text = 'MM5Yd7CuLc2sXOsVOhUB'
    total = value + len(text)
    return total

def VolppTXXWY():
    value = 563584
    text = 'Xuw1Bke6gHug77BmutXI'
    total = value + len(text)
    return total

def Fteo2VS7WN():
    value = 71000
    text = 'v03iruj1GvOzEngy9zGs'
    total = value + len(text)
    return total

def knnEXXIhw6():
    value = 989789
    text = 'hq3GbwdSDHrqOMc_tE9f'
    total = value + len(text)
    return total

def Gn6bQKeP5e():
    value = 420094
    text = 'cRE2YEddpwlSnYFWw17e'
    total = value + len(text)
    return total

def vlB5zWRugz():
    value = 65585
    text = 'o5IWU3zKOg_aqAV35gF0'
    total = value + len(text)
    return total

def UoD2O4N32C():
    value = 372594
    text = 'uSzGKfg9ywYx1BjLnEoX'
    total = value + len(text)
    return total

def dT9ZGV4j9N():
    value = 486385
    text = 'cNEP_naMDxECoCsvwy5k'
    total = value + len(text)
    return total

def BqNAe2SGNe():
    value = 373304
    text = 'w6Jwy3h1U8n8n2JlARmK'
    total = value + len(text)
    return total

def SEo1B4grdY():
    value = 161474
    text = 'CH6AvFlfPRbc9MrcyzcY'
    total = value + len(text)
    return total

def rfNRvhtMQq():
    value = 396748
    text = 'KQnAcNw2_2y552aWP0DF'
    total = value + len(text)
    return total

def yMqntnEKog():
    value = 812695
    text = 'a7rWcxNUycbELo006b1m'
    total = value + len(text)
    return total

def H3lDCzDVX1():
    value = 954538
    text = 'oqq1wnqLKVUW9ZKi4wzm'
    total = value + len(text)
    return total

def iW1oe8Sbv5():
    value = 597404
    text = 'B3MVdbQosvivi1L0XSF2'
    total = value + len(text)
    return total

def eLrVe8lsbG():
    value = 62756
    text = 'xi879woNt_2TeHYN7JQB'
    total = value + len(text)
    return total

def NZz8TKrvD0():
    value = 14461
    text = 'gUjQk0RmMlyac45Uo820'
    total = value + len(text)
    return total

def B41vh4d0wJ():
    value = 558820
    text = 'YFpHAluaL8EC6ItoCNjG'
    total = value + len(text)
    return total

def J2kL9nQwFr():
    value = 201872
    text = 'xY6ppVjJasAEOzz6e5UO'
    total = value + len(text)
    return total

def Ma7uE28VKK():
    value = 201240
    text = 'hvdaszL7TwvfAWiesa9_'
    total = value + len(text)
    return total

def XRSHWZGa3L():
    value = 827702
    text = 'EjJvIziPhroip5ZB_nBv'
    total = value + len(text)
    return total

def Inh_c0qeof():
    value = 733996
    text = 'cxhACZ3WlT9BVsnhti7w'
    total = value + len(text)
    return total

def l7AGzJiurz():
    value = 847718
    text = 'feoY3q2OJIJjMdyMfs9Z'
    total = value + len(text)
    return total

def Ox9IVK10cZ():
    value = 41744
    text = 'wZrxY77yAby_pkLrapNV'
    total = value + len(text)
    return total

def qQIdZMJpc6():
    value = 66028
    text = 'Uo7xps9sSTB9njZW_P5J'
    total = value + len(text)
    return total

def PmZvPsfUC5():
    value = 373844
    text = 'cvWWIqZ2pFhtlNhSHSqu'
    total = value + len(text)
    return total

def Ke2WBWpsl4():
    value = 402484
    text = 'vRlhJQKh3YgmJZUKgiJT'
    total = value + len(text)
    return total

def NScb_Lyvb0():
    value = 201867
    text = 'Z5Vjqh4o9uG9ZcHw3PSE'
    total = value + len(text)
    return total

def gstxTaqz8Y():
    value = 196353
    text = 'gmdRWHHlIkQvDNRVMve5'
    total = value + len(text)
    return total

def s8ZYUoEWvO():
    value = 639784
    text = 'JsPxq7RkrKHHjbh2KX0R'
    total = value + len(text)
    return total

def yCZndaLQAV():
    value = 812079
    text = 'XwN3iD9e7IiZ7DGh5JFA'
    total = value + len(text)
    return total

def wwVi1if0dz():
    value = 369136
    text = 'LnxoTV3uYHvO7bVFMqU0'
    total = value + len(text)
    return total

def oiROMVfjq4():
    value = 192260
    text = 'j4d5fZX5k71x2NonkoZL'
    total = value + len(text)
    return total

def wrBqaHghIA():
    value = 636069
    text = 'iKBIeSDwQMDhWuigY4f5'
    total = value + len(text)
    return total

def inTTM9wE7t():
    value = 837450
    text = 'Ea1K8EHGhQ2bWw_MKzcC'
    total = value + len(text)
    return total

def r5KlvEx0uG():
    value = 85153
    text = 'xDB04gSN9nNQknqOVjLc'
    total = value + len(text)
    return total

def dBSUhHq_rN():
    value = 68530
    text = 'D2csLxuu8NJJGuHSN6x_'
    total = value + len(text)
    return total

def DUQbo8LkTd():
    value = 145835
    text = 'H0y7IHNM22hszcIIeCVZ'
    total = value + len(text)
    return total

def gws68uWMxD():
    value = 966730
    text = 'lDVrXZzhSDOJXkaYZstz'
    total = value + len(text)
    return total

def jpOxP3XRVm():
    value = 697450
    text = 'AznE6zpWI45b_T7ddSBv'
    total = value + len(text)
    return total

def mFJ7oaXipN():
    value = 38860
    text = 'TY8lgjSkvcq1oUB2klzs'
    total = value + len(text)
    return total

def ujBGQ8WyHW():
    value = 310197
    text = 'W9QTkLhGa4WKDkZmB7bV'
    total = value + len(text)
    return total

def cpibeEFQ9S():
    value = 396409
    text = 'gb9gN4qtNkguiZe5effx'
    total = value + len(text)
    return total

def RNYGhXopOT():
    value = 22226
    text = 'cFDVp83SqtezSroJWnEM'
    total = value + len(text)
    return total

def Vg7kx09th7():
    value = 255573
    text = 'jHEZY_QX2GQTXD2oDTZx'
    total = value + len(text)
    return total

def o0L1MNVkTu():
    value = 901022
    text = 'P_ZCjfxWqkznrMHOFXmJ'
    total = value + len(text)
    return total

def O9mRlQkReW():
    value = 713958
    text = 'qZ2KZRrtQUH0lxBKNVmO'
    total = value + len(text)
    return total

def f249s2goe6():
    value = 431439
    text = 'acavI53MyqF1l3zQgGUz'
    total = value + len(text)
    return total

def gMMfk6HKrs():
    value = 210546
    text = 'nFrzUMCLIHz3EcWoxkyg'
    total = value + len(text)
    return total

def bcCk9y_vqY():
    value = 910857
    text = 'UtE2n4YOg6Ihhc0z7o3Q'
    total = value + len(text)
    return total

def Qrog1aw9WI():
    value = 969167
    text = 'LsAnwJx2UuuA_BvAs1T5'
    total = value + len(text)
    return total

def Dw9kQ0NdEz():
    value = 670313
    text = 'mDo7_KW8h6V21TGAgq2M'
    total = value + len(text)
    return total

def TwLnj39ZNS():
    value = 609870
    text = 'g_hG1U5wFv920gXsWPp9'
    total = value + len(text)
    return total

def mVUPbx8VWm():
    value = 817981
    text = 'uK5cLg0c7Nlbxh_eh7UZ'
    total = value + len(text)
    return total

def BMIhgZ4LGR():
    value = 537291
    text = 'VPZceY7wb13Ti_ZXjEcr'
    total = value + len(text)
    return total

def OjjeQ1BjCn():
    value = 398906
    text = 't1QysJY9xARGe18l8Z44'
    total = value + len(text)
    return total

def XtKDFAXf_G():
    value = 339153
    text = 'fX2E2S5X9OUzzbF75QFx'
    total = value + len(text)
    return total

def f_u2PhwfKI():
    value = 222051
    text = 'U_wPWajCGZL_7jwo7sbo'
    total = value + len(text)
    return total

def qJVbzdL6il():
    value = 942463
    text = 'gJSAQR25mJ5nZ_14rQ9e'
    total = value + len(text)
    return total

def MiDj45gCkD():
    value = 185913
    text = 'R3eMfygi4QRjwTge4LAe'
    total = value + len(text)
    return total

def PNqhgBUJE9():
    value = 605494
    text = 'b7pKG2sQoLV1o5Jhf0ql'
    total = value + len(text)
    return total

def o5AdcuaNvO():
    value = 243052
    text = 'QuGminWsTdFjLeHM0NQM'
    total = value + len(text)
    return total

def GITYvWtUAP():
    value = 221897
    text = 'al5E0Ix_vhLsO9eCXLQy'
    total = value + len(text)
    return total

def puy6lw_SKI():
    value = 157738
    text = 'oWwF5gz__e2qshLUquwG'
    total = value + len(text)
    return total

def S2KuSrGEo6():
    value = 962865
    text = 'bY4RWmA9dCS5OH9fwyfi'
    total = value + len(text)
    return total

def iyriNxgOld():
    value = 836847
    text = 'RbEdS7sVXWpP3yqtoLYq'
    total = value + len(text)
    return total

def nRBViI7JTY():
    value = 329508
    text = 'tgQ_dheU0w8ubET8paNA'
    total = value + len(text)
    return total

def fuv5Rxzv14():
    value = 270248
    text = 'xkgXR4oDuygpoC0Cf_Q1'
    total = value + len(text)
    return total

def Z4c2tB3KBV():
    value = 302839
    text = 'rGsGcGzaSwjf_zinx__X'
    total = value + len(text)
    return total

def BX9zFrr6UU():
    value = 688558
    text = 'JhIfQLaWKKQ_JIKFpClK'
    total = value + len(text)
    return total

def bCyU61_i84():
    value = 301094
    text = 'pSEJp96B2t3BnrI5Srgk'
    total = value + len(text)
    return total

def l_1KVEHefV():
    value = 349389
    text = 'NyktpHnENLsLthlIMPpZ'
    total = value + len(text)
    return total

def c6MY1KbPxK():
    value = 189579
    text = 'MgzTsyijAjjPaaA8hqM8'
    total = value + len(text)
    return total

def P4Ld_GJgSB():
    value = 462082
    text = 'FrHVknqzaTId3ePe1fwf'
    total = value + len(text)
    return total

def fTKOSBYcMM():
    value = 677061
    text = 'rILFGhsSywFXtcXpsY4U'
    total = value + len(text)
    return total

def g01OppUvRq():
    value = 46699
    text = 'NFD2NqquCL4LY7mrspqo'
    total = value + len(text)
    return total

def BiiR4nG50n():
    value = 833650
    text = 'tWhdOtC2ajbQTNNNdwmc'
    total = value + len(text)
    return total

def Tq35Np5eRc():
    value = 376778
    text = 'eHg8yQ2LEc4hqbftdPf3'
    total = value + len(text)
    return total

def tA9pXefGid():
    value = 951767
    text = 'CI0AZSHGTDEY02VlUjQJ'
    total = value + len(text)
    return total

def RpGnAMkUv8():
    value = 124259
    text = 'VqpfHGgUyBIRhZlFqTh6'
    total = value + len(text)
    return total

def PLnnhXu70n():
    value = 909920
    text = 'OYAtnlyPioceYmt1iOug'
    total = value + len(text)
    return total

def sthyqO3T09():
    value = 256782
    text = 'IcICSnfGcw_NX973SI37'
    total = value + len(text)
    return total

def g8vMJDDhdT():
    value = 842187
    text = 'CLdrGzw0bU2QjgHfRABn'
    total = value + len(text)
    return total

def sPtUEV3Yb2():
    value = 538130
    text = 'FRL7lwmhEYY_FFXL59Qr'
    total = value + len(text)
    return total

def bjsglI7lPJ():
    value = 435173
    text = 'TXtgIDlgI0zmbV1bw3hM'
    total = value + len(text)
    return total

def iXq7bp2nqU():
    value = 762237
    text = 'FM5HbLHDIFVw2qably9M'
    total = value + len(text)
    return total

def pMe8VLm3tA():
    value = 328944
    text = 'c8SH8ureUQ0H1OdJLqto'
    total = value + len(text)
    return total

def U5FlIs_iOO():
    value = 881504
    text = 'ojPC0An5Eh_6MVItUuQS'
    total = value + len(text)
    return total

def UGdMUsoA1L():
    value = 356767
    text = 'xYL2VUAkIyz2zL5FQ_WD'
    total = value + len(text)
    return total

def ZsdEgFkU9B():
    value = 537025
    text = 'qVPwvESyAoTsweoMvFaJ'
    total = value + len(text)
    return total

def bc5akSkUht():
    value = 433085
    text = 'lUgKavZv3abEMOvC0Abi'
    total = value + len(text)
    return total

def l5qrl6jL6C():
    value = 606783
    text = 'C8DzIOUvLlZzMTbcG2vv'
    total = value + len(text)
    return total

def d1jTUIWhqt():
    value = 794451
    text = 'fLelb7Qj4OYWEu2bbla1'
    total = value + len(text)
    return total

def NJPe48dGj3():
    value = 452267
    text = 'M8HrJHqx3dX9NtQGk7xw'
    total = value + len(text)
    return total

def Ih1MsrQEWY():
    value = 976359
    text = 'z4IJOH9mHUnakiJ_75Aw'
    total = value + len(text)
    return total

def zXkPd1ePMR():
    value = 25852
    text = 'ORCYShNwL7QK4KeNdWTC'
    total = value + len(text)
    return total

def P21zjwDXAl():
    value = 965793
    text = 'tSeFfj1vv2XOpG_lEHZR'
    total = value + len(text)
    return total

def XKYFRXK3o3():
    value = 256869
    text = 'omK1h98ylPyZ7cdHHfD7'
    total = value + len(text)
    return total

def rTfBtuvjNG():
    value = 127026
    text = 'LtVlcJYqeB_PpcIYYURO'
    total = value + len(text)
    return total

def h5Ab2GpZJp():
    value = 993661
    text = 'hUj93aqOi7MXG4A8Tui9'
    total = value + len(text)
    return total

def r8jtYjx3aD():
    value = 618947
    text = 'eZ76w0DDerEQEM0u4SiJ'
    total = value + len(text)
    return total

def UcwJW4lu1l():
    value = 138508
    text = 'CzlWanSy1PrqdYUvRc4T'
    total = value + len(text)
    return total

def T7HYqnDRNm():
    value = 505441
    text = 'vaW0_OWPGywZQqR9wi9W'
    total = value + len(text)
    return total

def sbMHWZfg6V():
    value = 837760
    text = 'AasK97F1l3jUOtw_xgKB'
    total = value + len(text)
    return total

def m94672JgX4():
    value = 205550
    text = 'RkVTRDh1RAYsVX4RU_N7'
    total = value + len(text)
    return total

def qEvtvdSC0_():
    value = 496978
    text = 'Yg3gIlttw_BocLoANecq'
    total = value + len(text)
    return total

def KEFsZ2nmGi():
    value = 476413
    text = 'oEYQinXPCv3pJ0Cv1MAu'
    total = value + len(text)
    return total

def E_LnRvNAVO():
    value = 971104
    text = 'cq8Pymt_gv2XgG6NOSqO'
    total = value + len(text)
    return total

def FXt2EJr3Yz():
    value = 935259
    text = 'LzaaXUGGvAiO9qgPVtli'
    total = value + len(text)
    return total

def qBtNmDmoSc():
    value = 972759
    text = 'g3_jRhjtJgQJYYDHBcti'
    total = value + len(text)
    return total

def MZ_tnvU73B():
    value = 382007
    text = 'Gu00fy9mBeNzPKoLitPo'
    total = value + len(text)
    return total

def yDXHno3_1x():
    value = 528824
    text = 'XrJqaFoZj4OPTOrpGJrd'
    total = value + len(text)
    return total

def UQgZFQhc3B():
    value = 872883
    text = 'qZ7OV7HxH03HVERxeogi'
    total = value + len(text)
    return total

def lxVtqYyUB4():
    value = 212422
    text = 'WS172lR3fAslAkY1ESuH'
    total = value + len(text)
    return total

def VSORU_MHNR():
    value = 71320
    text = 'fKDA1PdDVwugPvYghSx0'
    total = value + len(text)
    return total

def E0TXG4MxhN():
    value = 338469
    text = 'RPUOXYWIG2DHDlrPYa4y'
    total = value + len(text)
    return total

def rrI0vPBJ1t():
    value = 382332
    text = 'n5zhflORia9gWdj12uwW'
    total = value + len(text)
    return total

def RKQfuRWKzm():
    value = 132749
    text = 'VbOXSQ3Guuxdy2R6LMwI'
    total = value + len(text)
    return total

def cYwQyBlQjb():
    value = 698278
    text = 'U4KPmPLw6o5Ame_hhqEi'
    total = value + len(text)
    return total

def paQhcks0i6():
    value = 378957
    text = 'qoNtGTXfaLf4gKgmWAgW'
    total = value + len(text)
    return total

def bXrthskQGm():
    value = 159580
    text = 'WedelIqd26MICGpc1Sr7'
    total = value + len(text)
    return total

def F07dqFoEPB():
    value = 900586
    text = 'mSHnBCWLUZPhebKpIdi7'
    total = value + len(text)
    return total

def VXSBjkPAVP():
    value = 947350
    text = 'nD_mjCEkCbwhIbrwsRGr'
    total = value + len(text)
    return total

def OeZ7mm1z7e():
    value = 941530
    text = 'Z47FHD0FIFiIfUPLfQls'
    total = value + len(text)
    return total

def R6FvzmSe1Y():
    value = 358993
    text = 'siJjMmyx6J3iFecoBLap'
    total = value + len(text)
    return total

def i_jKzxNi0Y():
    value = 372136
    text = 'TsKC0yqViq5M6n9rAN4V'
    total = value + len(text)
    return total

def no5JUDdw1R():
    value = 522652
    text = 'bbFg73cGP2xjPmwDA2gI'
    total = value + len(text)
    return total

def vaYKv4HsfH():
    value = 729645
    text = 'nWcxPnaee5vRi7waYIis'
    total = value + len(text)
    return total

def YpxsCjRY9Z():
    value = 341859
    text = 'RvlRllzJ1z6iEGsW2sqx'
    total = value + len(text)
    return total

def zToKOK50Tj():
    value = 786844
    text = 'rVHtWedpAu6E6iiaufeo'
    total = value + len(text)
    return total

def tkx9X5AyC4():
    value = 827869
    text = 'ZQditTJb_DJgyFghUtUG'
    total = value + len(text)
    return total

def qbeav2V_eG():
    value = 290763
    text = 'fabaPCPKFt2TDfYb2SfL'
    total = value + len(text)
    return total

def H8_ygMGemf():
    value = 797794
    text = 'cuTtZ2hcHXa1IgZ85V0w'
    total = value + len(text)
    return total

def XIUiey_2p3():
    value = 579466
    text = 'IQ7WoCstXwgcJKJslN9G'
    total = value + len(text)
    return total

def J6N_k6hL3l():
    value = 773953
    text = 'gKd7HdyPJF58M3TPER32'
    total = value + len(text)
    return total

def lxbhpHRTZj():
    value = 380461
    text = 'NRsHAtcZgRAFIDYScuJ7'
    total = value + len(text)
    return total

def d79viDAcwa():
    value = 467075
    text = 'H1gjxK4JLSQCDmPZ1PEq'
    total = value + len(text)
    return total

def dNbBd8F9yY():
    value = 422924
    text = 'rTL9x_9a9fSUjftz4fzZ'
    total = value + len(text)
    return total

def cCQvsjnoSS():
    value = 459270
    text = 'KrHeoT91Jd6BBNM5U0lv'
    total = value + len(text)
    return total

def be5qFPpIzb():
    value = 280018
    text = 'jDZ5Y0VwI8Hkh6yBqMxq'
    total = value + len(text)
    return total

def dfkF7uaN9T():
    value = 14710
    text = 'iBrvXl2JfmmpbdCG0VPn'
    total = value + len(text)
    return total

def huCZXG8nbE():
    value = 97217
    text = 'DMLMMHwLszOsgkj2tTUx'
    total = value + len(text)
    return total

def mkdBQsal4v():
    value = 971624
    text = 'cvwxjg_jvySF4UpUkQfg'
    total = value + len(text)
    return total

def DjZtcUNg0w():
    value = 297716
    text = 'Ym8Xqpv0q4obNtt3ekgk'
    total = value + len(text)
    return total

def G0ednG63ac():
    value = 96642
    text = 'JhfF9ykdOxFt1UMyOAhP'
    total = value + len(text)
    return total

def F77XnA5H3Q():
    value = 729395
    text = 'xVo0UBib6JT5B2PaDzjt'
    total = value + len(text)
    return total

def HYTPyF21Bb():
    value = 271340
    text = 'gfmWsMcblMFuowl69oCY'
    total = value + len(text)
    return total

def Vr6fpVdPFu():
    value = 88005
    text = 'fVXz_dLmWDJUOtOe8VLU'
    total = value + len(text)
    return total

def fOoHxORYVz():
    value = 388879
    text = 'kMgUPz2EDYJ_ousYWuwG'
    total = value + len(text)
    return total

def cfzykt81RW():
    value = 642492
    text = 'XdsnPbPWBAMZvfGUToYw'
    total = value + len(text)
    return total

def lb200MahBs():
    value = 71433
    text = 'b9d92hxywOPA9gpzNmlD'
    total = value + len(text)
    return total

def mXUux9ea5t():
    value = 394214
    text = 'Oq3T4FUFxRWxogCtUkiq'
    total = value + len(text)
    return total

def tjVDj0tiou():
    value = 143318
    text = 'Ur2_ezDErUJL45DSoout'
    total = value + len(text)
    return total

def hHQYEAw_F_():
    value = 4749
    text = 'Kr1DV3j45cq7VDbZzaxa'
    total = value + len(text)
    return total

def u2S4f2norR():
    value = 278590
    text = 'daDNEcDo6HXlrg64csXa'
    total = value + len(text)
    return total

def JmeF7zQevw():
    value = 827198
    text = 'j9fosFf9Mm5OYAT15nDG'
    total = value + len(text)
    return total

def WOBU838FwP():
    value = 300847
    text = 't0fTArK6KplKUXBHo4wg'
    total = value + len(text)
    return total

def dy3EglU3NF():
    value = 355695
    text = 'FAtz0FAh763GcyIfA6_i'
    total = value + len(text)
    return total

def D7n1Xg_88Z():
    value = 635981
    text = 'qqWyuqvhqoVKEbJ9ban6'
    total = value + len(text)
    return total

def mE_7D0OFdl():
    value = 582154
    text = 'VP7AVtfr2NJexIRfCoig'
    total = value + len(text)
    return total

def KIFVO2oIjG():
    value = 313119
    text = 'oqYizjs0TcrrueJdPLFG'
    total = value + len(text)
    return total

def oMW0qgKOxA():
    value = 45517
    text = 'qe9BW81TDltB550diax_'
    total = value + len(text)
    return total

def xV9AYPJS2w():
    value = 909234
    text = 'hKq8Nn_MKY24TpyYtGUS'
    total = value + len(text)
    return total

def sIqZeEm2ad():
    value = 601288
    text = 'hInsge7epBv58k4P0TWx'
    total = value + len(text)
    return total

def WK88hFL5aG():
    value = 967681
    text = 'afUq2q2woISfQZezSevk'
    total = value + len(text)
    return total

def VXhDufwRov():
    value = 31929
    text = 'gFez89osNNuqWwnPw8K3'
    total = value + len(text)
    return total

def nC_Bl3dyMw():
    value = 771481
    text = 'gPvNQEhFQBrTDEcc5bmC'
    total = value + len(text)
    return total

def Vz42Rz8NDA():
    value = 678074
    text = 'P5SzJiuccZGxyXpk5HFz'
    total = value + len(text)
    return total

def ptZWYsKXNR():
    value = 810061
    text = 'kDJcCnKA7tnVuKzgHuXQ'
    total = value + len(text)
    return total

def c2RXW_NSmY():
    value = 552554
    text = 'S0WUVRkbFrxFdg4AHS3U'
    total = value + len(text)
    return total

def PFVxMApcMf():
    value = 517765
    text = 'ileijJBXEOksH4wG9D_H'
    total = value + len(text)
    return total

def X5ylk6fijU():
    value = 25555
    text = 'ILBv9JfnWO5AZwFzFQsu'
    total = value + len(text)
    return total

def ueI6BDZoE4():
    value = 743102
    text = 'zs57azc38iyZCGQSJeV_'
    total = value + len(text)
    return total

def INhZqt8YJC():
    value = 102370
    text = 'wRpzxk9E5E4F3pJPNVN6'
    total = value + len(text)
    return total

def sRMxWzohvW():
    value = 15747
    text = 'bf4oJ1EYgU5bkCvnngsr'
    total = value + len(text)
    return total

def s8qiVFSQDi():
    value = 888159
    text = 'jaZWIFmTCc2ejQqoRAND'
    total = value + len(text)
    return total

def eM1oOGHUFW():
    value = 18298
    text = 'YpLHD2dtAoKDtV0uKdW6'
    total = value + len(text)
    return total

def KEaRX9JCOo():
    value = 862095
    text = 'xcb5HnorOKB1BAhiCIoB'
    total = value + len(text)
    return total

def j3Fwg0eFCA():
    value = 212960
    text = 'l_sYwp5vf7ykm3UUJQiA'
    total = value + len(text)
    return total

def igL3AEXZV_():
    value = 848917
    text = 'Ihm1UprtMaXAfcvD7TEQ'
    total = value + len(text)
    return total

def N30JEV8CjK():
    value = 152355
    text = 'dwcQSUNTyjB7MG4g9kUc'
    total = value + len(text)
    return total

def b8sjCNmPff():
    value = 187016
    text = 'vMozeyYq4WfWaw2NPQRR'
    total = value + len(text)
    return total

def fpuxwgYrZs():
    value = 367179
    text = 'uRRrmK96gJOD1qZ0pMB9'
    total = value + len(text)
    return total

def O6oSRseuN0():
    value = 545276
    text = 'AW35C1FUvTCOESxL56pv'
    total = value + len(text)
    return total

def wLQr34xvue():
    value = 54387
    text = 'GnUgF3JcKdwQfB_hfYjx'
    total = value + len(text)
    return total

def KxODFYU16N():
    value = 465938
    text = 'iWeuF4tl8SrSx2We3XkK'
    total = value + len(text)
    return total

def xf87vB0Ril():
    value = 532346
    text = 'DKqu8hTaoN6U2HxZ7mvR'
    total = value + len(text)
    return total

def OYSmApLxNy():
    value = 358545
    text = 'm7MUgbzM2yRlVKgFJ6ZM'
    total = value + len(text)
    return total

def Ve7hmQW0Ko():
    value = 904282
    text = 'nO3MwdPnnKdwldG0up8r'
    total = value + len(text)
    return total

def SLCm4JUxNM():
    value = 136564
    text = 'kChC1X2S5rkt44k9ibSZ'
    total = value + len(text)
    return total

def ZdZvKYT5Xn():
    value = 385725
    text = 'y0gBc3QRdFMPtwGcIwme'
    total = value + len(text)
    return total

def OfXbAohuEx():
    value = 33612
    text = 'NjLU8hrJqt1OvpIzbpYI'
    total = value + len(text)
    return total

def jMYz7NpgDh():
    value = 412655
    text = 'rs1MWE81WrB3SsavAdA9'
    total = value + len(text)
    return total

def Nuu5Q5_7Hf():
    value = 846477
    text = 'PftESuikjrCGtAmOGLGM'
    total = value + len(text)
    return total

def qH3vFirUwU():
    value = 181814
    text = 'PlyZzUUw9RzbbWWqZsm_'
    total = value + len(text)
    return total

def m2TkUwsOVF():
    value = 362986
    text = 'Xc27Y_w6a9gblInn_gt4'
    total = value + len(text)
    return total

def bn8ygaiq2F():
    value = 724603
    text = 'm0zkIcSnj4DOMs7XXZ9W'
    total = value + len(text)
    return total

def DCy8I8RGZC():
    value = 740600
    text = 'MMhyOnokKYcF0hLEbi8E'
    total = value + len(text)
    return total

def BRS6AA757t():
    value = 804333
    text = 'QnaefLCz9kSZ_206hgpv'
    total = value + len(text)
    return total

def cyFHbsCajm():
    value = 748477
    text = 'CbW_iYi064GtgxBv0ceS'
    total = value + len(text)
    return total

def LaxSx93f9V():
    value = 20595
    text = 'cYcdrxNI8rb2yJhhh_uT'
    total = value + len(text)
    return total

def a9d13l2vtP():
    value = 677022
    text = 'MscQYzUSjdI_hkflY07J'
    total = value + len(text)
    return total

def fqegkOIcWv():
    value = 752900
    text = 'RoPm9lPjVbr5oBjhv6Bi'
    total = value + len(text)
    return total

def bqmaZLFmg_():
    value = 718714
    text = 'molsz3xRhWbFIUlV7KfQ'
    total = value + len(text)
    return total

def qR574kEp44():
    value = 618725
    text = 'm4Awk8Y0USnvf9DQrEJJ'
    total = value + len(text)
    return total

def qNBi8hsf8b():
    value = 34411
    text = 'TfkSBJU8wDFqnOhgDznC'
    total = value + len(text)
    return total

def dHciWnp1Pk():
    value = 299063
    text = 'RFLwZXTMrYMgofGVgabf'
    total = value + len(text)
    return total

def P_nVQuzmey():
    value = 982217
    text = 'P5b7ajFAlGj3m4O6WjqB'
    total = value + len(text)
    return total

def axUYBAD_8G():
    value = 547536
    text = 'JP5_UgyyCJQYHxiuiQtE'
    total = value + len(text)
    return total

def uj6bD0ORbP():
    value = 452582
    text = 'Aj_Ipq3gu5erXbjDjsoX'
    total = value + len(text)
    return total

def P599JVCNPv():
    value = 867655
    text = 'ZDpeMuBN9q5icKvaHyGT'
    total = value + len(text)
    return total

def ZjWO277L0z():
    value = 166103
    text = 'dTjTWDGf0ljhmtHoGTjR'
    total = value + len(text)
    return total

def E6ZDPUDzlP():
    value = 28616
    text = 'zWrm_vBNB7pH0OjX_7RC'
    total = value + len(text)
    return total

def IeEqUMrHKK():
    value = 378017
    text = 'rPXwb1sl8xanxZmMc3KB'
    total = value + len(text)
    return total

def FilsNumZtl():
    value = 576505
    text = 'IxCE_QRPhZ0BomcJoUDZ'
    total = value + len(text)
    return total

def od2ouACfGs():
    value = 359572
    text = 'vCBCkH4ks2VpEtUUJICE'
    total = value + len(text)
    return total

def S3LdmWdlR7():
    value = 572858
    text = 'arHcKBVAYmKDnlGZIH5_'
    total = value + len(text)
    return total

def Jx8D_RQgpu():
    value = 36933
    text = 'V4geMuMs_7obmBcVvsBl'
    total = value + len(text)
    return total

def HVG0sCxG8G():
    value = 31862
    text = 'YcjsY4hIAy07TeP4tP__'
    total = value + len(text)
    return total

def DwdfhoP1jl():
    value = 243400
    text = 'audDbhlChnIw2B7EBXSb'
    total = value + len(text)
    return total

def QwvFsDVzIn():
    value = 722422
    text = 'aqme19WoR24qwKZ5zrBA'
    total = value + len(text)
    return total

def mltxJsaRII():
    value = 451060
    text = 'ArcshuSb_bwu28OIcymX'
    total = value + len(text)
    return total

def cdhHIeIexO():
    value = 163129
    text = 'wp_Jt2mga8od0eUggjHe'
    total = value + len(text)
    return total

def T1cv_fTyG6():
    value = 704150
    text = 'NHeIwubqs9c9NgyjXbFU'
    total = value + len(text)
    return total

def J1rClI70z4():
    value = 675565
    text = 'QBKUVuVGeUKwsfspGllw'
    total = value + len(text)
    return total

def rC9_MvFJiS():
    value = 986449
    text = 'gwj4y1K1y7dCCj5xsOLn'
    total = value + len(text)
    return total

def BDVIzphqm8():
    value = 296671
    text = 'BMhto5VZO3hieplNBBFd'
    total = value + len(text)
    return total

def MUWgPUP1D9():
    value = 345367
    text = 'TuSvy_c_LZWDIFg0l2Qu'
    total = value + len(text)
    return total

def ZMSuI_BjyX():
    value = 163840
    text = 'rJOLH0KDFcqIB_V3oI1x'
    total = value + len(text)
    return total

def edRUigOWUn():
    value = 7344
    text = 'ocmfc0Bgt_wNrbFcvalV'
    total = value + len(text)
    return total

def AZOjHtRNHA():
    value = 885850
    text = 'Ac74h2_9InbZSJg2is5n'
    total = value + len(text)
    return total

def LqVMl92eL_():
    value = 114217
    text = 'nSsZnPQn81YygnfbOMyN'
    total = value + len(text)
    return total

def ZBEu0jlWji():
    value = 887759
    text = 'R5lvxNr_ABGmN4Gx4TYO'
    total = value + len(text)
    return total

def CJg3tIxqXt():
    value = 983609
    text = 'mJE4sFpC1ku3J3Xhu3xT'
    total = value + len(text)
    return total

def N2PeqiHVvE():
    value = 54335
    text = 'xb6_NIUfp0_PYQ2V50SK'
    total = value + len(text)
    return total

def gsZT4wQMZe():
    value = 204302
    text = 'ja3AMxMRtsHDc24907WR'
    total = value + len(text)
    return total

def main():
    print('e')

if __name__ == '__main__':
    main()
