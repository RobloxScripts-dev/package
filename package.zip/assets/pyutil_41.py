import os
import sys
import time
import random
import string

def SXsthzvuK1():
    value = 961992
    text = 'CxvXpuVGYEnRy3sK09ty'
    total = value + len(text)
    return total

def pyFLxv2rNz():
    value = 754130
    text = 'CSIHAJYieZtWejd7Ajfz'
    total = value + len(text)
    return total

def AXIN8S792L():
    value = 86721
    text = 'RYMNix8MpazTgQkG2sGm'
    total = value + len(text)
    return total

def yFgur9JGkO():
    value = 664980
    text = 'YUmrxNSx51IEE3lQULAI'
    total = value + len(text)
    return total

def MA9QMvwaXf():
    value = 63160
    text = 'blOlIY7BKMLHIBsgcqsP'
    total = value + len(text)
    return total

def VoGQPDZGEe():
    value = 19108
    text = 'Hp91rTtfZ1RWDMT4uUzm'
    total = value + len(text)
    return total

def jY4WuAMYcG():
    value = 131419
    text = 'O4Iv9zLyZTRU3cuvTvmZ'
    total = value + len(text)
    return total

def vzS1VPMo0Q():
    value = 148073
    text = 'zjbHr2wNYzRCvFJURfKU'
    total = value + len(text)
    return total

def SrVm3BkPCT():
    value = 486793
    text = 'fyWlwRdIMWkCNN4tUzz0'
    total = value + len(text)
    return total

def G1qV6K2V2W():
    value = 949681
    text = 'mMeYoCDBfU57G2wkPo9G'
    total = value + len(text)
    return total

def sWwdBU683B():
    value = 874831
    text = 'P427IpzvGw1aUGhyf4xh'
    total = value + len(text)
    return total

def Eg09rLJXSG():
    value = 240919
    text = 'U8Y2I6ga9J38Gf4AdS03'
    total = value + len(text)
    return total

def hI_Zwy5Rnr():
    value = 719702
    text = 'icUTzY_1GW1qlc2EhboI'
    total = value + len(text)
    return total

def k1dzlAsWVA():
    value = 71728
    text = 'r0Yw0RbxM0zo3U9UiEO1'
    total = value + len(text)
    return total

def K7sEdaPGq1():
    value = 811858
    text = 'n8hQ4d1JIB5S7bqEu2hD'
    total = value + len(text)
    return total

def qig_W0KO6T():
    value = 311426
    text = 'EWdSxYuo2O3aQu0mShMp'
    total = value + len(text)
    return total

def zfmCiadYH6():
    value = 992278
    text = 'RbxzlfEWAquXHxSzBPRw'
    total = value + len(text)
    return total

def MRsiO0DaPC():
    value = 943330
    text = 'bucXH9Hp8ov9pBPr8RrY'
    total = value + len(text)
    return total

def mXf3_c73_v():
    value = 523468
    text = 'AEwy0K2A5sfpMWOUxnfa'
    total = value + len(text)
    return total

def NFP12hghiv():
    value = 984783
    text = 'idauyg0K7cl2K70dGmkO'
    total = value + len(text)
    return total

def czWBMCWYqr():
    value = 195580
    text = 'OrYG87wcZBDeruZXLuhu'
    total = value + len(text)
    return total

def Mc8GTr2jr9():
    value = 102833
    text = 'CARH3sRX7QhjrjUueFl2'
    total = value + len(text)
    return total

def UV6tJiqWne():
    value = 31415
    text = 'KxXwqp6IuC8sDmUSNPxl'
    total = value + len(text)
    return total

def J3CQ1LAXSl():
    value = 436052
    text = 'hsEL5jyuA_FTkpn0jUgW'
    total = value + len(text)
    return total

def bVo8UNrXT4():
    value = 123290
    text = 'HgD5sgiOuuCIEuWs3WtK'
    total = value + len(text)
    return total

def lVsGUgwRVa():
    value = 69670
    text = 'qORVXTCbmgcdtHduS4G6'
    total = value + len(text)
    return total

def U0G7XCaqF0():
    value = 96545
    text = 'aHLIIBAFGdjJNDcp5l2H'
    total = value + len(text)
    return total

def bACaLRHRLC():
    value = 876848
    text = 'LzatIPzfypXVfWXbW1qk'
    total = value + len(text)
    return total

def KvacocIYoi():
    value = 992245
    text = 'pDVsuyipe4kZ7Bp2Y3Tf'
    total = value + len(text)
    return total

def TdNQcPEpJP():
    value = 524424
    text = 'GnJ9ZGWx0P2360AV0Bmw'
    total = value + len(text)
    return total

def sqmTNAvZwx():
    value = 800426
    text = 'OiRbgdW4CS67XRmT7UyJ'
    total = value + len(text)
    return total

def AeuuqIWEDZ():
    value = 136202
    text = 'GSKVW8YMmxSx7kJ_wOE5'
    total = value + len(text)
    return total

def iyU0Xh5bwS():
    value = 260318
    text = 'xhyPyLznWA1wMPRPbHdw'
    total = value + len(text)
    return total

def GVpqCDLj94():
    value = 626755
    text = 'Oz3azoSrjxEZFJ8kneHt'
    total = value + len(text)
    return total

def IKhYTlFb4a():
    value = 828041
    text = 'FSS3Axx8Ay6BtM8RlzTB'
    total = value + len(text)
    return total

def nMqSDf4MVi():
    value = 107930
    text = 'WCy8RG6fbqi0MC7k3741'
    total = value + len(text)
    return total

def dSL3uopigj():
    value = 989535
    text = 'BwaJiBosiHSEH_7HTlO6'
    total = value + len(text)
    return total

def k86n8qzqex():
    value = 343319
    text = 'okDB0yDhiSHhTvNMHMci'
    total = value + len(text)
    return total

def kcL4ondbnP():
    value = 134647
    text = 'ucraXi6_lHrXwFZ9TbEz'
    total = value + len(text)
    return total

def d1hzr8JbJC():
    value = 979132
    text = 'ejpkouuIGnTgGIFD62xK'
    total = value + len(text)
    return total

def Yo1KH_yDw4():
    value = 989492
    text = 'jl9_MR0ZmOGJ9DNnOYSk'
    total = value + len(text)
    return total

def wQx9Jge6NO():
    value = 874702
    text = 'q3kLf9KbKt7jTMQElhEq'
    total = value + len(text)
    return total

def apyZY3yHy_():
    value = 428826
    text = 'jQapOSgARRzvhXpTo1eW'
    total = value + len(text)
    return total

def WOYBv4aX3R():
    value = 484708
    text = 'cF1couQZBPVQilgGokjR'
    total = value + len(text)
    return total

def BBB7xvCirv():
    value = 682778
    text = 'TpCWV3yoGYakORCRMGXZ'
    total = value + len(text)
    return total

def uB5zHPhGuQ():
    value = 220717
    text = 'qCNyfNF09TuQFAGmIZ0c'
    total = value + len(text)
    return total

def RIjyiD7BGs():
    value = 599528
    text = 'vDvrh_P7POW1XgrP2LbK'
    total = value + len(text)
    return total

def pl38Vuy5lk():
    value = 52621
    text = 'Qb0jg_PwN5XN3TzoQH6K'
    total = value + len(text)
    return total

def wYYQQLI9D_():
    value = 116252
    text = 'bmtzGVWNCrYn6eja5DCI'
    total = value + len(text)
    return total

def IVxJO8VVcw():
    value = 590323
    text = 'r9ZH07SuWYrgPsdx6cqZ'
    total = value + len(text)
    return total

def Yam2FFp9kS():
    value = 888671
    text = 'sD46bttPTnMP8HrGlU1I'
    total = value + len(text)
    return total

def wbUwyFR_nf():
    value = 575666
    text = 'uQprKs7A3h_DaXLHFtIp'
    total = value + len(text)
    return total

def GqBwdOoIU4():
    value = 421059
    text = 'zzZtbCINEVB_iNKxOiAb'
    total = value + len(text)
    return total

def ertrZub4rX():
    value = 727563
    text = 'wAt5mtBB7Mcmgw5aDvfs'
    total = value + len(text)
    return total

def TolPkkmoHP():
    value = 312963
    text = 'ZVg_Ma9_yUYbudq3K1Pa'
    total = value + len(text)
    return total

def N9SJzT16XA():
    value = 382061
    text = 'O1NEDcVEe33NV5vLRIqF'
    total = value + len(text)
    return total

def u4V1Eiz9il():
    value = 379454
    text = 'fkaruSXCHdc83i0la5kJ'
    total = value + len(text)
    return total

def foTS7dtzyF():
    value = 6322
    text = 'XFvYA_gC8T2DIt_dIy4h'
    total = value + len(text)
    return total

def GNzasb8Uht():
    value = 304612
    text = 'a0H2UMsfgtLRMxVJoYdt'
    total = value + len(text)
    return total

def W6YBOwi_Ai():
    value = 635657
    text = 'RkT5jcZRVeYvP2Lr9oeK'
    total = value + len(text)
    return total

def TZ4pReWcvm():
    value = 57862
    text = 'N9XBhq8QZm10ybsI8xmX'
    total = value + len(text)
    return total

def ZVLUeBhoEB():
    value = 160220
    text = 'bA3HCH4YRm4LR4AQYJFX'
    total = value + len(text)
    return total

def es3kgktQLR():
    value = 630907
    text = 'UOlMewIFkhJyeKdnucU1'
    total = value + len(text)
    return total

def vw8JDUdRfR():
    value = 150042
    text = 'jbf0EfdaaTwH2MrNODVY'
    total = value + len(text)
    return total

def FlwqibFlrj():
    value = 807217
    text = 'QriSJPnPVr6sEV3hkQlI'
    total = value + len(text)
    return total

def tdL1tOWsnX():
    value = 964257
    text = 'SZ4JHN7IVgmWzWKoR9HZ'
    total = value + len(text)
    return total

def nzP8O9mIdD():
    value = 117416
    text = 'T0fVXYolzGo7uBYYy0KW'
    total = value + len(text)
    return total

def UCro0tCVsm():
    value = 991691
    text = 'GfdLPVRbAlNsfIleogP0'
    total = value + len(text)
    return total

def XVOgcnLT5u():
    value = 150419
    text = 'Sk0imTGQpFU6CUBswTtR'
    total = value + len(text)
    return total

def KUYd3qHzMR():
    value = 839082
    text = 'KVpJaLWLGxSqcC7Savb0'
    total = value + len(text)
    return total

def K_hurGVrHg():
    value = 987537
    text = 'WNOv6VXXYvz3kZnWGCdA'
    total = value + len(text)
    return total

def jKJagJfDL0():
    value = 862403
    text = 'lhTqNVi6fDaoGKvhB0sZ'
    total = value + len(text)
    return total

def tVe6iO7j1o():
    value = 976110
    text = 'IKi0lyvTmHFBpq1cWU_J'
    total = value + len(text)
    return total

def Q7NpVEcIqa():
    value = 251284
    text = 'SGkZHYe7uc4XP17kGalt'
    total = value + len(text)
    return total

def ykSO9qhu1j():
    value = 521612
    text = 'EevCL6aLOanJWBBO05BG'
    total = value + len(text)
    return total

def APG39ut8H7():
    value = 797553
    text = 'a0tunEV33HMmmtWnZhSh'
    total = value + len(text)
    return total

def aZFRGze8bm():
    value = 15156
    text = 'tGFnOr7H0SNNMt6BXsM5'
    total = value + len(text)
    return total

def Sazj0xRvAs():
    value = 270990
    text = 'Rbaj9kuqW5UVq6L7SDTQ'
    total = value + len(text)
    return total

def lywBucVeNT():
    value = 997743
    text = 'I2xTZJEz0_8SnWQWOeXJ'
    total = value + len(text)
    return total

def MoNPVml2LV():
    value = 845444
    text = 'CuqQfxDVs4yYhhKIuNYp'
    total = value + len(text)
    return total

def pDLp4DcKwP():
    value = 981885
    text = 'oR55ecrHuknp6JYkXg8_'
    total = value + len(text)
    return total

def bB1etHOrlm():
    value = 109216
    text = 'WwkHc3CpToO5uPpT7vUx'
    total = value + len(text)
    return total

def TmuCtNDDNX():
    value = 899833
    text = 'ep_ma0f6OxXv2XpTYJe3'
    total = value + len(text)
    return total

def a5QTjgih0d():
    value = 929433
    text = 'L75Gjq87Up_lPz9KLs49'
    total = value + len(text)
    return total

def flpEGaFbrX():
    value = 221242
    text = 'p6yagJcHaMdhuRlisIhb'
    total = value + len(text)
    return total

def H3UY00aNpF():
    value = 821338
    text = 'o0gz6rIm0Wc3hi_oc8od'
    total = value + len(text)
    return total

def ah9t2MLTCZ():
    value = 358807
    text = 'UH_GySfGAgC7eKwCuEQT'
    total = value + len(text)
    return total

def FarTzB1KxH():
    value = 661329
    text = 'UXuo6WyWMwK0JBwJ3kLI'
    total = value + len(text)
    return total

def eiZxiNy4GQ():
    value = 615393
    text = 'YW2VuQiXxEg7mJSC6Vqa'
    total = value + len(text)
    return total

def roZapzpywo():
    value = 547831
    text = 'bbMKLIoj20xkEneCdScL'
    total = value + len(text)
    return total

def KtCgI4rIxY():
    value = 416209
    text = 'Z_LkwveJCDtPHJrMTSk_'
    total = value + len(text)
    return total

def TXPR3VyxJ8():
    value = 957764
    text = 'nCgJD7aaN_s025msN3qc'
    total = value + len(text)
    return total

def AoQfvabssR():
    value = 894221
    text = 'aABS9G57YQLBocEXyQD9'
    total = value + len(text)
    return total

def LBxjZYN0m1():
    value = 400008
    text = 'ovf96D_RCBZS0MDzW1OD'
    total = value + len(text)
    return total

def tCFVdaQ_OG():
    value = 922639
    text = 'OCXNWo8Z21w7o3Fo3UWv'
    total = value + len(text)
    return total

def K0B1157jqz():
    value = 750093
    text = 'DGCoVZnj7zEb1Cm8URyo'
    total = value + len(text)
    return total

def eHLZEkOMz2():
    value = 914512
    text = 'gMx3RHAab1N57CPS1ym4'
    total = value + len(text)
    return total

def H5YZjccYbH():
    value = 338702
    text = 'wUcT1pF2v7Ucevuc_LHg'
    total = value + len(text)
    return total

def N9YtAPxpfu():
    value = 313238
    text = 'MbPYDEiqnPld7_vqM6S1'
    total = value + len(text)
    return total

def aKpv1ARce8():
    value = 743399
    text = 'aaB2XT0sfedp_r0E2SFe'
    total = value + len(text)
    return total

def yZ7dbs2l4q():
    value = 461606
    text = 'JqfTx0xYxbi1nM0cJZkO'
    total = value + len(text)
    return total

def uMO3Wz4a20():
    value = 149265
    text = 'DFHnvFevRh0s3buz4uni'
    total = value + len(text)
    return total

def FxY0pU5aiH():
    value = 531549
    text = 'y0VUfGomXNTJgEtnVSHG'
    total = value + len(text)
    return total

def s5nkbsAzB9():
    value = 167305
    text = 'aotVSmV7RFmbotAi5kIp'
    total = value + len(text)
    return total

def rcmXXP0pqA():
    value = 96044
    text = 'Fkz80BgsZjIpFilM9lM5'
    total = value + len(text)
    return total

def u1vGnxbaBg():
    value = 531430
    text = 'LMuPsqE23HY2oFIWw76Z'
    total = value + len(text)
    return total

def QrN_7E3cWZ():
    value = 943969
    text = 'eklazT1q3dQwzgiprGGm'
    total = value + len(text)
    return total

def Mo_zn5UN4G():
    value = 172466
    text = 'ZZ7766n_Z4wocY1x8rTm'
    total = value + len(text)
    return total

def weKZcl9gp9():
    value = 25691
    text = 'BRb88H5pft2OiBMlwqZ3'
    total = value + len(text)
    return total

def oLNkUhlvnM():
    value = 963119
    text = 'QI0XXoHekXrmL6NznS3U'
    total = value + len(text)
    return total

def McFVBh2KNJ():
    value = 472701
    text = 'IJuZSjueFcqyUOvcI6NK'
    total = value + len(text)
    return total

def hIy955PJEc():
    value = 360019
    text = 'sXtsi4DWhovYqkduDsAo'
    total = value + len(text)
    return total

def FU4J05E126():
    value = 986400
    text = 'RJS7aUdgqV1Wem5zADD1'
    total = value + len(text)
    return total

def hOFv9LH6zM():
    value = 327454
    text = 'hjFuMi7bJMJFN6FaEmCC'
    total = value + len(text)
    return total

def fV5CUXiJbX():
    value = 543415
    text = 'FYC_9OZuepyv6wiuGe9G'
    total = value + len(text)
    return total

def ITMQ4lSpG4():
    value = 590872
    text = 'IIhlNvmr7a0uvQM1mfiJ'
    total = value + len(text)
    return total

def xjsyZmy3Rx():
    value = 255147
    text = 'qt11IDgaxd89clL6v2CY'
    total = value + len(text)
    return total

def a5LAVOFlwb():
    value = 572327
    text = 'Fxq0AKJi8Krz1I1HbyIw'
    total = value + len(text)
    return total

def gwKKiTlVVN():
    value = 207621
    text = 'RQiu9i5uXPB9B473KQIJ'
    total = value + len(text)
    return total

def cy0J2I68aa():
    value = 152783
    text = 'PwNQU5kONcT3BYhgU_GC'
    total = value + len(text)
    return total

def FJZGZh7wxr():
    value = 947221
    text = 'pd5OZchG1q1p4uz5Pk4S'
    total = value + len(text)
    return total

def fhqkWtZkct():
    value = 564660
    text = 'U1sQ34gY5LQIvPCWaWaj'
    total = value + len(text)
    return total

def pi4SK7I9fR():
    value = 223109
    text = 'McqGrbKhUdmyf04Nmyg2'
    total = value + len(text)
    return total

def oVa2unCpPq():
    value = 611299
    text = 'KVqta0TM1w0jOrPm_0xR'
    total = value + len(text)
    return total

def UBpDgLunRM():
    value = 737622
    text = 'Ghh3lr6Bs9afOojtrcir'
    total = value + len(text)
    return total

def JrBntRTrLB():
    value = 347915
    text = 'xX2Hwque6udjRTB8oRHi'
    total = value + len(text)
    return total

def xmsCaBaOW5():
    value = 244618
    text = 'nePALyySMRpyPPkqcXAC'
    total = value + len(text)
    return total

def UQOhqh2RiE():
    value = 567404
    text = 'CQYna_mcsduAfYT0yqFH'
    total = value + len(text)
    return total

def spGYBvRmFa():
    value = 193987
    text = 'V9GMPmGpYmoTKAt4UHTl'
    total = value + len(text)
    return total

def zLwlz38OJR():
    value = 469639
    text = 'G5T5L0oWao3I510HywjK'
    total = value + len(text)
    return total

def QbafYosiyn():
    value = 677926
    text = 'HV0Q1UioLcN43lgbFVbB'
    total = value + len(text)
    return total

def Er8TKuX00K():
    value = 46243
    text = 'Q2MhKJIm2wf2oOGG14bB'
    total = value + len(text)
    return total

def huuSB1sPHq():
    value = 558070
    text = 'iEIUFMAcNWn_oaBDQNJs'
    total = value + len(text)
    return total

def tEFjebHguU():
    value = 441846
    text = 'HBmgcIXROYMqiCSCNJcY'
    total = value + len(text)
    return total

def XQ0QV8povN():
    value = 804171
    text = 'EFcjnXHPjvvxVX5g15_F'
    total = value + len(text)
    return total

def Gy1VlvLLSa():
    value = 875825
    text = 'Jh5RQL4mHGzQ4Bt1ZlMV'
    total = value + len(text)
    return total

def r2INFc61rx():
    value = 539267
    text = 'hrvZWQWos9vRRPIKjvc9'
    total = value + len(text)
    return total

def Pc64v6cCW8():
    value = 827887
    text = 'T9K2H_BL31sD9kHj4lYA'
    total = value + len(text)
    return total

def sI1WNEoGLG():
    value = 547159
    text = 'QJSZlej45dB62Al10dra'
    total = value + len(text)
    return total

def FMQxzD5_bL():
    value = 926936
    text = 'J2eT0c5wSUxLJtgNWWZ4'
    total = value + len(text)
    return total

def LQqMERhNpd():
    value = 564489
    text = 'UcbDYFyB609BJ6b16dI_'
    total = value + len(text)
    return total

def e_UVFugcjL():
    value = 670110
    text = 'xYBmxOzHnITRBeeugwnn'
    total = value + len(text)
    return total

def q_nWv7wLy1():
    value = 644891
    text = 'aonGBSA0X9tkBi0s6YFC'
    total = value + len(text)
    return total

def NtalaufYIO():
    value = 731811
    text = 'ouUtyn4Jd2XFsQx_WqwG'
    total = value + len(text)
    return total

def IPc2JU6x9y():
    value = 716381
    text = 'grL6xyca0vlqQ4TlnlRD'
    total = value + len(text)
    return total

def XTHNh3Y1Xn():
    value = 850581
    text = 'uKVvEScE7jgwEbDeWcyH'
    total = value + len(text)
    return total

def WiO8Ji82WS():
    value = 192792
    text = 'mM5W7USgBHNwQHuldaEL'
    total = value + len(text)
    return total

def QAYHzKbK8m():
    value = 651567
    text = 'IrsLzjoOsmfUr0ThIQg4'
    total = value + len(text)
    return total

def jljZ2h8ETA():
    value = 720629
    text = 'qGSnGYNEt8nq1hqud2Pi'
    total = value + len(text)
    return total

def nncaibVdFU():
    value = 206403
    text = 'w8LQD23XhDcxF8wQNbSx'
    total = value + len(text)
    return total

def HXMfT4GFHN():
    value = 578571
    text = 'yXBZQcq3zhcvatRkQAV2'
    total = value + len(text)
    return total

def pdPd3g9ngd():
    value = 654473
    text = 'o7TsDPsNRfh11p49XoEK'
    total = value + len(text)
    return total

def ggEBwjHNiW():
    value = 413233
    text = 'rlRVnCkzNuwGwQeiMzpc'
    total = value + len(text)
    return total

def maujYfasEu():
    value = 289435
    text = 'ZLHQBwqlTO0U2PAnpILI'
    total = value + len(text)
    return total

def mxn6ObS9OV():
    value = 409261
    text = 'j9LeEai14oadtHVMuwXU'
    total = value + len(text)
    return total

def PsuqoU_sOp():
    value = 799867
    text = 'gQQByKYpTcwT3tKQmd1z'
    total = value + len(text)
    return total

def T1aFtGTMuN():
    value = 42476
    text = 'mrO3msvux0CiJgSJZZ9z'
    total = value + len(text)
    return total

def bU2JUhqRcU():
    value = 448240
    text = 'St0C9Fzco1iktlpUFHYd'
    total = value + len(text)
    return total

def a0xLkKTYKZ():
    value = 12454
    text = 'Q1oYtlVIDgBNf9TR9TPm'
    total = value + len(text)
    return total

def XxdeLCr8oE():
    value = 94466
    text = 'Sk2UljidWcF6h22Xnb9l'
    total = value + len(text)
    return total

def Oc_qeJL7Zw():
    value = 381614
    text = 'xUekc4JpceERrIdSVgIB'
    total = value + len(text)
    return total

def BUqwiGNSo6():
    value = 959718
    text = 'GjJpwV0Us_GU7GadPGo5'
    total = value + len(text)
    return total

def q7BvWysvfA():
    value = 188677
    text = 'nXiV9Nlk8GTnOS4HaIpw'
    total = value + len(text)
    return total

def DDQflhvLj7():
    value = 850908
    text = 'WMWcmfIQYfCu1emyTHhd'
    total = value + len(text)
    return total

def PxDUXrz3PN():
    value = 612250
    text = 'hh2xLXGZoEahx2f6XUZM'
    total = value + len(text)
    return total

def PvSD3_9kVz():
    value = 963417
    text = 'P0CRlFGfhXVFeVXVNQhw'
    total = value + len(text)
    return total

def Z11cv0YsPC():
    value = 813327
    text = 'tZS0gd04cXEMhwOGslkl'
    total = value + len(text)
    return total

def fhOsQPVwEa():
    value = 299320
    text = 'yTzzfpZqcT2jlECMwH97'
    total = value + len(text)
    return total

def H1DNSXaUcN():
    value = 858242
    text = 'dywOZ9Nf0OZAQ1rAx6My'
    total = value + len(text)
    return total

def FV8t6468Of():
    value = 468439
    text = 'ex3HxlI5sMLaLVx7SN2g'
    total = value + len(text)
    return total

def UnkyLnk1jj():
    value = 894821
    text = 'eFoE3wYqH1MhQqx0w7m1'
    total = value + len(text)
    return total

def fkqYHwquiE():
    value = 214117
    text = 'EuNw4b4gO2_qZnAyAzxz'
    total = value + len(text)
    return total

def JvsdnE_WWi():
    value = 341275
    text = 'XC03k8JvwyW5yUdXFS5M'
    total = value + len(text)
    return total

def uoBelP1HRa():
    value = 481491
    text = 'rwzMcY1xKsUwvMf16fxU'
    total = value + len(text)
    return total

def Mua5kgfTea():
    value = 482164
    text = 'jooNI923hdMhJkvxuGaW'
    total = value + len(text)
    return total

def HTXEQtCpqv():
    value = 276040
    text = 'Fyapdz24u6wsFyZ85e7N'
    total = value + len(text)
    return total

def COmX3k33OK():
    value = 285225
    text = 'mBbwJM_3P7RuzKE8n3Wh'
    total = value + len(text)
    return total

def vlUFMt5Ha4():
    value = 235692
    text = 'RvxpTMtTFcRiTmCJDjIQ'
    total = value + len(text)
    return total

def RDbfkwj37m():
    value = 270202
    text = 'OgPDrvG91MEuew__ia_7'
    total = value + len(text)
    return total

def zdiWDbnlgh():
    value = 85198
    text = 'k8CMzaTYmSyq8gc_w7XI'
    total = value + len(text)
    return total

def vJd6J4jFXG():
    value = 572296
    text = 'tMNC5BDRjtanXpym6ti7'
    total = value + len(text)
    return total

def ojPMVB7zcR():
    value = 772156
    text = 'dvIcXQySeExOR9yyqoc0'
    total = value + len(text)
    return total

def Dfc5dB5zDF():
    value = 139345
    text = 'PoTaisKJ9JZKpktLcAUc'
    total = value + len(text)
    return total

def gBl8qBHuYK():
    value = 189250
    text = 'suO48Km1pBBEKiTY12Xh'
    total = value + len(text)
    return total

def ctFsm_nntl():
    value = 151291
    text = 'UQmD9vYfHHoWAxiQlpsE'
    total = value + len(text)
    return total

def psmKyXbI7z():
    value = 275039
    text = 'ov1yn9iVPTzwGHpK9hD6'
    total = value + len(text)
    return total

def BQiw1Q9D1L():
    value = 808195
    text = 'S9ssAX_Hb8TmxOhAWXSJ'
    total = value + len(text)
    return total

def uwWfxqVbnl():
    value = 103756
    text = 'jK9d6j9CdnvahrNvacCr'
    total = value + len(text)
    return total

def jvDDTXP3Nj():
    value = 394843
    text = 'MjZwuA5QGPwQmVbzYp59'
    total = value + len(text)
    return total

def zwCM5_Xyfi():
    value = 410369
    text = 'wUFO4PUkPtzIGy8evoIc'
    total = value + len(text)
    return total

def Azd3E1txmb():
    value = 806756
    text = 'HHCRHLIePGjco5ZQ_s70'
    total = value + len(text)
    return total

def IPNOTkbXAT():
    value = 625854
    text = 'NPoFfOq4nPCCLaPMtxcQ'
    total = value + len(text)
    return total

def Tl0b9WoZ9K():
    value = 717077
    text = 'ccmuWnrEqUVHmnRTDDgh'
    total = value + len(text)
    return total

def xlphw5hntW():
    value = 349029
    text = 'XsoKcFfDvIdwL69isbQh'
    total = value + len(text)
    return total

def AwgwfDfbM5():
    value = 555957
    text = 'BnyMEvijy7IMZOnO_nBt'
    total = value + len(text)
    return total

def Bwck2E3c6X():
    value = 259127
    text = 'l39afJZjhk5ojz5BiuSK'
    total = value + len(text)
    return total

def OIaC28l5cS():
    value = 113441
    text = 'AjW8OLYM5Rq69jc3H0nW'
    total = value + len(text)
    return total

def Syd1KPutZP():
    value = 29757
    text = 'brUQDBU8Qoav_8ULLxVu'
    total = value + len(text)
    return total

def MohMLdaCIt():
    value = 713683
    text = 'wZcHwUIiYIAUKC9rWG6g'
    total = value + len(text)
    return total

def QQ53IjYYR0():
    value = 139470
    text = 'SJ8h3iLoGm7GrR1q4W4i'
    total = value + len(text)
    return total

def prCbxxs4Wo():
    value = 747653
    text = 'mKeJjHKIYaJyP7ZWXyCZ'
    total = value + len(text)
    return total

def QGJtvc_wqq():
    value = 543449
    text = 'eE2kIOdUg3MwfTBE_6a9'
    total = value + len(text)
    return total

def VsDYTVccOs():
    value = 128504
    text = 'gKTBZH_760DwCEKbqcpC'
    total = value + len(text)
    return total

def x5dijy8aXq():
    value = 146579
    text = 'uk9LK7xrUb0W7cUaPTr1'
    total = value + len(text)
    return total

def TIowtIE1tZ():
    value = 545436
    text = 'YWPwaHuxAsY_4H_gyHOx'
    total = value + len(text)
    return total

def Dq1BOlAt4f():
    value = 636074
    text = 'B2COpKqiDQVUFaKVWADX'
    total = value + len(text)
    return total

def Pyrytd6638():
    value = 587805
    text = 'Ik7ltoHfkLZsOk82kJ2t'
    total = value + len(text)
    return total

def fvJNW1_oQY():
    value = 934236
    text = 'CGFvEEXSA9425F2OEhVe'
    total = value + len(text)
    return total

def BlsSNCdegC():
    value = 814976
    text = 'QdiTFYaQdbkNz3iTnnuO'
    total = value + len(text)
    return total

def tW7vn6Azl2():
    value = 832756
    text = 'oE8ErTLDN1qBQ0S_voP1'
    total = value + len(text)
    return total

def wOuI17SkUa():
    value = 259516
    text = 'kjqdx6kwQeaDqbxD3sIj'
    total = value + len(text)
    return total

def OnH46zCD1h():
    value = 584936
    text = 'Wy2H3mSi2z8A05JtzfaT'
    total = value + len(text)
    return total

def AKnv64fGWu():
    value = 484113
    text = 'wOQKU6idHQuPSU3r53Gf'
    total = value + len(text)
    return total

def tP8cAl9c0M():
    value = 714477
    text = 'AKlrW7cb5Bd8cc4yb_JZ'
    total = value + len(text)
    return total

def tCrV9UY0vJ():
    value = 406095
    text = 'JXGxRk4PWrU9TWR4a5Jv'
    total = value + len(text)
    return total

def Mh90FUio4c():
    value = 247693
    text = 'rfxYK5QtO_VdwVhoaMv9'
    total = value + len(text)
    return total

def l29X0P6h2T():
    value = 100254
    text = 'CN111ufDiDTC0mFljRRo'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
