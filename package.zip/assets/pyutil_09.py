import os
import sys
import time
import random
import string

def JRHmfWmQVD():
    value = 917280
    text = 'lmGl1IY9IcjcTWLpBdAI'
    total = value + len(text)
    return total

def sBjX8UyfhP():
    value = 222826
    text = 'nOBflpmBMNM2yfnRolgh'
    total = value + len(text)
    return total

def eKzmSqiFa9():
    value = 869548
    text = 'hLgqtfY8H0x2LUQ0SW98'
    total = value + len(text)
    return total

def nVN5CY0ah4():
    value = 572367
    text = 'JSksvBUcEUkymbftQfy7'
    total = value + len(text)
    return total

def upDafPLiOy():
    value = 96075
    text = 'ovQ1NTHNY8LjwdzYTiGK'
    total = value + len(text)
    return total

def NGFAoVIDiO():
    value = 748047
    text = 'wHv0lWtPCUXdAa_hxtNM'
    total = value + len(text)
    return total

def mDtKFHXCGW():
    value = 317485
    text = 'yUk4BleaS44X0zRR_lQ4'
    total = value + len(text)
    return total

def EJcYvOPdLp():
    value = 755763
    text = 'chDSJvmuqebuCTrdjwxn'
    total = value + len(text)
    return total

def cpi4HUhOcS():
    value = 369944
    text = 'zBdgIKKqqhwMf4Rq3gGv'
    total = value + len(text)
    return total

def Qh4LciENw5():
    value = 359640
    text = 'qRbhb9xpHRzp4wMf_imC'
    total = value + len(text)
    return total

def Dh7G_ghItX():
    value = 595254
    text = 'b3LkXD4YGlq3P8XbkJ32'
    total = value + len(text)
    return total

def WXbqL89Pxx():
    value = 759512
    text = 'XiKpwb993OpUVdgGlrDk'
    total = value + len(text)
    return total

def iQ38oyrlT6():
    value = 839975
    text = 'AS0LI3dt4bA65yB3uHQX'
    total = value + len(text)
    return total

def h2Hwwx9veO():
    value = 916674
    text = 'IYteI9Jcjgx3WewZhHVP'
    total = value + len(text)
    return total

def HYHsTtVISd():
    value = 535174
    text = 'g9KJovLGO3yu_wDZqIGU'
    total = value + len(text)
    return total

def DbjL4Xz6NA():
    value = 649060
    text = 'bFFxdy7kzm_ycld20rrf'
    total = value + len(text)
    return total

def MYD9qAYNZE():
    value = 617273
    text = 'ctp08aH40eacQxT4hZpg'
    total = value + len(text)
    return total

def pUeH8UXM8u():
    value = 59388
    text = 'XbP2rW4UsgfDCGyF7l6e'
    total = value + len(text)
    return total

def zPHXiPIjPt():
    value = 802760
    text = 'TM4P0zXKy9T2_9ng6JHE'
    total = value + len(text)
    return total

def TbnCLAbV8M():
    value = 507085
    text = 'nsTtjcop29QMsKjxbNN6'
    total = value + len(text)
    return total

def uiOyogKe_i():
    value = 789752
    text = 'HLeBFQ5VrDlzGRvu9btF'
    total = value + len(text)
    return total

def YSMvcrtBJl():
    value = 45999
    text = 'zY5_QEq7BcTfLoEm8Um2'
    total = value + len(text)
    return total

def UGFiZcIXny():
    value = 988768
    text = 'k9sMz5pFu0kFwklUt_2_'
    total = value + len(text)
    return total

def lrFJq97erT():
    value = 975298
    text = 'ASU5BaKjGAQdlSxgqzka'
    total = value + len(text)
    return total

def FPmLUyyK_h():
    value = 862046
    text = 'jbftX5XXtmdzcRUTVX5u'
    total = value + len(text)
    return total

def Y2Y0AjWork():
    value = 301578
    text = 'I2fwwtGXiMD8KbJ9WIvk'
    total = value + len(text)
    return total

def PfKZcGpXpw():
    value = 915653
    text = 'Bp5toVwdDQcw0VSOW6ki'
    total = value + len(text)
    return total

def CZWGXVL9lX():
    value = 56359
    text = 'yI98KStTlJSbKCfDKpmk'
    total = value + len(text)
    return total

def ypytZ7bjk3():
    value = 544076
    text = 'mQNTKzGHQO1_oiP0Fjew'
    total = value + len(text)
    return total

def csoT7IoW5G():
    value = 157838
    text = 'wr6QSwswWDA0qsM_Cupg'
    total = value + len(text)
    return total

def F5lSIOZ0ZG():
    value = 397715
    text = 'QeVgmO18EXsMh5_bl0eO'
    total = value + len(text)
    return total

def Nisnh1Rpqt():
    value = 677627
    text = 'r1tZWE_qg2fEAvPJGpI0'
    total = value + len(text)
    return total

def flWn9PzdRH():
    value = 384350
    text = 'hduKZLlh9T3gYKd9tM7W'
    total = value + len(text)
    return total

def z8NxSHG1Fi():
    value = 544405
    text = 'GYfMzF3wzyU6dlDr6CrB'
    total = value + len(text)
    return total

def wwH1niHqfC():
    value = 62026
    text = 'dj4YgBihTNhQTZkt9SD2'
    total = value + len(text)
    return total

def nihDM2FU9D():
    value = 12256
    text = 'nu8OWZI4jOyFhYjY6bth'
    total = value + len(text)
    return total

def eykOv4KdfZ():
    value = 478836
    text = 'YSQUXqdjK_sZU25oYJ_l'
    total = value + len(text)
    return total

def n7QjI_Gqqz():
    value = 591088
    text = 'zoYPk7FWZwuCkBqlWXt8'
    total = value + len(text)
    return total

def KJHaPUDSJP():
    value = 999063
    text = 'on6Bk9rwihfd7eVcR6bV'
    total = value + len(text)
    return total

def RoJ5VfX1E9():
    value = 778813
    text = 'IoPGps2hNsxZPaTAKXYo'
    total = value + len(text)
    return total

def mkYwJ1TTDf():
    value = 268814
    text = 'ilTusRu1x7qqxSYI4UJ0'
    total = value + len(text)
    return total

def VRxSgCk6ZY():
    value = 515027
    text = 'nUXzuRCbT2mifKtznXXA'
    total = value + len(text)
    return total

def xOedBBnPbg():
    value = 14855
    text = 'm_qraMbJQBGsgPGYizio'
    total = value + len(text)
    return total

def ZRUKQCTKMa():
    value = 369466
    text = 'M1fW6iZ_G5C99ZzR1fkg'
    total = value + len(text)
    return total

def sBBeET12_2():
    value = 502950
    text = 'fBG8eHVcN9nBoq_fkyZM'
    total = value + len(text)
    return total

def nWWcZ7BdJ1():
    value = 633571
    text = 'krsCl9eDmApvPoRcG43D'
    total = value + len(text)
    return total

def FX6Y7V2rcQ():
    value = 984237
    text = 'F7wGydREzTIHy2NiGisO'
    total = value + len(text)
    return total

def m7JjkulonJ():
    value = 280454
    text = 'Iu1jmdpHOsCqtiwnbvDt'
    total = value + len(text)
    return total

def lpZOtBxbFR():
    value = 833887
    text = 'kL9oEX4ZSyBb7Yv2qYYZ'
    total = value + len(text)
    return total

def LTWa3hJyL8():
    value = 656164
    text = 'MxLrRUNQbfW3Lhbrvv7U'
    total = value + len(text)
    return total

def hoox6bB8QV():
    value = 404818
    text = 'Jc3sSCmzzVuubzWrtyaG'
    total = value + len(text)
    return total

def qlem4deTBw():
    value = 850553
    text = 'D8Pq8oduByZsayGeH5MR'
    total = value + len(text)
    return total

def SsZm2aCtuN():
    value = 76732
    text = 'Ddka_At40yQUa_IqzpL8'
    total = value + len(text)
    return total

def o34qi0kcoV():
    value = 853739
    text = 'xYmonCZJfP3g9vZGpI_2'
    total = value + len(text)
    return total

def x7OT9W_CdW():
    value = 321274
    text = 'ycTtujeXjLLpRIHD6EZp'
    total = value + len(text)
    return total

def u5KSN_lbia():
    value = 727607
    text = 'MFg0gU22_JOK7YknERof'
    total = value + len(text)
    return total

def a8AaeOO7pX():
    value = 168949
    text = 't1wYfceajfT5w_94sj2D'
    total = value + len(text)
    return total

def R72YMhJZ7N():
    value = 570924
    text = 'DtayTRhzkEUegoQyf0s0'
    total = value + len(text)
    return total

def jFskgcqTFN():
    value = 268231
    text = 'x5sP78B3Sy8slVYoOJ7i'
    total = value + len(text)
    return total

def kWtXdBaSZ_():
    value = 316791
    text = 'qjMybbOoHCkBkJBoJDJi'
    total = value + len(text)
    return total

def XXuUlbIqQm():
    value = 379699
    text = 'izoYPLcGizv9eJhC1N68'
    total = value + len(text)
    return total

def lfPxJxqjBy():
    value = 819183
    text = 'C0zbeTeSntY_4bXJLTVW'
    total = value + len(text)
    return total

def Qeysqsk339():
    value = 91135
    text = 'NmxkiiyeBoi4f_90RFkU'
    total = value + len(text)
    return total

def ANGwPW2ySm():
    value = 107341
    text = 'B_lw6mFUzYOJYGe5HqKe'
    total = value + len(text)
    return total

def xy1dY13GCK():
    value = 809595
    text = 'WR78bfQsQn_PoWuoD2PP'
    total = value + len(text)
    return total

def n57mnY9WOf():
    value = 699209
    text = 'AnGzRqbwpq6IqDsEjUxO'
    total = value + len(text)
    return total

def GljQrApuge():
    value = 914628
    text = 'MBonGrW7WW3Fd8MjVRXw'
    total = value + len(text)
    return total

def jQPwfY45z0():
    value = 483342
    text = 'MBA1CENwBa4GtoYR6D13'
    total = value + len(text)
    return total

def nKVpwxxW9G():
    value = 816957
    text = 'Gdfxa5qTdYsu7sEGrtO4'
    total = value + len(text)
    return total

def fzu145GPGl():
    value = 432520
    text = 'FvhriXrI7FIP3GnN4RXM'
    total = value + len(text)
    return total

def XU9_2SD7QF():
    value = 560894
    text = 'sAy6e7mFLIQi3kerTbRF'
    total = value + len(text)
    return total

def BHxtIARHOy():
    value = 342330
    text = 'BeGnVand3VInt09utm76'
    total = value + len(text)
    return total

def xPKGf0Ns6H():
    value = 507225
    text = 'JPhsfcqTEqpITYIYTUMZ'
    total = value + len(text)
    return total

def yX2m0WSW7G():
    value = 630847
    text = 'KXbhViZtp58qfxEXs23I'
    total = value + len(text)
    return total

def gq53fSqWzy():
    value = 407840
    text = 'K3mRSvbjX0gGkely7D5u'
    total = value + len(text)
    return total

def VZtvjhywZv():
    value = 605076
    text = 'EZvgkbisBbr09qPXDSIR'
    total = value + len(text)
    return total

def opQRrHgWhQ():
    value = 968824
    text = 'Fb8qulOTZr7wGUCH2isr'
    total = value + len(text)
    return total

def yfeuFWhsX6():
    value = 866134
    text = 'eFAUhf2cP7UTQ4bXLy1T'
    total = value + len(text)
    return total

def CVpMGTSYID():
    value = 847747
    text = 'EnWMLzvKZ4U8knQ5dcVq'
    total = value + len(text)
    return total

def IZYZcqMd3e():
    value = 284913
    text = 'dZ1ZeOAn1BldWuCoIvGf'
    total = value + len(text)
    return total

def ajrRYz_Hz0():
    value = 394250
    text = 'Ljuce7gwFhqklrfIqd_u'
    total = value + len(text)
    return total

def c_51oP_fWb():
    value = 50309
    text = 'IOXAIOwr1_Y7_qPnr0eQ'
    total = value + len(text)
    return total

def D9ogMmFH1O():
    value = 869790
    text = 'jGNxl0RO_UOMg1zr_fwR'
    total = value + len(text)
    return total

def otOmn9ZANb():
    value = 329470
    text = 'sO_8jS0V0okTTEXQhCNX'
    total = value + len(text)
    return total

def lu9Jc4pm32():
    value = 318852
    text = 'DcvNpfZbJqAyym_du1xz'
    total = value + len(text)
    return total

def ELTwcZCNrm():
    value = 382036
    text = 'WRuNyxA9mNTQkv65_etq'
    total = value + len(text)
    return total

def VQSRlJHvgc():
    value = 658815
    text = 'eqGNMRPYD8WNrw8pApwv'
    total = value + len(text)
    return total

def EoeS2ebOxQ():
    value = 787213
    text = 'm4yXIGcOD3DIxhOjK8hs'
    total = value + len(text)
    return total

def RqRnJlGKro():
    value = 629383
    text = 'nGTZ86H6CxdzPeYSrcVr'
    total = value + len(text)
    return total

def YyDtRRGxkU():
    value = 204142
    text = 'DMqfB9TlSwwDGam6KDhi'
    total = value + len(text)
    return total

def fDz_uKexbd():
    value = 603341
    text = 'FCZrHmGcLCTCIvxYUn_W'
    total = value + len(text)
    return total

def UJJrNkn2wT():
    value = 133099
    text = 'ZHBs8U98gw0emwj4BCc7'
    total = value + len(text)
    return total

def x_zazQXPRl():
    value = 210819
    text = 'zxZIE5ndTlTczPPiQJTO'
    total = value + len(text)
    return total

def hM997IDOfI():
    value = 498304
    text = 'obskOommXSLpf1KJO75w'
    total = value + len(text)
    return total

def SuCJ73Ytrf():
    value = 829089
    text = 'GJs3oQ5MOREVAl6HNIH3'
    total = value + len(text)
    return total

def UPKGSfbruX():
    value = 279656
    text = 'FiMpsfhfpqOGBUqdy1jB'
    total = value + len(text)
    return total

def nhA4JLNPYa():
    value = 395483
    text = 'PMIyedXouD4kTmGcCwEA'
    total = value + len(text)
    return total

def YfZ8r1Wr08():
    value = 713321
    text = 'Fbf6mtXQ40RxLhEMMEYf'
    total = value + len(text)
    return total

def ws4MclrCKS():
    value = 455113
    text = 'R3NkuL2I6gPNIE4aVsJw'
    total = value + len(text)
    return total

def rSemyYvQrZ():
    value = 850847
    text = 'D5L7jBJs3rvlFAHtC5vv'
    total = value + len(text)
    return total

def WoNkLDVKDj():
    value = 909762
    text = 'UTdHBWw22wr7hnTZwMD3'
    total = value + len(text)
    return total

def UtSke3lwXF():
    value = 575475
    text = 'qeUsLpOUAc3GIkDeTb7y'
    total = value + len(text)
    return total

def pr148GOFE3():
    value = 998762
    text = 'EiLUciJmlV5YTwIAWsEg'
    total = value + len(text)
    return total

def HAZJ3DxHKO():
    value = 482038
    text = 'Coib2P0wYUD_gqrGh4wx'
    total = value + len(text)
    return total

def XdRsXJgOE6():
    value = 29431
    text = 'iB6Fz5K0D4y4UxhKfb7P'
    total = value + len(text)
    return total

def kvS_en15IK():
    value = 34235
    text = 'vbemizDfDQr7xN_O3HTe'
    total = value + len(text)
    return total

def DxuFDBSLbs():
    value = 738588
    text = 'w1VEYJWUeIqkrq_h0piY'
    total = value + len(text)
    return total

def FGbfNzDR3t():
    value = 495598
    text = 'D9Q16IZL8Y6teo1d1LQ6'
    total = value + len(text)
    return total

def pDsEuibFEu():
    value = 787298
    text = 'IToHgtajbfPXzjRM0Mx4'
    total = value + len(text)
    return total

def FAvYofdinx():
    value = 844173
    text = 'ks5TEEn4vXwF2JJttTjs'
    total = value + len(text)
    return total

def LBQ1UUuUIa():
    value = 918470
    text = 'hYf4Rcs0TEKXpzskPvHD'
    total = value + len(text)
    return total

def CHMb7lj3zM():
    value = 480490
    text = 'OjCZX8teVenRvQ9JtOEQ'
    total = value + len(text)
    return total

def EoTvw6GLsz():
    value = 306977
    text = 'ITRmxl_8Y6NCw1dU221q'
    total = value + len(text)
    return total

def pnqCziObbZ():
    value = 423096
    text = 'xobEnkbk9SKjWT4YF83G'
    total = value + len(text)
    return total

def y3lch2GSl4():
    value = 970052
    text = 'toXBPLzgwxcfamVmr7Ka'
    total = value + len(text)
    return total

def dKaPhFQl7n():
    value = 634390
    text = 'WTZWRB4zSWsMKh3Bdyrz'
    total = value + len(text)
    return total

def ozJccrAwwE():
    value = 294502
    text = 'fjPOKPejMMZSAQDJhcVs'
    total = value + len(text)
    return total

def Sx25k1rk8O():
    value = 79533
    text = 'n0CDbHQqFWJbbGgNT_IH'
    total = value + len(text)
    return total

def IV3Qslsr6j():
    value = 321687
    text = 'dfvtEgu_c8JLvaGOWHU2'
    total = value + len(text)
    return total

def WVDs3_cElE():
    value = 196672
    text = 'ReIQpQ0Z3mNePfxq6ElO'
    total = value + len(text)
    return total

def XhcLSjlG_e():
    value = 614293
    text = 'T3ePaATf7IheSCEmhU1V'
    total = value + len(text)
    return total

def Cbm1UFSnxn():
    value = 941774
    text = 'FRQo3hqslxF7jJi9CAR5'
    total = value + len(text)
    return total

def vgsS_5H0FC():
    value = 841565
    text = 'U7_E4co8GzpjZYxTz2Pu'
    total = value + len(text)
    return total

def WYDJjlda7H():
    value = 250771
    text = 'VCbQXqhLFwcw_ra0rz_i'
    total = value + len(text)
    return total

def A20M_xwmtu():
    value = 573600
    text = 'kENrGsWauTfpZ2OSMM2r'
    total = value + len(text)
    return total

def LB5ZRHXc28():
    value = 609028
    text = 'WP5X8LnvOYl5bKVSHQzp'
    total = value + len(text)
    return total

def qZ43pNya3G():
    value = 413081
    text = 'p_knlu_PhoqWcAMtya0_'
    total = value + len(text)
    return total

def TVntlelZxC():
    value = 278452
    text = 'Wo5yEnpye4IjL5Su_wz9'
    total = value + len(text)
    return total

def yHdYt2oY9Q():
    value = 834160
    text = 'HCIhlOJ7WqW6JFiznGla'
    total = value + len(text)
    return total

def EuvmFnVmpD():
    value = 694954
    text = 'hJX_sKfRxpkpPICaMYUc'
    total = value + len(text)
    return total

def BCaxOugjQw():
    value = 346707
    text = 'K4uOUVobfr3mlUq1IDLn'
    total = value + len(text)
    return total

def VnuRyX1QOF():
    value = 825383
    text = 'LOd_ZZB5Z504oUpLZZXD'
    total = value + len(text)
    return total

def iYrvM8F0eU():
    value = 990501
    text = 'GsbQuPF_TOtwJinvaH7M'
    total = value + len(text)
    return total

def mu59Qfaoip():
    value = 377040
    text = 'tLbkaxgWIkwC0vntUBqE'
    total = value + len(text)
    return total

def GvqKquCvCA():
    value = 259486
    text = 'wDQcYZyNH2gE4TunXBRE'
    total = value + len(text)
    return total

def gmu3tH0NZ0():
    value = 327883
    text = 'MomR9hC0diHjnBFX9q6s'
    total = value + len(text)
    return total

def NszkMgqvi7():
    value = 946428
    text = 'M1bFWQTUAWQVEpx8H54q'
    total = value + len(text)
    return total

def WKJ_oVBxD5():
    value = 982271
    text = 'x31xbNMu5egSXF7XAKUU'
    total = value + len(text)
    return total

def RWDg7bMq2j():
    value = 209852
    text = 'MAsMj15n3BYfbRq8tidA'
    total = value + len(text)
    return total

def axSjRsug4T():
    value = 784767
    text = 'p33YoLyakAkT7GUwz38t'
    total = value + len(text)
    return total

def udl0bEgfbt():
    value = 666572
    text = 'l4GaMCVxboSjOyeuj9gt'
    total = value + len(text)
    return total

def jPWadb_RA9():
    value = 860144
    text = 'xyp5Bir6lKEUbK8j9oAr'
    total = value + len(text)
    return total

def IE9beK5RA5():
    value = 928968
    text = 'kya15FxasJ_iXgpAMhQg'
    total = value + len(text)
    return total

def YQRSv4cpnU():
    value = 944571
    text = 'dhcIdNm3C19neP7PZiqC'
    total = value + len(text)
    return total

def Lh_5WksXLV():
    value = 627192
    text = 'aIwzpl5QKYhcP0zpl6Cc'
    total = value + len(text)
    return total

def nUPwiQhKWc():
    value = 507592
    text = 'SAqzSMwKRqR5OndQTvST'
    total = value + len(text)
    return total

def tBFnC8PVbE():
    value = 490339
    text = 'UipikFBVc1jgeqrwG8id'
    total = value + len(text)
    return total

def Bk8s6The1k():
    value = 67843
    text = 'kaWdg1h_povpRFoPk1dl'
    total = value + len(text)
    return total

def IpE5MEgJYL():
    value = 432990
    text = 'zVyE384NH07UMGBHB3ey'
    total = value + len(text)
    return total

def HdjH4H67_E():
    value = 564286
    text = 'Ogv1Hr8wwzooRoVuOmWH'
    total = value + len(text)
    return total

def e8MvCXMsWH():
    value = 546247
    text = 'd2lZrwBuh8VQz6WUwc4h'
    total = value + len(text)
    return total

def zkUKpYeSvc():
    value = 43113
    text = 'cVxdXwQTUF8xcQI8GZqN'
    total = value + len(text)
    return total

def BlRTrG83c_():
    value = 685493
    text = 'K36gmvje33rZrKn9mVpf'
    total = value + len(text)
    return total

def Xr_OULTIKs():
    value = 521708
    text = 'BvnLcdrtx_8rBCerWsMd'
    total = value + len(text)
    return total

def EkODER8CQ9():
    value = 812234
    text = 'E_zegK_SqxdxVZ4F61Ui'
    total = value + len(text)
    return total

def lHLKatWwhs():
    value = 591151
    text = 'hAligz8iTryuwAyFT3pv'
    total = value + len(text)
    return total

def KjFGuQyag8():
    value = 537226
    text = 'rQRsD0vwr8ohpsJ0qzDy'
    total = value + len(text)
    return total

def fLrdFIuUUP():
    value = 968032
    text = 'GHYto_AIPm_uUkmPbxbW'
    total = value + len(text)
    return total

def MD5P7mHdN5():
    value = 997314
    text = 's_hOsWwhpA3vcFhPHj86'
    total = value + len(text)
    return total

def RZLSb37DQV():
    value = 756668
    text = 'PYA6zV8Tlma10ZFlWVbo'
    total = value + len(text)
    return total

def VQRfGlpmoJ():
    value = 204254
    text = 'kgpBJRaP2nFTVGMN3Rnw'
    total = value + len(text)
    return total

def EJN65Jy4EO():
    value = 794964
    text = 'PqomSIRCAo45w4cl04tx'
    total = value + len(text)
    return total

def E_cQdJNyGN():
    value = 770632
    text = 'DeTRlaFvwrzeX1l7tIC7'
    total = value + len(text)
    return total

def rjFyilgcKP():
    value = 573849
    text = 'C257LgruMBPd3I0Wl3Ig'
    total = value + len(text)
    return total

def AunOPmK2fp():
    value = 881623
    text = 'DElijxD1b2Qk7rZDOBdR'
    total = value + len(text)
    return total

def x02D_rDkp3():
    value = 58689
    text = 'l6fP7xP3ehMFUWmHBCe2'
    total = value + len(text)
    return total

def ZxFDdhHTiQ():
    value = 141953
    text = 'QlY9iwXYnSWg7iCurDRb'
    total = value + len(text)
    return total

def tF2lokdnb6():
    value = 97557
    text = 'zOjEyrxUnbaPCKFRGHzC'
    total = value + len(text)
    return total

def d8jZ95seuI():
    value = 259435
    text = 'yzQy9lX490__4rRkn4UZ'
    total = value + len(text)
    return total

def pUNSBjN249():
    value = 767005
    text = 'fGQ9ImBTrZJKNloVcaqG'
    total = value + len(text)
    return total

def jH83p2M06Y():
    value = 836450
    text = 'irKafyWvUeCC4lV6zu88'
    total = value + len(text)
    return total

def QtuM0YVkSV():
    value = 570660
    text = 'OvLtX0EU8FxDI_78jCf1'
    total = value + len(text)
    return total

def FOpP_8gBqT():
    value = 696066
    text = 'y3tgxsj5Z7Gh5Jq5erWa'
    total = value + len(text)
    return total

def ObxDKVrocl():
    value = 575322
    text = 'nZeNwDBxxvdrnuopMKOX'
    total = value + len(text)
    return total

def MfRxNH4_gM():
    value = 354586
    text = 'BuGM4lX_7KhNbTml1XZy'
    total = value + len(text)
    return total

def AJ0POTt6kO():
    value = 808193
    text = 'CtGWU5UgCc000OpPGWCQ'
    total = value + len(text)
    return total

def POLmyEL8Ke():
    value = 701990
    text = 'sESenDm8jIADJ5CXo55D'
    total = value + len(text)
    return total

def XezIzQey8V():
    value = 633502
    text = 'MJHlvWqDXTphfe4egeuF'
    total = value + len(text)
    return total

def XOenf_9ASW():
    value = 295962
    text = 'Ex1Xy0F63XAwepgKpmSD'
    total = value + len(text)
    return total

def FC36cjniQD():
    value = 698461
    text = 'uWD4q_xnqrqsIyTtVqob'
    total = value + len(text)
    return total

def npFBoW38g2():
    value = 783415
    text = 'Ux372oevp9f_8TKnEL3x'
    total = value + len(text)
    return total

def gWipmkNpUz():
    value = 874916
    text = 'GYpLad_M84YRYU7BAw1G'
    total = value + len(text)
    return total

def AoAsOy5ii4():
    value = 696532
    text = 'xEGNBmPbriUvoRQKg61n'
    total = value + len(text)
    return total

def bNaz8qUtEx():
    value = 391869
    text = 'X426E3Uokvftw91xdmxF'
    total = value + len(text)
    return total

def gYDCs3b9sJ():
    value = 889902
    text = 'ww0pWUu07fSckoR35jbE'
    total = value + len(text)
    return total

def ifnMBiSSij():
    value = 233893
    text = 'yOswXEBOP9RyG2P_Cho7'
    total = value + len(text)
    return total

def exOXKxWBKc():
    value = 56874
    text = 'lKMhb4OQTD5inERf1E4c'
    total = value + len(text)
    return total

def znLwgY3IBI():
    value = 217205
    text = 'dHwO8kn7DVjOCFRhLog4'
    total = value + len(text)
    return total

def BYGrEDNKbq():
    value = 931698
    text = 'ZKCrAv8mJfk0leCuOG8P'
    total = value + len(text)
    return total

def j3mKpjVPWr():
    value = 984132
    text = 'EU3mTLAFjenZNM77wmHd'
    total = value + len(text)
    return total

def w8gMGmsbtU():
    value = 36476
    text = 'n0V0xUSQ6RwTnmjrjtSi'
    total = value + len(text)
    return total

def XGqzv5oIf_():
    value = 195716
    text = 'ccILI3GOfv5YafVYMunR'
    total = value + len(text)
    return total

def R9xwXFkrsM():
    value = 449558
    text = 'mR30FMdkXrHtjNGeUoDd'
    total = value + len(text)
    return total

def YX_nqNb1Aa():
    value = 175287
    text = 'yARv9k_GZ8T2jGRw3vcF'
    total = value + len(text)
    return total

def n8TkDAyIUA():
    value = 158528
    text = 'X3vgyIawPlzusEkLDd3R'
    total = value + len(text)
    return total

def F5wuWAksLv():
    value = 138521
    text = 'u4hYTJecPDWENvSQcxVQ'
    total = value + len(text)
    return total

def kD5tXdKPBI():
    value = 369141
    text = 'UXEMz55nZI0fgaE6cwJR'
    total = value + len(text)
    return total

def L4gWZvLE_K():
    value = 356255
    text = 'Jf660rR6M78dTJWGzsxW'
    total = value + len(text)
    return total

def A_VsSXaANc():
    value = 507826
    text = 'FZTsn9ocEsSJpSXm4qW9'
    total = value + len(text)
    return total

def GM05T5pb10():
    value = 44899
    text = 'WKdhiSLtc3ggbgGXHoav'
    total = value + len(text)
    return total

def DI9OGr6mvv():
    value = 834936
    text = 'xVlKUnjwr_SlOGVtmyvU'
    total = value + len(text)
    return total

def C0zgSD41j2():
    value = 417789
    text = 'PKnKngzRAakJdH97zhpx'
    total = value + len(text)
    return total

def gowNbH_LN3():
    value = 79604
    text = 'dql_vokahch7YIgt24SS'
    total = value + len(text)
    return total

def B_jwncny1a():
    value = 489262
    text = 'uei2t9HQsUpyHymz9qdc'
    total = value + len(text)
    return total

def MAxJYq4UZo():
    value = 656576
    text = 'CjJyx0wiiK8P0f2g26NG'
    total = value + len(text)
    return total

def r6lKFmqX6y():
    value = 10634
    text = 'KTeK3u8wCd3eIS7nbaHu'
    total = value + len(text)
    return total

def Yntbliw7Ot():
    value = 336353
    text = 'bTt04rBT1JhEerXik0tY'
    total = value + len(text)
    return total

def r4h2OEef1z():
    value = 736145
    text = 'KBrMAoRke1FPiTCYDT2V'
    total = value + len(text)
    return total

def cVgGjjJ864():
    value = 803266
    text = 'vxj9CiSXQ4CRCldDnFx_'
    total = value + len(text)
    return total

def Tep3lOKGNY():
    value = 175682
    text = 'whYnd4PCCaEF9NlaUbHz'
    total = value + len(text)
    return total

def HLeCksyIxJ():
    value = 113052
    text = 'yuc1uytdtkIXIROT8FlH'
    total = value + len(text)
    return total

def UdMTNIJ79C():
    value = 360125
    text = 'v4p_GFjEIB8CmYpA5qXL'
    total = value + len(text)
    return total

def geEZvIb9fZ():
    value = 211329
    text = 'M2VaQXhPycdhNyYLGKQi'
    total = value + len(text)
    return total

def O4eQ5BfhIj():
    value = 140368
    text = 'UO9lnTgN1GXlL0H6jkz3'
    total = value + len(text)
    return total

def lbU3lXQvJp():
    value = 144994
    text = 'JnltghhsuS3vmykOhSMc'
    total = value + len(text)
    return total

def wUkFk7R_HB():
    value = 782681
    text = 'O0Ags5ISFxYmoRbUjmC7'
    total = value + len(text)
    return total

def BshiBcuVcd():
    value = 613576
    text = 'jfcxLHa4UPmyEe38Adsj'
    total = value + len(text)
    return total

def e6UlU3xgy8():
    value = 246579
    text = 'dQ3IqNKWT_42vBMckGZE'
    total = value + len(text)
    return total

def WzYUSVAsdz():
    value = 139312
    text = 'JtQss6QH1biwG8X3wjO4'
    total = value + len(text)
    return total

def DQ71uzrCeZ():
    value = 55748
    text = 'UqHuf9ZqNmySQ1RV8yDw'
    total = value + len(text)
    return total

def KH3nfYB1qt():
    value = 558436
    text = 'gw8yq94uGY_chnKh59sz'
    total = value + len(text)
    return total

def e5LJAGOL6r():
    value = 144200
    text = 'jscpfokrk8m0YO7QN8JV'
    total = value + len(text)
    return total

def WvOTC3k9DV():
    value = 270110
    text = 'tdb0_JKMebMwEQFvqc6R'
    total = value + len(text)
    return total

def nEWmYCF_Ab():
    value = 875058
    text = 'cCQDbl4pEqZjvUHUfoAL'
    total = value + len(text)
    return total

def twDhW1d9ms():
    value = 282743
    text = 'z7XKh0Z6YhMrgLrRO8Fg'
    total = value + len(text)
    return total

def c8RCeBDPC9():
    value = 441042
    text = 'fvROVjIhXD5IVobUoxZL'
    total = value + len(text)
    return total

def R1HLAiyWeG():
    value = 268187
    text = 'scfRtHiHyB7gp7kmVukn'
    total = value + len(text)
    return total

def a9GWurqaPq():
    value = 88754
    text = 'PyiZshvjlOguDtmmeQat'
    total = value + len(text)
    return total

def cpno4OEzss():
    value = 632062
    text = 'ksSYWUzt8OXVuVYOqNLR'
    total = value + len(text)
    return total

def sNrL00i1vx():
    value = 130161
    text = 'k1gEszsJc5FojWtv6jPL'
    total = value + len(text)
    return total

def aDqJvDKD34():
    value = 823536
    text = 'jMJNeoUG8rc_qCvwC2Ui'
    total = value + len(text)
    return total

def jcyGQBzkBx():
    value = 118951
    text = 'DXcuBSZshqHhRIEZ44J5'
    total = value + len(text)
    return total

def rAJCAhd9fK():
    value = 283768
    text = 'YKJ1jl8z1aoHKbmqsQCl'
    total = value + len(text)
    return total

def SU6R_IsenB():
    value = 66679
    text = 'TdykrSnwPN8yl7yOMx0W'
    total = value + len(text)
    return total

def uR0Ty0tZ1q():
    value = 501449
    text = 'QwCLvI0xQC5vka3H5tXw'
    total = value + len(text)
    return total

def McjRKHsDSz():
    value = 437893
    text = 'gjinf9hhN_UDZZ73pENU'
    total = value + len(text)
    return total

def yYCmpv0Ttk():
    value = 622289
    text = 'gYASlrPx7tH4C0ufbasc'
    total = value + len(text)
    return total

def xI9t1ADpq7():
    value = 898296
    text = 'qyxy6JqN1teuWwCgLQjt'
    total = value + len(text)
    return total

def pi8X1Y2Ueb():
    value = 707851
    text = 'R5XsSgYsV5sTPf5BHz_c'
    total = value + len(text)
    return total

def MLPRx2yqsr():
    value = 273518
    text = 'z7umAXwAy1WZ4PawKjr6'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
