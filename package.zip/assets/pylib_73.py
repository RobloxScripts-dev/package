import os
import sys
import time
import random
import string

def az7ym6XkbD():
    value = 588192
    text = 'TnLxbqnWopD0wHgdJPiP'
    total = value + len(text)
    return total

def koEgMXLgL_():
    value = 470009
    text = 'U_maMuDvhGT6XK5hDbN6'
    total = value + len(text)
    return total

def CumfT5mqvF():
    value = 915422
    text = 'g9HYnlXtvIbtA2iUT7UL'
    total = value + len(text)
    return total

def hzID7v9PKd():
    value = 893649
    text = 'F_AXZwVgPxwmLrLPe2wz'
    total = value + len(text)
    return total

def jOQga4QmY2():
    value = 339758
    text = 'DFeIxlhTn6q9bDWZKqHw'
    total = value + len(text)
    return total

def jHlOSoakcZ():
    value = 937758
    text = 'ulPzEQ7N0fKcLOKFyqlu'
    total = value + len(text)
    return total

def v9XXu93n6u():
    value = 574393
    text = 'fb2qjpTkiF4tvN59caZF'
    total = value + len(text)
    return total

def fj4toPUXWa():
    value = 975966
    text = 'aDyo79KcNujQEJI_LgNi'
    total = value + len(text)
    return total

def HLiBJN05dz():
    value = 258398
    text = 'OXR2927er0ruV9Ed56dy'
    total = value + len(text)
    return total

def xh0PuEnwlL():
    value = 416670
    text = 'ZJdPYsmFv82vFnS9QKBv'
    total = value + len(text)
    return total

def PQK7xYtPRD():
    value = 354543
    text = 'nbir8zpcFcLWlEk4uhkX'
    total = value + len(text)
    return total

def UEZXXnGDru():
    value = 726464
    text = 'Gzw0RAzs0bIaInG6FPvs'
    total = value + len(text)
    return total

def kV7Ipem8Gr():
    value = 481099
    text = 'cvpNSqPGM8aluOqtRnEb'
    total = value + len(text)
    return total

def Hqdqjeo4il():
    value = 639465
    text = 'ji524lemn6WeXXJlUAnM'
    total = value + len(text)
    return total

def ofeV8_Qbn0():
    value = 882948
    text = 'VhiDyDnXKoNhZabJUQz6'
    total = value + len(text)
    return total

def dqoXtCaX2r():
    value = 656482
    text = 'Xv1xdxa2G2mVkKRwnPgo'
    total = value + len(text)
    return total

def WCoXqsN5El():
    value = 342655
    text = 'IuRIZS21YFvWutcuwNyq'
    total = value + len(text)
    return total

def RqpAeLixKy():
    value = 729828
    text = 'ISSEHjm5oOLc4sHODP3e'
    total = value + len(text)
    return total

def glbbqaK8cc():
    value = 777367
    text = 'HPsy5iEsxhG1Z19aQC4v'
    total = value + len(text)
    return total

def kgE3RZhN8C():
    value = 451513
    text = 'rXFMCp9wDngRHXRekEqO'
    total = value + len(text)
    return total

def eRvW5nbbtj():
    value = 886929
    text = 'Dce3y2AQZFtodmmrPOk3'
    total = value + len(text)
    return total

def VGKNFxNLTI():
    value = 279930
    text = 'prCS4Zj9rOYHb0m2a7oR'
    total = value + len(text)
    return total

def aIvDWydwTz():
    value = 534353
    text = 'aNnRXuNJ0omJF3VvYV3b'
    total = value + len(text)
    return total

def MYDe6pAviR():
    value = 459738
    text = 'w7IuTVLyMSIWK3_Js_U6'
    total = value + len(text)
    return total

def rjg8or_1pt():
    value = 610113
    text = 'WEtqriAZJV5tfoKF411m'
    total = value + len(text)
    return total

def mOcW65M8Gs():
    value = 794473
    text = 'D9ICZaB3UkoB5H6346Xc'
    total = value + len(text)
    return total

def UMZpPlaZ28():
    value = 28584
    text = 'fuC17D3W2EOm_9wcklIn'
    total = value + len(text)
    return total

def ZJhLo8SJ8_():
    value = 960351
    text = 'GrrHQyyvKs8Rd540EYQI'
    total = value + len(text)
    return total

def rp_PMZF1uL():
    value = 649879
    text = 'og6h6ZuImp8te5lfzcfD'
    total = value + len(text)
    return total

def SSk4H3SPlL():
    value = 562391
    text = 'Au09wV3e0VnMBXMMEW0R'
    total = value + len(text)
    return total

def tIpBZFAtI6():
    value = 410165
    text = 'amMSOeQoMzBfnqYkMQ8l'
    total = value + len(text)
    return total

def eHuxVcfoZH():
    value = 538730
    text = 'EIlrG09uVw_5X1dqI2ak'
    total = value + len(text)
    return total

def TkWHG3gUw5():
    value = 215777
    text = 'kg7BbBGIJ2eVNmxIJLlE'
    total = value + len(text)
    return total

def nCPpzTfd6W():
    value = 993941
    text = 'wsO4Xyx7jdxqZ65wE8Y1'
    total = value + len(text)
    return total

def g_bjTArBHH():
    value = 193148
    text = 'hrzqrkfexzLLsSgTBvlp'
    total = value + len(text)
    return total

def kCIVFPqlOY():
    value = 296646
    text = 'eLIN9wbZDrkFawnb5tKB'
    total = value + len(text)
    return total

def sYmGT6WxJN():
    value = 38543
    text = 'GihOZs7YNofJss65bIIN'
    total = value + len(text)
    return total

def yTzb9UZaFh():
    value = 224688
    text = 'o1ubuoJGqrb5dMIA0Oe9'
    total = value + len(text)
    return total

def UhNYD6V3At():
    value = 677461
    text = 'w8jRBjr1eX8YhNY1XGXt'
    total = value + len(text)
    return total

def WFc3OxvxnV():
    value = 550407
    text = 'RmRpzfntu9Y_VrrTun25'
    total = value + len(text)
    return total

def AytXYq2dxq():
    value = 327853
    text = 'KfX3lykHHWWBklwAGwWc'
    total = value + len(text)
    return total

def ZKaDpM9Bt9():
    value = 365096
    text = 'B55RQrp5ekRVHIaAgj4q'
    total = value + len(text)
    return total

def BOYntMIhUR():
    value = 754250
    text = 'xY_oAs3aLGg7ocqHJBnM'
    total = value + len(text)
    return total

def Ka9EPHBpVd():
    value = 407169
    text = 'uu3ljGfC0BBy3cZ_BzfA'
    total = value + len(text)
    return total

def egwEw7SduK():
    value = 258144
    text = 'jAbjEHw5JQMnXCE8uAU5'
    total = value + len(text)
    return total

def Zm6jxWJCZd():
    value = 287913
    text = 'wPyFVC_uT56oVBdY_3Dc'
    total = value + len(text)
    return total

def PRdqYMVV0j():
    value = 30976
    text = 'Txwx8c8GYwsgukA9Y5NW'
    total = value + len(text)
    return total

def eoQnGGyAP0():
    value = 342701
    text = 'VxC4KD3UjeuQnZqs8Kl2'
    total = value + len(text)
    return total

def I45eAsosqx():
    value = 639459
    text = 'c2Yt9wa7BPeaGfJ6TZ1_'
    total = value + len(text)
    return total

def fu5DK6ce0Z():
    value = 583482
    text = 'h1DCLTaFk8noro2Yz7iS'
    total = value + len(text)
    return total

def Qf6zPZNjAs():
    value = 247755
    text = 'hGa4EdI956W4o5rOoRWK'
    total = value + len(text)
    return total

def s6bSV88o6S():
    value = 198577
    text = 'YtvTTKUaZRSOFYco3taE'
    total = value + len(text)
    return total

def pYvxLLIMnd():
    value = 441227
    text = 'pNS3ZBQMMjKTIRbykDHL'
    total = value + len(text)
    return total

def bSCCWIYWqe():
    value = 565393
    text = 'eLfTakgiuDp8OwC2jP1w'
    total = value + len(text)
    return total

def rPV8xcsMfM():
    value = 255917
    text = 'sNluMush4grsbpG4Dpxx'
    total = value + len(text)
    return total

def Lj5nSb5v5D():
    value = 201946
    text = 'PDOMidMgoKNFTpMaotDh'
    total = value + len(text)
    return total

def tAfLOKO6wD():
    value = 816173
    text = 'xAp7QGUzZ9n3JYwod7tc'
    total = value + len(text)
    return total

def HNhHsOZbeF():
    value = 800025
    text = 'kttFYpLK0x1bcohsdryU'
    total = value + len(text)
    return total

def X72Benklc7():
    value = 914997
    text = 'nj9mOGBGETIWo9m8S8lS'
    total = value + len(text)
    return total

def NWfdKO0esx():
    value = 198947
    text = 'ajOIJJaDsvdSTDZIwcSi'
    total = value + len(text)
    return total

def jy7uKPZ_eH():
    value = 193412
    text = 'FNpkRgQpNyGjYaE1IzMW'
    total = value + len(text)
    return total

def ybWsWefxtv():
    value = 868222
    text = 'DpD5jaFAgH_QBtzqdbAl'
    total = value + len(text)
    return total

def LeS2EfR65a():
    value = 358737
    text = 'Uz4zM7wFCCvOHap6gWHM'
    total = value + len(text)
    return total

def eBSCPm5NWR():
    value = 659644
    text = 'dR0LW58qiyTnKSAT640d'
    total = value + len(text)
    return total

def pzgb6FO8cF():
    value = 90499
    text = 'nJ9utesDA7R17ECbSPBF'
    total = value + len(text)
    return total

def YGsAubxfTX():
    value = 990670
    text = 'O_jTEtYJQGn_LEBic5AM'
    total = value + len(text)
    return total

def v2xMqxn2V0():
    value = 883393
    text = 'DXlHxBE8YmLeaz_tiJsk'
    total = value + len(text)
    return total

def PZB1EkjPJT():
    value = 135174
    text = 'WSGxrCbhmXP_i3Tt0ktc'
    total = value + len(text)
    return total

def XHIV0UcKKb():
    value = 331785
    text = 'dgTg41TukyqsrgUcCweX'
    total = value + len(text)
    return total

def XWqBRqP6g3():
    value = 617454
    text = 'GG5nfY8VTArBsO7vR5kt'
    total = value + len(text)
    return total

def spLNQ2Tls1():
    value = 732539
    text = 'c9WNQ1wYUkxUSx4qkmmh'
    total = value + len(text)
    return total

def O8mQrNImad():
    value = 355385
    text = 'En2oKVqLgeQSA_7LsZFl'
    total = value + len(text)
    return total

def h5c0b5c41S():
    value = 242152
    text = 'xcfuFQeS8_0Z4hhjLgQL'
    total = value + len(text)
    return total

def GkChGiyJe1():
    value = 302260
    text = 'WL5jvdXIVR2L_3hOI77Y'
    total = value + len(text)
    return total

def Y9TLQ6lS6T():
    value = 544690
    text = 'seKCz9kq6Y3_MHjBSsFS'
    total = value + len(text)
    return total

def h5t9DasFRt():
    value = 784090
    text = 'PqYM4WCa8ZhSpUjkCzJW'
    total = value + len(text)
    return total

def Sh8WIuWG1c():
    value = 133674
    text = 'Mxfd31xdChQx4cYpGfiP'
    total = value + len(text)
    return total

def GepKxbZquS():
    value = 203240
    text = 'a0KWsf65J0fieRApJjq4'
    total = value + len(text)
    return total

def vFoE_tXE4y():
    value = 270220
    text = 'ln_BOlkExkBTRvaq5J6l'
    total = value + len(text)
    return total

def X8mwKvATsC():
    value = 52365
    text = 'TvgvNfJxShErILZZ3RUR'
    total = value + len(text)
    return total

def DzdFutOeha():
    value = 533510
    text = 's4G7g33cFtNogDHdC7WC'
    total = value + len(text)
    return total

def zLKWrglh1I():
    value = 201286
    text = 'ztCrKTblCrDzPPR5E6LD'
    total = value + len(text)
    return total

def LjkkF_Laqd():
    value = 401794
    text = 'WjM6UVn3hWWi4oLEosuk'
    total = value + len(text)
    return total

def VgJdmB0fW1():
    value = 230803
    text = 'ChU4JAYJOGD9YcBueO6l'
    total = value + len(text)
    return total

def JtcIs2XXLb():
    value = 897931
    text = 'pnFNPsL5AMcvHFthieJb'
    total = value + len(text)
    return total

def X0LkiJayHH():
    value = 805750
    text = 'NNEOTatIaMuVNyvk4SRm'
    total = value + len(text)
    return total

def jLRTgt_q03():
    value = 826131
    text = 'K6VjfrjboaXDGQ0srHA9'
    total = value + len(text)
    return total

def a4YG1xbv9H():
    value = 778226
    text = 'HjDM2svdXUnkrpR1Alds'
    total = value + len(text)
    return total

def acn7gk44Tp():
    value = 588127
    text = 'IQr9kWrLWy7IKCe2Vtpf'
    total = value + len(text)
    return total

def HYI0hvDZf5():
    value = 3858
    text = 'F8jxXanqQuZUP5u5DJ4Y'
    total = value + len(text)
    return total

def hQrs4KQNEX():
    value = 177757
    text = 'E0kNe3G9TLF1bdQLD0zP'
    total = value + len(text)
    return total

def jbvhhRrkUF():
    value = 339021
    text = 'NcyhWoCeg8VpMzFywmOf'
    total = value + len(text)
    return total

def ovGRG_jnes():
    value = 392334
    text = 'JUA1VTvrlqZdR49vDIOk'
    total = value + len(text)
    return total

def HTR3QFUqs8():
    value = 156951
    text = 'tpdHYrKsWLguBXeGrgpZ'
    total = value + len(text)
    return total

def eIsND4Y9xM():
    value = 576598
    text = 'BcaPov4T_JQ6pPDqaz42'
    total = value + len(text)
    return total

def W1l3Gcdsnp():
    value = 34651
    text = 'H24w8bolPfiY59rSJUp0'
    total = value + len(text)
    return total

def x0WkIeX1Jj():
    value = 59095
    text = 'vC9S8hxkpNzvIYuKWAUx'
    total = value + len(text)
    return total

def MLwsJSbs43():
    value = 803465
    text = 'rdyB_VuaiwDl89vMZTnu'
    total = value + len(text)
    return total

def PZjJl4OQCG():
    value = 463185
    text = 'SpJIGOXrkhmvlfqbjkH2'
    total = value + len(text)
    return total

def Oj03inhNKh():
    value = 429270
    text = 'JMY0no8htvVzeoXrN964'
    total = value + len(text)
    return total

def oDVXfoVFqv():
    value = 461849
    text = 'WSmOeyaSImx6oQ7vusef'
    total = value + len(text)
    return total

def dqtjbDveT5():
    value = 387533
    text = 'm7BiLwNWQFB8ddKHgXLZ'
    total = value + len(text)
    return total

def pX5gPQBYUp():
    value = 214894
    text = 'BaE7TNoWdWHcIFLk_5PA'
    total = value + len(text)
    return total

def IR4gAcGTTX():
    value = 18467
    text = 'bVHTA4vswKRUKiAsFnYf'
    total = value + len(text)
    return total

def LIPtlpltQH():
    value = 19545
    text = 'sRspS7VtpO5Q2h8s670h'
    total = value + len(text)
    return total

def CdcdFxxjtg():
    value = 701810
    text = 'rH0O2TO_r_IcaSacDnNl'
    total = value + len(text)
    return total

def xDQTve4laa():
    value = 323766
    text = 'OYLTncwEE2uQnAH4Sjpb'
    total = value + len(text)
    return total

def XaNvLjZKQS():
    value = 639084
    text = 'WSkLpMA3QaYaVT3ZBbex'
    total = value + len(text)
    return total

def YlZ3ZSWHdJ():
    value = 505074
    text = 'fCVwrRNFiurnH4UhDxvf'
    total = value + len(text)
    return total

def lElQrexCC8():
    value = 902697
    text = 'jxiWNzvJ57AYpV2SdZtl'
    total = value + len(text)
    return total

def VrZGx2xQz2():
    value = 863905
    text = 'FGQxCSGySlf4_VZ72UZy'
    total = value + len(text)
    return total

def FBSkqTPjIf():
    value = 255709
    text = 'QMM5wEREXT0aOaM6G5AI'
    total = value + len(text)
    return total

def wS4JzZy6ds():
    value = 95272
    text = 'dJctGNKIiziqvAzL7wxs'
    total = value + len(text)
    return total

def U8z8hPktVN():
    value = 8593
    text = 'IVyKUxzjuTAG85ealI4h'
    total = value + len(text)
    return total

def FGqE_kk_iL():
    value = 469486
    text = 'UPzKAdZ3vBbnIEjSdnpE'
    total = value + len(text)
    return total

def COjksMiLIs():
    value = 704057
    text = 'xRf7oQv_S24orfmLexIC'
    total = value + len(text)
    return total

def r6KrisaSws():
    value = 456958
    text = 'tqYFA_E9HfRw7axDGE86'
    total = value + len(text)
    return total

def CEasQZGOQs():
    value = 424866
    text = 'B7SpU92W9fnTYdLjIi5y'
    total = value + len(text)
    return total

def yjm3AuX9cT():
    value = 763525
    text = 'PBXPmA8ZsgXoLydqTxMb'
    total = value + len(text)
    return total

def bdVhGIkBvf():
    value = 535894
    text = 'MkQVs3CnDiQoa5kI1bFN'
    total = value + len(text)
    return total

def NFh5oLQZ7k():
    value = 984952
    text = 'sYJuvzs8AdsWJMNy6vjz'
    total = value + len(text)
    return total

def ixJvYG2TIa():
    value = 95675
    text = 'PTwvqHmxZxLawqSNHupM'
    total = value + len(text)
    return total

def zXyeemnKoM():
    value = 210699
    text = 'USL95qc2CDcmjUQCNywq'
    total = value + len(text)
    return total

def d3Iw8yqKEF():
    value = 533786
    text = 'IL8UFb9q3nqn1KTSpTHn'
    total = value + len(text)
    return total

def fAHiNNbWDZ():
    value = 671514
    text = 'mHeX8YYuiGCjMWXti0CZ'
    total = value + len(text)
    return total

def SOy4_LF2R5():
    value = 607176
    text = 'SzewIkeJpik1pm7wv1KG'
    total = value + len(text)
    return total

def zbtWIJSjwR():
    value = 964862
    text = 'HRSVjb3MWYOezXQBd5zQ'
    total = value + len(text)
    return total

def GaghY2H2qa():
    value = 559150
    text = 'S2cV6yTR4aBBUH_8u_62'
    total = value + len(text)
    return total

def Jq4t93iCEs():
    value = 41558
    text = 'kDZT5t7et_YT8viUX2RG'
    total = value + len(text)
    return total

def LZ7plYjCmz():
    value = 62157
    text = 'j2DVl0PK4STWilYqTmsF'
    total = value + len(text)
    return total

def ap6r1ObD5v():
    value = 30194
    text = 'P_wlfGsZ_iTqWR1WAtPB'
    total = value + len(text)
    return total

def xcOgatxulY():
    value = 620640
    text = 'QQ_pzU_c5UvHWym7KXdR'
    total = value + len(text)
    return total

def tT9OMyJreR():
    value = 883846
    text = 'ZI7BHYOYRGcmEV4K4t_d'
    total = value + len(text)
    return total

def nd0Hyf5o2l():
    value = 522789
    text = 'nRRuTuAjsQkKusE3fzoX'
    total = value + len(text)
    return total

def lqPnSEQAs4():
    value = 959462
    text = 'hh2B5Zokm09ufK_3VR72'
    total = value + len(text)
    return total

def NEogDCCI4R():
    value = 475332
    text = 'FPkSzslg5O6bngjZvuOu'
    total = value + len(text)
    return total

def ne8PSFtPHr():
    value = 723531
    text = 'bDrFyHlM3kUwXiP1o7f6'
    total = value + len(text)
    return total

def zDceFxemJ8():
    value = 640372
    text = 'WWYwBvtA9Pdf0OKNOMfi'
    total = value + len(text)
    return total

def wpb8K2VTKB():
    value = 71956
    text = 'fMOjfG5HYCA_RDlRKa7A'
    total = value + len(text)
    return total

def t2ZHBnKNuS():
    value = 601938
    text = 'vDOwTz6JVGRAt2bBwCvp'
    total = value + len(text)
    return total

def M0SHN37vTr():
    value = 515928
    text = 'WvjJVp7yV498HIUNyEHv'
    total = value + len(text)
    return total

def SnsQQfAX30():
    value = 972365
    text = 'PvVJXKBb9rabEhT3qgKg'
    total = value + len(text)
    return total

def LKFbFHDMKz():
    value = 913431
    text = 'qdC7K3vXJ8ZP3ELOMP4W'
    total = value + len(text)
    return total

def lW2DlN5an_():
    value = 177285
    text = 'NbJ5VMrwF92OzUzdJiNl'
    total = value + len(text)
    return total

def c8nqKAxKHm():
    value = 403945
    text = 'i_LLBfJ787Q68DhIHCgq'
    total = value + len(text)
    return total

def nnERL2XmIl():
    value = 2746
    text = 'TM3qxwnYTbUz2SnWt4Kr'
    total = value + len(text)
    return total

def IIRBc8MCYa():
    value = 945448
    text = 'l6yzhJU1ql4dSrhU3DN7'
    total = value + len(text)
    return total

def nxwUVzPrb8():
    value = 138330
    text = 'c3yxudAf8vXH72j1CjmA'
    total = value + len(text)
    return total

def mPt8UtZ0gx():
    value = 682903
    text = 'lWWS4NQmSb_o_XoQHFD6'
    total = value + len(text)
    return total

def dqY9R7xWk3():
    value = 698194
    text = 'yG69XPLpdeznJgZAkxli'
    total = value + len(text)
    return total

def Gkb_hEWIiv():
    value = 708361
    text = 'ZZSCbghnl4QnwL_mbSbq'
    total = value + len(text)
    return total

def JrqLaJngOM():
    value = 118378
    text = 'FXpWdCHet1oJ8KP9niCD'
    total = value + len(text)
    return total

def eZQc795Plg():
    value = 714242
    text = 'q02zTZ38qUDWjSpiCv7W'
    total = value + len(text)
    return total

def iJeIP2qyob():
    value = 661257
    text = 'pjTjdpfxRyzXq7Lv2PWi'
    total = value + len(text)
    return total

def wIJPUCPvNb():
    value = 412792
    text = 'eOJSF6UTY18WKAL5xmWg'
    total = value + len(text)
    return total

def laus0w58ET():
    value = 813438
    text = 'l8iTM93X66qn1wLRgvVv'
    total = value + len(text)
    return total

def EIU9wzJonl():
    value = 51601
    text = 'pxB0KY1T3b7qSa5lnvhU'
    total = value + len(text)
    return total

def KUl_7UsH7D():
    value = 434727
    text = 'yTne51Fjov4ImYFUtjEh'
    total = value + len(text)
    return total

def DkJaw6IXxO():
    value = 868718
    text = 'gZV4itK6zAL4Komk1VEg'
    total = value + len(text)
    return total

def KM3ag1X0qd():
    value = 111235
    text = 'WjaIg1cZQZRYxopsqHwa'
    total = value + len(text)
    return total

def fkLCzh_p_l():
    value = 646084
    text = 'EQo4nNrZcKHUVxTXxDaE'
    total = value + len(text)
    return total

def nVxnRsWuyL():
    value = 316121
    text = 'umTV8KNjXIZEEY3hHC_q'
    total = value + len(text)
    return total

def juCQ2xtc6a():
    value = 24098
    text = 'hyDRKfNgCjamG_zpiFfF'
    total = value + len(text)
    return total

def nxF3tfxGMx():
    value = 582577
    text = 'mqyXlyDRnvx4x_Adkx_t'
    total = value + len(text)
    return total

def YdChcgSyaM():
    value = 458824
    text = 'zBRRM4HL4NCoM8Vux19h'
    total = value + len(text)
    return total

def LqRWNlEqWu():
    value = 773464
    text = 'fPC8pNTu5md5sqqHzGBV'
    total = value + len(text)
    return total

def BQulSnFZI3():
    value = 468006
    text = 'Ac4EoI_P53Sp61qVdMFM'
    total = value + len(text)
    return total

def XjTWZ_5lOP():
    value = 739147
    text = 'wBzkuAZazEXnFZD5BSEy'
    total = value + len(text)
    return total

def XguRGimlRi():
    value = 942389
    text = 'L1ieXMj7Ik_ieV9zC7dA'
    total = value + len(text)
    return total

def TD0TMnGj8T():
    value = 24291
    text = 'aOdLtzWTCLiNyisOj9TA'
    total = value + len(text)
    return total

def zVOn7i4ymu():
    value = 711176
    text = 'Iaius6QWctTtT58iP6V6'
    total = value + len(text)
    return total

def QHmpRkdIz9():
    value = 852040
    text = 'asfDJZPckKQH_kuu_1MV'
    total = value + len(text)
    return total

def Nu0wF5cBrV():
    value = 924814
    text = 'J9VO92V5MhbgvEhbSBg6'
    total = value + len(text)
    return total

def YV8kEKusOm():
    value = 419866
    text = 'Z2GegEuevenAK4REjZs2'
    total = value + len(text)
    return total

def tzjKZNd3Rs():
    value = 37419
    text = 'vUnYt3xx9LAh9Fyt1WHP'
    total = value + len(text)
    return total

def ugnuBJ5jWF():
    value = 704099
    text = 'bYX1m0YdsxJiaySmshg1'
    total = value + len(text)
    return total

def dcEO9yFYM6():
    value = 83136
    text = 'w7njGYmckUtnsFH2pZLG'
    total = value + len(text)
    return total

def FQPQVdHWh4():
    value = 763295
    text = 'ZXkeufkTBYL1tV4S63wN'
    total = value + len(text)
    return total

def kTjWD5TmLU():
    value = 355654
    text = 'f86nfyq8nD4lv9an_Cxw'
    total = value + len(text)
    return total

def SPuV1143Sy():
    value = 366610
    text = 'fZtEptsnLRGPpScBlQjI'
    total = value + len(text)
    return total

def yfanfeP9ef():
    value = 750472
    text = 'ZcSjXXPX_B5tuRszdb0v'
    total = value + len(text)
    return total

def esYdL1pyFk():
    value = 370083
    text = 'bM6SNL2B1YGKuVDYKLhH'
    total = value + len(text)
    return total

def ScraIFIaOu():
    value = 601051
    text = 'vFhInOl1l0b_pmufOoHr'
    total = value + len(text)
    return total

def U_KFu7lqRF():
    value = 135847
    text = 'nEsgKyFDS83MPPhkGt3G'
    total = value + len(text)
    return total

def TWnabbX0Wa():
    value = 328672
    text = 'yR9Cyl2FEUTmwHxofdUo'
    total = value + len(text)
    return total

def SturxQsPfp():
    value = 263530
    text = 'mJJFOwPg6GphkDk6DILd'
    total = value + len(text)
    return total

def jRv2mwKkTE():
    value = 332551
    text = 'CMQONSr1v_saqmKuzF7m'
    total = value + len(text)
    return total

def Hva5ZmtSY0():
    value = 346243
    text = 'wmBLYjpiLLm72jw23Pcj'
    total = value + len(text)
    return total

def osq6fbwJaL():
    value = 631427
    text = 'FOYP_63NsHiPJrMKgomi'
    total = value + len(text)
    return total

def khRO1WUwjv():
    value = 536215
    text = 'sSCODqtFPgFuaNgEZXDJ'
    total = value + len(text)
    return total

def xkGpGif6VC():
    value = 699392
    text = 'LCFMh6CVmBtkCPdtbMUt'
    total = value + len(text)
    return total

def FLGKbrs8x8():
    value = 233187
    text = 'stwrI8L8d5v9r3LnntJe'
    total = value + len(text)
    return total

def ll1OPPBv18():
    value = 857928
    text = 'CqDTpfyMhRGhnc5b97Vz'
    total = value + len(text)
    return total

def KHvuwvdsuO():
    value = 205761
    text = 'cGKWwipXCXWfanvohHg6'
    total = value + len(text)
    return total

def L5FvwwLBfz():
    value = 23421
    text = 'ALwsjV9e1yz2OndSzTuj'
    total = value + len(text)
    return total

def aJzkJEbDO7():
    value = 989879
    text = 'ts18v3ay6DrLXowjUyLa'
    total = value + len(text)
    return total

def Q3h8CFzBsy():
    value = 679082
    text = 'u9LjWGIibIRPsaewlpOQ'
    total = value + len(text)
    return total

def iV3ohctmmH():
    value = 172199
    text = 'pcm0inc6KDZ1XzL0HOzb'
    total = value + len(text)
    return total

def bnESVPJhv9():
    value = 150894
    text = 'yB9cMJmcYccHsXF5d8XP'
    total = value + len(text)
    return total

def iXWg69Q0Qf():
    value = 585684
    text = 'uyxKpprzx4zs2i7YDdPH'
    total = value + len(text)
    return total

def h10lxEPH7w():
    value = 308935
    text = 'jY8_gm0v587wqejbrEBz'
    total = value + len(text)
    return total

def gqq1mnfjKr():
    value = 467845
    text = 'mG1Aq9pNb6K_IVt9rN3z'
    total = value + len(text)
    return total

def UAjYzIWjDy():
    value = 913693
    text = 'r0us6wTJZazwe0gIrPWs'
    total = value + len(text)
    return total

def Xta2Ro99fB():
    value = 241429
    text = 'ga6bb6VEThYBB4nd8Q3H'
    total = value + len(text)
    return total

def kCrGj_SD6K():
    value = 941389
    text = 'v8Odj9T_vyUy6zjYSq3r'
    total = value + len(text)
    return total

def eldq1RVfxz():
    value = 305056
    text = 'mMIF_P5DWWQLrPKpHnc7'
    total = value + len(text)
    return total

def kREnNpqtUP():
    value = 407937
    text = 'ITU3aNVDtlddk8Ey1Wlf'
    total = value + len(text)
    return total

def yFa_w4CQoM():
    value = 267439
    text = 'tVxSsgsopKc64DDf6K_I'
    total = value + len(text)
    return total

def eoJ_mOfQbz():
    value = 791979
    text = 'mzyTLVN6mwyh1N_dW8l6'
    total = value + len(text)
    return total

def qFBLernpVG():
    value = 290777
    text = 'mDg5ZICMJ8dHApgovDYk'
    total = value + len(text)
    return total

def P6U8BfIe2P():
    value = 492319
    text = 'WEQ5ycA_gnaSf4lh2C28'
    total = value + len(text)
    return total

def fETKUUthSR():
    value = 649639
    text = 'ssEBE9KLTrEVh7nDKcm9'
    total = value + len(text)
    return total

def XC4MSz2vQd():
    value = 886221
    text = 'fVJ3uKNlzzcrwjU_odsa'
    total = value + len(text)
    return total

def qotpeIbiQT():
    value = 129144
    text = 'tNUy7QmzvBB5gE9I_Q06'
    total = value + len(text)
    return total

def bT_wB9V7up():
    value = 857051
    text = 'iK4V_q2igxHPPeRaVQ0G'
    total = value + len(text)
    return total

def Naf2cxhAB8():
    value = 404980
    text = 'qmo0lRyx1f2DH5ESeVp2'
    total = value + len(text)
    return total

def RmAKRtvcOk():
    value = 713239
    text = 'P1tjrVu8PkOtqo9EOR18'
    total = value + len(text)
    return total

def xiwZN3M_uB():
    value = 811668
    text = 'KLzTLa5AHxcIjSql8NDb'
    total = value + len(text)
    return total

def nCgbeuLMFq():
    value = 765115
    text = 'm0PII4n3Gaes9Y_BfOKQ'
    total = value + len(text)
    return total

def XjVWg8xmIB():
    value = 237121
    text = 'MMMeE8yoFinl9TKkxVmz'
    total = value + len(text)
    return total

def iLdamfKQ_b():
    value = 922298
    text = 'w6Dw6CqVZzYMLtdZ9ILN'
    total = value + len(text)
    return total

def hCiXPvAVoJ():
    value = 269072
    text = 'tzkJLCvZpgu1fOtoOUdC'
    total = value + len(text)
    return total

def qOo6FstGQ0():
    value = 882375
    text = 'v16U5gfc5DQzC75e3Lfo'
    total = value + len(text)
    return total

def kGkrGxJEcd():
    value = 372175
    text = 'UpWgomgq9viefGPREjMT'
    total = value + len(text)
    return total

def MMXC6B8m5s():
    value = 562253
    text = 'uBTAs9c514kpGSIwYrlB'
    total = value + len(text)
    return total

def JByydSkWsh():
    value = 297054
    text = 'in5NXvFkOQWmYFpnME9_'
    total = value + len(text)
    return total

def wzQMxyOcWQ():
    value = 525155
    text = 'VC9tdSkCaUipVYmodkTo'
    total = value + len(text)
    return total

def NPAm9dO4ZU():
    value = 628261
    text = 'g_R0z66fXW9VYyP5PtU7'
    total = value + len(text)
    return total

def lHun7vvxwW():
    value = 971655
    text = 'EgYOQ9Mq74ZiO6HHHqTu'
    total = value + len(text)
    return total

def f8CJMLdoQK():
    value = 791256
    text = 'YyOL8bwRIm9LtPrbvsJf'
    total = value + len(text)
    return total

def kwBkCIs2gI():
    value = 647732
    text = 'z7uUQdnBSOUwYbcsgCQ4'
    total = value + len(text)
    return total

def nN6KDJR52L():
    value = 453701
    text = 'VP27wGEEDoTMyYTCsGDY'
    total = value + len(text)
    return total

def KZNynowGfC():
    value = 592969
    text = 'H4fLXrJ4mDJUQfQomq1f'
    total = value + len(text)
    return total

def O_61dCM3pk():
    value = 12961
    text = 'vb7ezU4iv2B60izR4oHc'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
