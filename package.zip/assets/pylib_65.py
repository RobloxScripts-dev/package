import os
import sys
import time
import random
import string

def mcZmFLQ0HB():
    value = 534178
    text = 'n7LfhvbIaObL2o23nmtI'
    total = value + len(text)
    return total

def YHcUi23m0P():
    value = 98925
    text = 'a9UkXzVYoXoClj3aEx8v'
    total = value + len(text)
    return total

def U1w0F5lc1K():
    value = 469886
    text = 'XyYVQdbULpebaVjUTKc3'
    total = value + len(text)
    return total

def uqmk6CR8oh():
    value = 825954
    text = 'KulG_xqe2UKuttfW5Fy_'
    total = value + len(text)
    return total

def WhPaTT2Ph4():
    value = 898668
    text = 'gLQXMn9SOT5mQHr862XH'
    total = value + len(text)
    return total

def zNeduc_Nuh():
    value = 483690
    text = 'OrJfJJF6ninR9ffUxLhx'
    total = value + len(text)
    return total

def qzv6jXGyuv():
    value = 799988
    text = 'YsCIORS2ZkMyZlTS3er1'
    total = value + len(text)
    return total

def AhgZ3oc9BS():
    value = 429487
    text = 'hgbYbcdIZgSb6AvoQsfh'
    total = value + len(text)
    return total

def FjULB3mMIo():
    value = 956254
    text = 'J1pMEiNr9HOms7I74Smg'
    total = value + len(text)
    return total

def WIe4A3r9ZR():
    value = 609950
    text = 'd0l83ma50wa4q0n4d120'
    total = value + len(text)
    return total

def KAi9G8ffSd():
    value = 472481
    text = 'NbgxTbhgOx36KFvZvzdA'
    total = value + len(text)
    return total

def wrzMLDnCnO():
    value = 298363
    text = 'fy3jiTtdeal5QxQ8YDML'
    total = value + len(text)
    return total

def dIjxv5fUHR():
    value = 954588
    text = 'hdbhS1QMFnx64b9dSPM2'
    total = value + len(text)
    return total

def qi6kndVf8j():
    value = 240320
    text = 'T9cAZOc16ZlfnCuDVsiR'
    total = value + len(text)
    return total

def EI6Qrss0C9():
    value = 747200
    text = 'zVONnrgLfcCthFIdqd3Q'
    total = value + len(text)
    return total

def orNqv2BuiE():
    value = 454258
    text = 'qg78PZPb8ci9xz5J9FK8'
    total = value + len(text)
    return total

def uGM6sjHxxv():
    value = 228516
    text = 'cFMLMIIKUWzlBaiUokuc'
    total = value + len(text)
    return total

def WJ9eBgm1UH():
    value = 77361
    text = 'HOuKNVLCHV9_AXMy6Tmh'
    total = value + len(text)
    return total

def i4uY3p1MDy():
    value = 352419
    text = 'iVJI6VmDWHCimAhX6FK9'
    total = value + len(text)
    return total

def IltSl0AuSJ():
    value = 604919
    text = 'yGNnOgXWVROFRxmlyKnp'
    total = value + len(text)
    return total

def InxdIcPz4r():
    value = 404481
    text = 'PCgg_O3kwKl7SqXYzTzJ'
    total = value + len(text)
    return total

def h5KLR5vEca():
    value = 854077
    text = 'QdwQnI3Zpt4qY9DOQcVD'
    total = value + len(text)
    return total

def v7m2WzepUp():
    value = 344752
    text = 'nzee4ZKTJNubl91MqQ1L'
    total = value + len(text)
    return total

def N6rIguo28A():
    value = 665885
    text = 'h1jGqHheTHpHDPHCFIRU'
    total = value + len(text)
    return total

def mnH8B5Rbvm():
    value = 633889
    text = 'fBdz0t53mETtG3rf_0HF'
    total = value + len(text)
    return total

def SWhp5g2cgq():
    value = 805794
    text = 'u7_7Ns8JHCIeZ4YnWFrO'
    total = value + len(text)
    return total

def J7eD6VsspU():
    value = 702268
    text = 'bimKtHOfBCRU5qVNzZ6C'
    total = value + len(text)
    return total

def XiQ2EkC3IC():
    value = 471003
    text = 'UQy8rdnbqbZ4jkzpgfNW'
    total = value + len(text)
    return total

def SA8SIFouOE():
    value = 167181
    text = 'IPJ8pXGdz5xe6POSOfK1'
    total = value + len(text)
    return total

def XcBC4vIkH4():
    value = 6231
    text = 'hWgqlXvinwY5HMcAnsvk'
    total = value + len(text)
    return total

def tKQJZi629I():
    value = 804946
    text = 'OnbFl0H34qu6Lf6Tu8bz'
    total = value + len(text)
    return total

def ssQ_l75UyP():
    value = 644314
    text = 'Z14NFJdryXf7aOGktoHZ'
    total = value + len(text)
    return total

def dGq2Jtyy6G():
    value = 83666
    text = 'XTkdj6rG1P8nmcwY_JB8'
    total = value + len(text)
    return total

def xvxyd2XtSa():
    value = 582661
    text = 'Jfso_jN70_GQe0mUytQf'
    total = value + len(text)
    return total

def mUCea_THF0():
    value = 644209
    text = 'fQ9PCYzgJMeLd1OyF2n9'
    total = value + len(text)
    return total

def EFYfwWreyG():
    value = 987839
    text = 'Y7Fh62IuIu9JcpE79coa'
    total = value + len(text)
    return total

def uwhTo53mME():
    value = 210716
    text = 'ae5e5ljwR_VEtLBVh9U2'
    total = value + len(text)
    return total

def wIVXq1zQ6S():
    value = 975539
    text = 'uIhb0fELpKLD8hYRKGpI'
    total = value + len(text)
    return total

def hHnEnsdF7J():
    value = 911298
    text = 'MiirLbyJTjiNmO9REwT_'
    total = value + len(text)
    return total

def xkjZrNsXHy():
    value = 669992
    text = 'hzwawHE8cjlpg7HKUnpp'
    total = value + len(text)
    return total

def agxE9nasmS():
    value = 724298
    text = 'wH_TZxKjRRekgbzT6bnK'
    total = value + len(text)
    return total

def rJOvq7Eiqx():
    value = 202409
    text = 'zi042cqWDedZR5MldT48'
    total = value + len(text)
    return total

def xF8EztWhT9():
    value = 501624
    text = 'OBguGcGntJehvKFifW2d'
    total = value + len(text)
    return total

def HrXVV_NEiL():
    value = 302117
    text = 'f7w6sVtTvqQtyDRLvSH2'
    total = value + len(text)
    return total

def Z8YeMfNnNF():
    value = 105503
    text = 'QuvAf4lprv14GRI6OFXV'
    total = value + len(text)
    return total

def T7QQzXBlTk():
    value = 266927
    text = 'zQe8QvL5hwHe8VoHNvtR'
    total = value + len(text)
    return total

def sUIoXFoz_2():
    value = 989021
    text = 'Kar8DpDTyMQcDeGpGkPb'
    total = value + len(text)
    return total

def TeHngnb0qv():
    value = 288164
    text = 'PD3ZisSoR4Ib4qM7mTTG'
    total = value + len(text)
    return total

def BErTqAouww():
    value = 832689
    text = 'suxml2doirCHx_3yASg9'
    total = value + len(text)
    return total

def Pt0moeG7K4():
    value = 351159
    text = 'xpFv016V0998Q7Lqx3no'
    total = value + len(text)
    return total

def GQjbs5dabA():
    value = 790724
    text = 'YM3s95VuFFa8NHYDuQEg'
    total = value + len(text)
    return total

def pqO2tjP2TS():
    value = 50929
    text = 'iByrD3G0UoXWUVJ6Y4mr'
    total = value + len(text)
    return total

def JmGa99j1zt():
    value = 921355
    text = 'v34Jc6Wsf6Ukyew2Pb1g'
    total = value + len(text)
    return total

def J9dwWna0Ua():
    value = 735530
    text = 'Rgcq37yW235qWuWbiTZU'
    total = value + len(text)
    return total

def bj71ZompwM():
    value = 121831
    text = 'ZrVVL3xAHPylUqVwjH8l'
    total = value + len(text)
    return total

def GXtGZnxhUM():
    value = 513071
    text = 'gvPOcDyt0GbeeiR7NXwX'
    total = value + len(text)
    return total

def V1Y6P41TPZ():
    value = 340314
    text = 'KFBWsN0XcDXl7uRrbBLd'
    total = value + len(text)
    return total

def OXw_C2r8TO():
    value = 762513
    text = 'Dzlgqj8sjY4uJUuz_Zbn'
    total = value + len(text)
    return total

def u_hOzxd636():
    value = 314742
    text = 'q9PbJho_OBtR2sGdb1wV'
    total = value + len(text)
    return total

def XNA4xoXxjS():
    value = 516309
    text = 'Nphsxxii_Kx52QgpBHHX'
    total = value + len(text)
    return total

def hJ3P24RtYD():
    value = 366136
    text = 'XpgJSvCWqA4tfxzNa3n6'
    total = value + len(text)
    return total

def EGIrVFF9sv():
    value = 272330
    text = 'jIXgW_qr_LLsRlq2V4KT'
    total = value + len(text)
    return total

def IqCXbYLFjz():
    value = 210832
    text = 'LTnIBAgkaHEYu8r9l1Ro'
    total = value + len(text)
    return total

def t9IBb1MUZs():
    value = 147007
    text = 'lJpynPH9_aqufhV9R5CF'
    total = value + len(text)
    return total

def m52Cyx6BYy():
    value = 191473
    text = 'gvdqmRXC41BTO3elCAqM'
    total = value + len(text)
    return total

def iT9vKv6QW9():
    value = 979015
    text = 'pNuH5iaH18njaPFwoMYG'
    total = value + len(text)
    return total

def foxzQ9mVLa():
    value = 247225
    text = 'UQXpiC5kSAANtvDC9fOz'
    total = value + len(text)
    return total

def WVpAJ69es1():
    value = 223187
    text = 'zwLON9R5009RHipcT0rh'
    total = value + len(text)
    return total

def FMeQBngKtc():
    value = 828040
    text = 'kUCraWNFVYoj6atYD75L'
    total = value + len(text)
    return total

def Z3rMmm2k_2():
    value = 818100
    text = 'nxMCojCjGHeoq6iFbdvt'
    total = value + len(text)
    return total

def i3cxlq3NrN():
    value = 282613
    text = 'BuRsevQ2FrpUrpUmr5b_'
    total = value + len(text)
    return total

def pTmFd3ShvM():
    value = 817356
    text = 'WjFHZ3enJncgCvcdLUed'
    total = value + len(text)
    return total

def ZxDxGNVMef():
    value = 59375
    text = 'KzmNFj6ZUUmF5M5iZmLX'
    total = value + len(text)
    return total

def XH68_6zJvK():
    value = 738072
    text = 'rXfMcSqZGF3yngxW8Ycw'
    total = value + len(text)
    return total

def f1EvtBz9wA():
    value = 873643
    text = 'JMTjf599bAhHVz65RX6o'
    total = value + len(text)
    return total

def SArAQkAhfS():
    value = 69849
    text = 'gBJr4MCRuSDcSscCqpAC'
    total = value + len(text)
    return total

def Wp_aX130vN():
    value = 854742
    text = 'FHH8tstbsNDjecVDFhJS'
    total = value + len(text)
    return total

def n3WWTgPZ4A():
    value = 556334
    text = 'XJfL_s8CgWpOK8tvODd_'
    total = value + len(text)
    return total

def rUpFSu_ySl():
    value = 97027
    text = 'rc2vvQHOijFURWch2uIY'
    total = value + len(text)
    return total

def twa8EMcOd6():
    value = 524728
    text = 'tbq2LmeolletUu0HBysc'
    total = value + len(text)
    return total

def xi7BY4zUjD():
    value = 436069
    text = 'LuqmnoPLxKuXueiHWx8K'
    total = value + len(text)
    return total

def JNzaQlEkxA():
    value = 344471
    text = 'VAl7SHfyxcvC3DFjDeQl'
    total = value + len(text)
    return total

def WY8tns5P6L():
    value = 111255
    text = 'dFJVwZLxR3zOmvUbfaTu'
    total = value + len(text)
    return total

def GjZ_G3bPmk():
    value = 949344
    text = 'Td4DUiiLzRS9suMM_jpt'
    total = value + len(text)
    return total

def cYjIpZNj9s():
    value = 779601
    text = 'lnKs99U8tQDdAjRhoPaO'
    total = value + len(text)
    return total

def HHXLDOCaz1():
    value = 743387
    text = 'bAlqVQzESkBddojqqLG_'
    total = value + len(text)
    return total

def n377v6dMXt():
    value = 641086
    text = 'jahiBKlhFVfO2uQs3nPb'
    total = value + len(text)
    return total

def osgAZFuTDA():
    value = 60852
    text = 'gy1EyemVolFSK2mnzoGa'
    total = value + len(text)
    return total

def d0KWS2gCci():
    value = 756839
    text = 'jPaLFzRZOHy5DyQlwAw1'
    total = value + len(text)
    return total

def v1t5BwRBu9():
    value = 645490
    text = 'GeAK9XcSB6RCaaFr1TMc'
    total = value + len(text)
    return total

def d_piCsrHH7():
    value = 928225
    text = 'jG9LpAZ8PgmBfobvof5Z'
    total = value + len(text)
    return total

def whnzfaxMkQ():
    value = 278702
    text = 'OICaGDaSoennCF7YsUJu'
    total = value + len(text)
    return total

def JyDnnxvqhH():
    value = 282269
    text = 'w4QrsIfidn_WczSAPflV'
    total = value + len(text)
    return total

def LPrJ3x62yY():
    value = 989742
    text = 'FZQtHPOAa4vFg7_8Z7Au'
    total = value + len(text)
    return total

def MK5V9StYIo():
    value = 215478
    text = 'Knq42_M_2jtg_ke1c1Bi'
    total = value + len(text)
    return total

def KUHLo2ukQ_():
    value = 283326
    text = 'UbgNJTbcgHjQsiyIa3sP'
    total = value + len(text)
    return total

def IbAeUf8NF5():
    value = 702838
    text = 'FwBFTAFJpdCRiAFtVZTd'
    total = value + len(text)
    return total

def Ry54FqT3MJ():
    value = 271602
    text = 'EDaDkhoCW_16yuDmXuS4'
    total = value + len(text)
    return total

def Rb5LTbj1ed():
    value = 367910
    text = 'fPLGOFkcGWt2P2Njnk87'
    total = value + len(text)
    return total

def JWvrqm419r():
    value = 492615
    text = 'Y86_QpkMmV5bZ51zcUek'
    total = value + len(text)
    return total

def Rz8E9sy9tL():
    value = 982957
    text = 'gDX471wWYYJatWMJQdfg'
    total = value + len(text)
    return total

def HeBPZtZTxH():
    value = 856092
    text = 'gJBmsZhUF98DOrwNifFL'
    total = value + len(text)
    return total

def J9cocIfP4r():
    value = 238147
    text = 'Q9zJW0ZoIF2hrgFkmmGL'
    total = value + len(text)
    return total

def uHeRj0qrYO():
    value = 258630
    text = 'HnqmWNhBgyVA0tkn3lHD'
    total = value + len(text)
    return total

def gWkEgGDQot():
    value = 993352
    text = 'iHWUSU0M2Yvo22TEiZED'
    total = value + len(text)
    return total

def cqoK4lrvt_():
    value = 264195
    text = 'RMsBf9i8rW_Iu5I91DNB'
    total = value + len(text)
    return total

def Bw4pxWy937():
    value = 644450
    text = 'FFh8iFAXJ_TEkjFlzdBQ'
    total = value + len(text)
    return total

def gEanzYKR_4():
    value = 862111
    text = 'rKkFM3TCNiyxr_PckKFN'
    total = value + len(text)
    return total

def isR4ttFMC0():
    value = 355320
    text = 'NOsUgomYRXHHbOOzHuwe'
    total = value + len(text)
    return total

def Vs_d6v8tRw():
    value = 674255
    text = 'zQUIrpNAj_txuaBhz6DR'
    total = value + len(text)
    return total

def PKHdPZlx3B():
    value = 783722
    text = 'OVaHB8BMegHJlC3aQ7vj'
    total = value + len(text)
    return total

def LGnsWeyWFj():
    value = 440833
    text = 'EklB_T2DbV4bNPZiG4__'
    total = value + len(text)
    return total

def JYL9RCe7IP():
    value = 774601
    text = 'GE57iyyr8rHgczOw3aL9'
    total = value + len(text)
    return total

def fP5Wk5yOpK():
    value = 223130
    text = 'Pwo4tPC7T50MaaIvGnSL'
    total = value + len(text)
    return total

def NC6pwwjVPm():
    value = 274356
    text = 'hXqm9CM5HU_i0yVUJJw3'
    total = value + len(text)
    return total

def PQ_IYYQKW0():
    value = 557657
    text = 'MlGXEC4L2xOW05UZzsFu'
    total = value + len(text)
    return total

def CoYplAIYOd():
    value = 326511
    text = 'ggeidaGtOcGdvewaiZyj'
    total = value + len(text)
    return total

def yxt5lkposX():
    value = 680358
    text = 'R8HL5XlRvcim67RRFb4O'
    total = value + len(text)
    return total

def jCTIgpXCEA():
    value = 178558
    text = 'QSpFAJyjoUD6C1yUtKRR'
    total = value + len(text)
    return total

def pEcqTBVksh():
    value = 226365
    text = 'yDrL6zS1FzJoIGy9zYMf'
    total = value + len(text)
    return total

def SrU6QALmhR():
    value = 91038
    text = 'qoAAo7MTv6Si179bGcGT'
    total = value + len(text)
    return total

def ib5k6U02Q4():
    value = 382474
    text = 'Cpot2vWYSjLKRTpkwvCM'
    total = value + len(text)
    return total

def z3xqxuypcq():
    value = 987301
    text = 'zOi7ehOCSPvgmxSzFvGj'
    total = value + len(text)
    return total

def t2QySbc1NN():
    value = 341041
    text = 'rModZ6zDNRy05es6dwaR'
    total = value + len(text)
    return total

def y7b8eC7lng():
    value = 875985
    text = 'Dad4Nzo8sj0J5zbG5jZW'
    total = value + len(text)
    return total

def ys9Tl5vNME():
    value = 978772
    text = 'BO5SlOAdTAmIdlDG1TQe'
    total = value + len(text)
    return total

def BiRkFJEte_():
    value = 478576
    text = 'ljsV84FpKz0zgmSgpwXl'
    total = value + len(text)
    return total

def byFAYDSaLw():
    value = 772635
    text = 'gi9kUVKvVm9uSh4jlOnX'
    total = value + len(text)
    return total

def gXqfyGu_Ni():
    value = 44892
    text = 'l0vfPHEBznyFwLNzZZmL'
    total = value + len(text)
    return total

def nB7HGp9DUh():
    value = 430704
    text = 'Qr7MogukDko6GZ0XOAE2'
    total = value + len(text)
    return total

def c1PBseWi76():
    value = 465774
    text = 'xpazZttIe6wKYGkehd_1'
    total = value + len(text)
    return total

def rUc0P_XQDy():
    value = 907238
    text = 'DcOP5dcaz4uoORqaHc6R'
    total = value + len(text)
    return total

def SS3Fc65d6X():
    value = 686433
    text = 'ydVOV0RGiZCNFaeMp5Zc'
    total = value + len(text)
    return total

def yLFIZYqKAv():
    value = 667027
    text = 'v9I0XlphGRLicj3xtVCd'
    total = value + len(text)
    return total

def krFlBbUHU3():
    value = 902229
    text = 'lFpKRikd1zoj4PHdeW0E'
    total = value + len(text)
    return total

def MkSRTqOXNy():
    value = 93886
    text = 'KLlTD7KJ8051xgGfvX2m'
    total = value + len(text)
    return total

def FNJFd2sm_K():
    value = 214485
    text = 'Dn2UK5UPCcpYDM4GIfpe'
    total = value + len(text)
    return total

def RlY4Ig95XF():
    value = 411940
    text = 'W6hhWUNtcW13FGL1bHX1'
    total = value + len(text)
    return total

def t4bXqIxQq0():
    value = 420065
    text = 'svrWgZhCByeXf5ZK8kco'
    total = value + len(text)
    return total

def aQtH_90UsX():
    value = 279283
    text = 'o2qAjY7lMCAy2sI3e6Vy'
    total = value + len(text)
    return total

def gVJWk_Qk4s():
    value = 822114
    text = 'G8ilwA9arfxr_I17WpzP'
    total = value + len(text)
    return total

def fZ9Bm0jKso():
    value = 466316
    text = 'Thr_GJMo_joqkGeyeS3o'
    total = value + len(text)
    return total

def NMLWjVezMj():
    value = 917328
    text = 'QdmQkzcKUzReMGWzN27v'
    total = value + len(text)
    return total

def mvOGHNTGvF():
    value = 2228
    text = 'cJWnr6iyusIcxhyIXYW6'
    total = value + len(text)
    return total

def HYh4Noa2n_():
    value = 19626
    text = 'zPid5TLg68mb23Bu3s4q'
    total = value + len(text)
    return total

def Slyf8eexP8():
    value = 292169
    text = 'I1oj9N_draLxlYSYXhzt'
    total = value + len(text)
    return total

def iLcaaIwoVa():
    value = 453671
    text = 'MNSeVQo09330TiRcjttc'
    total = value + len(text)
    return total

def MWEqQp3ykE():
    value = 337765
    text = 'GuUYGVlIu7iu2KxFXxy1'
    total = value + len(text)
    return total

def DS_KN6Qo4X():
    value = 922736
    text = 'YLFkCxjpkvkdgVCPjyBL'
    total = value + len(text)
    return total

def rcn9GyfALc():
    value = 695655
    text = 'FCpgsp4rs2Ao1MrrdndE'
    total = value + len(text)
    return total

def BJW7AcXm7M():
    value = 310778
    text = 'C4yK2X5W_7Kfd1d8S7Sq'
    total = value + len(text)
    return total

def H7apgZovcu():
    value = 699317
    text = 'kF7qRhSpB10N4DS8lB6L'
    total = value + len(text)
    return total

def sGquGiphQO():
    value = 589251
    text = 'p1d7DgPP7agLZin_bhVD'
    total = value + len(text)
    return total

def EsmxwqXDg4():
    value = 810760
    text = 'p3eNxtb5vuVrBoSyo8uX'
    total = value + len(text)
    return total

def bPpRIeP7yQ():
    value = 172302
    text = 'TTwYq3h_JLQgiDPUSXBA'
    total = value + len(text)
    return total

def PYYHqR6Ls0():
    value = 102317
    text = 'byKvmDW2MFOCmHg2nqY4'
    total = value + len(text)
    return total

def ujoOUsGPqb():
    value = 962539
    text = 'Hu7jB4Po7E7Sdj4Xb95p'
    total = value + len(text)
    return total

def QyU9npNybH():
    value = 423436
    text = 'QylcRwfL_IxYEVMKT6Jj'
    total = value + len(text)
    return total

def Y5ZD9Oqi5y():
    value = 940513
    text = 'mVY3eI_ySYsNQDdKcAN1'
    total = value + len(text)
    return total

def FneQ_6kdPP():
    value = 399347
    text = 'OvBVJo4sRNsEAHXrBLig'
    total = value + len(text)
    return total

def I_uXK3xvXy():
    value = 556717
    text = 'ix76AKhApjKyR5YzePL8'
    total = value + len(text)
    return total

def EplIKWaOel():
    value = 411491
    text = 'nQjKZL9s5QhW0_RdiluA'
    total = value + len(text)
    return total

def oJ7Psxh0_i():
    value = 225842
    text = 'ab8Gszz6RBtNlxwqv90K'
    total = value + len(text)
    return total

def mGQtAFXQAi():
    value = 887688
    text = 'F7dF2WQSMGMYmRn5V2J1'
    total = value + len(text)
    return total

def uSKFtNSkE0():
    value = 544720
    text = 'UFbEiplBlKZrs_anVjn6'
    total = value + len(text)
    return total

def Eqab0u0ctp():
    value = 961881
    text = 'Q1BJBIWoBYC5gvZv8jgy'
    total = value + len(text)
    return total

def OnO4h0h2nj():
    value = 392264
    text = 'mn8_JHY9OjxqlmPfCcDD'
    total = value + len(text)
    return total

def QkEsSGqRVI():
    value = 673495
    text = 'pc_Vjx_R3lWcDVll4ErU'
    total = value + len(text)
    return total

def bQGxsqdp44():
    value = 387645
    text = 'GosED7QaYs8bIXGvnqvM'
    total = value + len(text)
    return total

def WB7O4wOYkh():
    value = 22164
    text = 'CmOlDzsHlt5bbK6CUQRV'
    total = value + len(text)
    return total

def jxhx8PjiAX():
    value = 436591
    text = 'C1bCxggggJuIYOeGsPeD'
    total = value + len(text)
    return total

def lXKmHBuvDd():
    value = 856743
    text = 'l7mppeOqif6gWB7qwdeK'
    total = value + len(text)
    return total

def STc4sD1A_u():
    value = 916048
    text = 'zajEi9UyMjIkoWWtpUZ4'
    total = value + len(text)
    return total

def kHg8O2amYv():
    value = 286875
    text = 'MqNCDSxWLMQYZZpF15JB'
    total = value + len(text)
    return total

def RsOVjaGITh():
    value = 620780
    text = 'hiSMQCvzJcESBHvSwaie'
    total = value + len(text)
    return total

def DZpoq_QgoI():
    value = 940155
    text = 'vA7QLVqfhbg9ho71nDb9'
    total = value + len(text)
    return total

def X99PmQaIpa():
    value = 503282
    text = 'qcj1MuwqWwBDibnCMDu_'
    total = value + len(text)
    return total

def K3zgJopmZE():
    value = 656045
    text = 'QtWAEYBU72ickAUJQ0cJ'
    total = value + len(text)
    return total

def HRyHShHMLj():
    value = 634002
    text = 'e5nxEQnegFyYjnUqKNDc'
    total = value + len(text)
    return total

def rz1t2dPVsF():
    value = 974741
    text = 'LLc4lRxbiNASRIftxOCo'
    total = value + len(text)
    return total

def jHItQW6yS8():
    value = 756233
    text = 'VOUlmMVDnUrsbtyxI9Lp'
    total = value + len(text)
    return total

def UxHHubUkY3():
    value = 553253
    text = 'OQGt8la2kHhHet_V4Jdw'
    total = value + len(text)
    return total

def P6oeW26ySK():
    value = 287332
    text = 'xnYpUEqZQEidXEE9q2lN'
    total = value + len(text)
    return total

def P9OcXx7slR():
    value = 563758
    text = 'o7ZiksYhJj7HZjUrlDlu'
    total = value + len(text)
    return total

def QGdAIajF2D():
    value = 676642
    text = 'UDcOloNW88pAuOVR1KxJ'
    total = value + len(text)
    return total

def GWrZoPGhWL():
    value = 733468
    text = 'HSqMsyJnKpuAxdqH5w5p'
    total = value + len(text)
    return total

def rrFtlLTO4T():
    value = 764338
    text = 'zdzWSj2JkFjDpFvQycPe'
    total = value + len(text)
    return total

def NlSez7qSLl():
    value = 128489
    text = 'iW5Qg9zYSBkOLHt2R3qk'
    total = value + len(text)
    return total

def yNuYy9sIV2():
    value = 144560
    text = 'Hg4i98ytAcmsaQsOO8gG'
    total = value + len(text)
    return total

def gbPXMPgSD2():
    value = 147303
    text = 'XtW5juvOoICA_VjLidh9'
    total = value + len(text)
    return total

def hWyE7CEJN8():
    value = 452384
    text = 'k9NOYxX9XB6gv_fJ1K1b'
    total = value + len(text)
    return total

def tKzr74EmpT():
    value = 956232
    text = 'Op4bjKiouugVqGJSItMC'
    total = value + len(text)
    return total

def WmWlIraQfs():
    value = 654223
    text = 'zHjDyZImM2gcL36psg5z'
    total = value + len(text)
    return total

def maQpaMojch():
    value = 783305
    text = 'RNK91v0tv0e5RR24yXV1'
    total = value + len(text)
    return total

def xMri2J6MLu():
    value = 446499
    text = 'QBj5cQAcUAH7sA_KumtT'
    total = value + len(text)
    return total

def XrZ5CXqchV():
    value = 697266
    text = 'CFeWRl6dCYqtcJGwbUsO'
    total = value + len(text)
    return total

def IUfxYhdmuu():
    value = 498165
    text = 'DNiFKw9NCLNjB5jjeJ8g'
    total = value + len(text)
    return total

def xNBhZekdUy():
    value = 536147
    text = 'gZHtTz28nX5oSdjhePcK'
    total = value + len(text)
    return total

def heHm7OhPHb():
    value = 15415
    text = 'JhrumRS05M278xE1TyFp'
    total = value + len(text)
    return total

def sAbhR23nl4():
    value = 861594
    text = 'MX9smy5QfkWdw6plzcOd'
    total = value + len(text)
    return total

def oFMBjkDAvo():
    value = 924200
    text = 'ZMmPI4WcajZWT6AKtgIH'
    total = value + len(text)
    return total

def n4KpnaHPii():
    value = 394809
    text = 'd6cVypYXnaO99JOaDga2'
    total = value + len(text)
    return total

def b3hkKAlBJL():
    value = 645040
    text = 'VwfaAt0odjoT74lQ0gSg'
    total = value + len(text)
    return total

def D0go5chVu_():
    value = 741990
    text = 'zwDvASc0eII07oA8ERLQ'
    total = value + len(text)
    return total

def ZSfU0ZfrAD():
    value = 924718
    text = 'WmqxDxwVDOHFhLrMUr7X'
    total = value + len(text)
    return total

def xLwYJOa67N():
    value = 662684
    text = 'Z43cIs1nl_6ZO3kGFKks'
    total = value + len(text)
    return total

def GdCehu1dKY():
    value = 208219
    text = 'vgZFSJL3qbobixlOsE38'
    total = value + len(text)
    return total

def jWYYMb3zuo():
    value = 468324
    text = 'GOlas3NQ9JqKddYVSdj3'
    total = value + len(text)
    return total

def p5sG64xy7a():
    value = 708389
    text = 'On34mpkABty9mKQ0GkOw'
    total = value + len(text)
    return total

def SkYbaOdpvA():
    value = 739965
    text = 'toLNokDFp2b4WaFeLxCN'
    total = value + len(text)
    return total

def ZRIsfM0Y59():
    value = 89567
    text = 'viyEGyIlysjQc9jCBYK1'
    total = value + len(text)
    return total

def ggIm9KwJp7():
    value = 810921
    text = 'hPyKTGiwSXhVhxbYXQkI'
    total = value + len(text)
    return total

def qnHPHPFky4():
    value = 71023
    text = 'nllZ8ZbLgaJ2R2u3fXTn'
    total = value + len(text)
    return total

def DAXZsXEkBV():
    value = 773164
    text = 'Eim61x2YiENyoWRhk5Aq'
    total = value + len(text)
    return total

def fQfTkvD9LG():
    value = 570917
    text = 'HqqdPM_KaVI9BHiLjAJv'
    total = value + len(text)
    return total

def wttL5doff9():
    value = 141118
    text = 'h504MLbUmKh36nPLS9ax'
    total = value + len(text)
    return total

def HfigCvlt3Y():
    value = 289086
    text = 'Z07Oum3nCDULD8HgOWKI'
    total = value + len(text)
    return total

def W3xNiuu8Ia():
    value = 120107
    text = 'ElTMywF9xKEdofkr8q6I'
    total = value + len(text)
    return total

def L8eEOYdeMd():
    value = 577323
    text = 'zyn8QynFMVjT9HNh8xnm'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
