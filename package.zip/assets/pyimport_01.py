import os
import sys
import time
import random
import string

def k3GgGg8UpP():
    value = 377888
    text = 'qgLqeOyB_fJIwQGRKTGb'
    total = value + len(text)
    return total

def b5sN5OXAEq():
    value = 474864
    text = 'gNWBpFY1LdhqeC9BhBye'
    total = value + len(text)
    return total

def qNr1XX4sFI():
    value = 376668
    text = 'nB2zkZ5Xgbir2AcbUvaj'
    total = value + len(text)
    return total

def q6wiU9WRTK():
    value = 262666
    text = 'giDDcYytpaspk8v6Y9ix'
    total = value + len(text)
    return total

def ReIs_BdXvC():
    value = 915795
    text = 'v4mOd16tfCb62M1fbOYk'
    total = value + len(text)
    return total

def lEqR6UJm_M():
    value = 470218
    text = 'ULDH8gkbI8yozV8bO0W9'
    total = value + len(text)
    return total

def Qj7PsShhGv():
    value = 112400
    text = 'N5w9Ppu5AyVCVQNPmDjG'
    total = value + len(text)
    return total

def NQ9GqEkQpm():
    value = 472307
    text = 'FCbDVzLijID6aD18Ij4P'
    total = value + len(text)
    return total

def dvUiY7d978():
    value = 91339
    text = 'mymxizBxGQaqDlOvg8Dd'
    total = value + len(text)
    return total

def dAH3vTg2x1():
    value = 407680
    text = 'JzGCBbSoKLaxR_J9GvdJ'
    total = value + len(text)
    return total

def fDKbjl5EUq():
    value = 14056
    text = 'NXgqe4lDS73rLXC0jgvT'
    total = value + len(text)
    return total

def G8Le_ytEwR():
    value = 720291
    text = 'KNdDrEwXGi2E5tAfKTY7'
    total = value + len(text)
    return total

def tN5xaGQtCf():
    value = 83203
    text = 'fIPPjd7eAMqg6lmBO16m'
    total = value + len(text)
    return total

def CSMuk56rG3():
    value = 427947
    text = 'h7kJosQ088UTQ4vZb78o'
    total = value + len(text)
    return total

def PYaidHbnSz():
    value = 203692
    text = 'CnDuO_pDDtElpDs63UgM'
    total = value + len(text)
    return total

def T8YvXoBI4U():
    value = 379947
    text = 'vqGKOsXA1kjzhahOHvVA'
    total = value + len(text)
    return total

def Uo02W3Keay():
    value = 496105
    text = 'Qhq2UtUeozryd6Fhnojq'
    total = value + len(text)
    return total

def iBXBldjFfo():
    value = 936489
    text = 'nJa07wR8_IJU9a1xDIQc'
    total = value + len(text)
    return total

def FtPkNMZpOk():
    value = 76182
    text = 'wYKNhaF1RSP8y8AsBhrV'
    total = value + len(text)
    return total

def oSt7hdpk0q():
    value = 237503
    text = 'ltS2bXgXSNXzNqmVTvln'
    total = value + len(text)
    return total

def RcLVYjTVJf():
    value = 385792
    text = 'KhDcHnFa3uMURowp4naG'
    total = value + len(text)
    return total

def WfVN_VLgXn():
    value = 66289
    text = 'Oq6WpBTbeXkfPTcADulV'
    total = value + len(text)
    return total

def z9IUI8p7AF():
    value = 440543
    text = 'bT2ixZK00iLHrqN0r9sq'
    total = value + len(text)
    return total

def Hz9kGMs_An():
    value = 392206
    text = 'mxem03ZEqzY6fbfNYBXW'
    total = value + len(text)
    return total

def pXmG1PDxYN():
    value = 707876
    text = 'wW2vyyYpYVkvn8ttI3o8'
    total = value + len(text)
    return total

def xUfWYeLvsA():
    value = 345291
    text = 'JObrN7dfIK4NQbKDYEMD'
    total = value + len(text)
    return total

def wOxVDOL7ne():
    value = 807271
    text = 'H9SmltSJbs_p4Qbhub3F'
    total = value + len(text)
    return total

def IHEaB8r9e4():
    value = 313237
    text = 'gCTk03iQwvWNaCFReBD3'
    total = value + len(text)
    return total

def njzRJE55YM():
    value = 144592
    text = 'Ye677eln9olFuTDsfIb2'
    total = value + len(text)
    return total

def V7EFOtE1DL():
    value = 614263
    text = 'kK4a4eeMHg6urgGAgm1L'
    total = value + len(text)
    return total

def YccJ3rKztl():
    value = 412615
    text = 'a5XclSM1Ptsn2Qks5sBJ'
    total = value + len(text)
    return total

def B1G9tOmAvx():
    value = 761944
    text = 'r1bxhSuTE3fDllRsoKNz'
    total = value + len(text)
    return total

def p_io6MWrEQ():
    value = 772405
    text = 'aKdRUrvxeUxGKkpJNvv3'
    total = value + len(text)
    return total

def IsAkXa6Iae():
    value = 172280
    text = 'XEZOSMUlD00B_89UVYGm'
    total = value + len(text)
    return total

def CaSo37AGpn():
    value = 10407
    text = 'fMUV5OPeaIg5dwu3gnJk'
    total = value + len(text)
    return total

def MmLTBpJo2k():
    value = 136956
    text = 'rwDHnqJXdmVPdB6w8HzH'
    total = value + len(text)
    return total

def Ibv_Y9mo9i():
    value = 982899
    text = 'H0ocEMXxDhIEdHue3MLd'
    total = value + len(text)
    return total

def zL28zV5Bi4():
    value = 500790
    text = 'PVuawhxXXYG03B5IqNVp'
    total = value + len(text)
    return total

def wciTOPHFe0():
    value = 555568
    text = 'xdXehsFoIcA1USDQabNp'
    total = value + len(text)
    return total

def xMSlpfISiE():
    value = 376990
    text = 'PEI1cWl3uSVD0EQZOyDS'
    total = value + len(text)
    return total

def taux4yGxVW():
    value = 574249
    text = 'XhXh7Gl9mUjBfvwHceRq'
    total = value + len(text)
    return total

def xyUMCANnEO():
    value = 503070
    text = 'zAGoorfgHjcTiaMEF_zI'
    total = value + len(text)
    return total

def c9EXsin1Rc():
    value = 946417
    text = 'Fx6pzvovz8OuAKVjXuc8'
    total = value + len(text)
    return total

def VElZ402Lvd():
    value = 679502
    text = 'WU1fvUdbcTLg99Wbx3DC'
    total = value + len(text)
    return total

def gPKBXrtaWf():
    value = 854494
    text = 'abBuAU3yigExK8K3wshK'
    total = value + len(text)
    return total

def jwwmzz_Bcc():
    value = 718330
    text = 'HOsWxn1Rh6zVFPjwOdUJ'
    total = value + len(text)
    return total

def xo1b7HG1Ew():
    value = 945327
    text = 'BCf_NoZiXuUUjvsLiT9O'
    total = value + len(text)
    return total

def fCHFQ6W7FT():
    value = 362293
    text = 'jTX4xxlisr9pT82RFfmk'
    total = value + len(text)
    return total

def YfDTFgEPut():
    value = 577892
    text = 'v9OHXVCJK5gw_IJoydNe'
    total = value + len(text)
    return total

def uaShPMyEw6():
    value = 885116
    text = 't5L5Efqg2gLb38rzH3a3'
    total = value + len(text)
    return total

def ri3qBiFcS7():
    value = 388201
    text = 'IYpRvr6om0PNAUYeNkwA'
    total = value + len(text)
    return total

def ivAvgyi8mG():
    value = 398218
    text = 'NkRULAQ5_yyivLAOD3fJ'
    total = value + len(text)
    return total

def LBUqiOBtpG():
    value = 837612
    text = 'dWOr1U7Xk9IfJ65FY0bt'
    total = value + len(text)
    return total

def dNQUSgkBE_():
    value = 605356
    text = 'shFiQj90od7ccBcjgAAE'
    total = value + len(text)
    return total

def dkmu1zoQ00():
    value = 411553
    text = 'fOGJsm40ffsM3Qec9_SY'
    total = value + len(text)
    return total

def JOA8wpFPbs():
    value = 502775
    text = 'aoA7HVUUY2YtuD7MFvc8'
    total = value + len(text)
    return total

def sJDd3iYN_k():
    value = 891683
    text = 'MuPqOFE2CYdJxbZYEmQu'
    total = value + len(text)
    return total

def BnpNGaaZD6():
    value = 811556
    text = 'LCVaLbXzg9gBZ_GYH8AO'
    total = value + len(text)
    return total

def XJzzkRVt0U():
    value = 741184
    text = 'zxuQghuCbKWhpUjAoi3N'
    total = value + len(text)
    return total

def N2OQs6gbhf():
    value = 672116
    text = 'esjce14rXRy0jnO1OjBC'
    total = value + len(text)
    return total

def Zc3bUtw9KP():
    value = 497901
    text = 'cb0yKWBjq0j8QIjioHrV'
    total = value + len(text)
    return total

def l5ajwzggeY():
    value = 897955
    text = 'iraFwJpflvUfYqpurCIw'
    total = value + len(text)
    return total

def Sfp91mGDZw():
    value = 81929
    text = 'vKgX49eAJ7Hp_PPgIxrQ'
    total = value + len(text)
    return total

def Lp1_Pwe9FB():
    value = 868998
    text = 'TB0w5lKP0TMGWJMuv3e2'
    total = value + len(text)
    return total

def yuRNu_ovp3():
    value = 320733
    text = 'Lkn8TuLuUU5XgpQGyMyK'
    total = value + len(text)
    return total

def z0roLAzJIY():
    value = 188363
    text = 'KQDBzp8h4mJzh91TlguI'
    total = value + len(text)
    return total

def bxvstS8yY3():
    value = 524180
    text = 'RZMvxo03uYptaIMqjmNm'
    total = value + len(text)
    return total

def wE1kvmpnxI():
    value = 122665
    text = 'YE0ZoMWcIM6bXzbjkiN1'
    total = value + len(text)
    return total

def SldBWjCHp8():
    value = 24884
    text = 'nJlmXsNwPgDCq33IiQCs'
    total = value + len(text)
    return total

def nNlP7KWMZA():
    value = 463154
    text = 'qhzCy6YrrUNbMvhL_inw'
    total = value + len(text)
    return total

def tPNJO867W3():
    value = 894427
    text = 'JKMPY9oxh2VRfqDqskl9'
    total = value + len(text)
    return total

def id80G95olH():
    value = 757602
    text = 'f3oJ4pl0M1Q4GO4JwFFU'
    total = value + len(text)
    return total

def VQuQ1AHnKy():
    value = 503706
    text = 'kv4nqIfGi6Jz_8fnbzqu'
    total = value + len(text)
    return total

def Sf2WUxSmmG():
    value = 76972
    text = 'ZztT0ngmiCGCTuwvsTEI'
    total = value + len(text)
    return total

def Tmu6ou48MM():
    value = 122684
    text = 'DA0vn9329kVW8t4IG8lJ'
    total = value + len(text)
    return total

def osHTennEJq():
    value = 421351
    text = 'sTo2fcROCBc8wjnWU8cw'
    total = value + len(text)
    return total

def vsB3Cnqe8s():
    value = 302740
    text = 'dWpbfyCJ6232mq5VxKpn'
    total = value + len(text)
    return total

def DXr1JvvIVp():
    value = 600556
    text = 'Z_GlM5YR6NfKoSDijeip'
    total = value + len(text)
    return total

def LhNpDouEcE():
    value = 747076
    text = 'tKLwcHUT7Xwg6D5HBGbZ'
    total = value + len(text)
    return total

def fK8wlt0dHE():
    value = 894733
    text = 'RKN0ewu_7VSCo7AAk4gg'
    total = value + len(text)
    return total

def zf6Jmdu7wK():
    value = 790576
    text = 'B9IQsx9KXjeZoJnHO02G'
    total = value + len(text)
    return total

def KCPiRKpGtn():
    value = 80608
    text = 'OaWBeo79Jl_2v7hfqmtT'
    total = value + len(text)
    return total

def U4gcodwAth():
    value = 755138
    text = 'Lxdy0QLheqwSvs85d6hr'
    total = value + len(text)
    return total

def HfgRnpHcg0():
    value = 901622
    text = 'FNrU0eVqdefb8qCKUYEu'
    total = value + len(text)
    return total

def MedqMYSVWn():
    value = 228648
    text = 'oTGVfiOfoejCkOke0UFl'
    total = value + len(text)
    return total

def fuUwXVBL30():
    value = 164639
    text = 'jqAos2EaoRXOiRBzIHiH'
    total = value + len(text)
    return total

def Euc30oNpPg():
    value = 73824
    text = 'bN3HA9s9cB0d5XS1w28J'
    total = value + len(text)
    return total

def u6l5d9HEM3():
    value = 263098
    text = 'uAIanVF6DZ0SAf4puqLa'
    total = value + len(text)
    return total

def X2vrzjACbt():
    value = 892593
    text = 'pVLkRkH4kZ0uq187tbyy'
    total = value + len(text)
    return total

def jzb8g7yr82():
    value = 966805
    text = 'Wqha77yJK4HTSosyOkbn'
    total = value + len(text)
    return total

def WHy4hi00s8():
    value = 348069
    text = 'vJVshm1QKBPzhIXpb6xa'
    total = value + len(text)
    return total

def ckD1wmWKYX():
    value = 703596
    text = 'UUas4uRhIbO5iX4hTZOp'
    total = value + len(text)
    return total

def ZaAn2QvfDO():
    value = 94693
    text = 'gd5dDEhquvPUlIXEPoT_'
    total = value + len(text)
    return total

def tGSQXoY3o_():
    value = 984121
    text = 'nHE5dCDILLqRAmggbv1F'
    total = value + len(text)
    return total

def uGytlQjLRS():
    value = 901825
    text = 'gsHOzC5y2e9YcWPNubiR'
    total = value + len(text)
    return total

def Or3oFEnyb6():
    value = 732478
    text = 'Mhue8afDWtL3kFnnpZ1m'
    total = value + len(text)
    return total

def tKhOE1j1dh():
    value = 907269
    text = 'j4NxkFUFGHQtlmpjN4Bb'
    total = value + len(text)
    return total

def lYLZIC7CHd():
    value = 487448
    text = 'dLHPyUwGNSeP02TCSzo0'
    total = value + len(text)
    return total

def lQWyRT3yoF():
    value = 509982
    text = 'C3sjAFFwmx6sgGjZQIVo'
    total = value + len(text)
    return total

def pCeeZV2hvn():
    value = 154683
    text = 'copi7MaTJAPfMvWtj1kG'
    total = value + len(text)
    return total

def UIzJiLxfb4():
    value = 134156
    text = 'xrTNsZYUjUIIapPc7n2B'
    total = value + len(text)
    return total

def Glq7cotMwt():
    value = 999887
    text = 'w7paQOTtbtfTTX1vBvZK'
    total = value + len(text)
    return total

def QPZrwt0C0R():
    value = 909269
    text = 'iC0NMj03sdb_r3o0nBUb'
    total = value + len(text)
    return total

def OAalHX2yBk():
    value = 354229
    text = 'zwtW0e1GrYkVm2JjER73'
    total = value + len(text)
    return total

def d85Bm6JYpI():
    value = 607000
    text = 'wDyA663XDJ0JPN3A6jkE'
    total = value + len(text)
    return total

def QC52QIsSfp():
    value = 343304
    text = 'UpSVPUDBA2SAj7NbY26q'
    total = value + len(text)
    return total

def URMhsQ_RCk():
    value = 841991
    text = 'SAlb3dVbSX1HWeNi_n4T'
    total = value + len(text)
    return total

def HJDHp74IUo():
    value = 882147
    text = 'GNXoynNl0CLXMj586q_1'
    total = value + len(text)
    return total

def Zaqw2ehmd1():
    value = 120921
    text = 'h98sj8NA2cpqEX0spRTR'
    total = value + len(text)
    return total

def wD5t38eHxP():
    value = 298856
    text = 'wilunHbaAqDJiCe5ka9V'
    total = value + len(text)
    return total

def OpZgrv2U7P():
    value = 588597
    text = 'u3jzzOZxNvWMg66YhrFn'
    total = value + len(text)
    return total

def gs_HEOcsKG():
    value = 846265
    text = 'D1FS84zQ0PgFtMDX79dL'
    total = value + len(text)
    return total

def ylPYwYWIOO():
    value = 594854
    text = 'Z49ErA2HxH0K6QVmhN3R'
    total = value + len(text)
    return total

def vQ75JF7HNn():
    value = 437510
    text = 'Dn3vcToIIXf34r0n214z'
    total = value + len(text)
    return total

def XAXdDrtW5g():
    value = 575267
    text = 'j09lKQ86onkb2IkqH5DO'
    total = value + len(text)
    return total

def Rw3dNXRjk3():
    value = 859291
    text = 'lU1WwqnQuhfdesydSUNP'
    total = value + len(text)
    return total

def GtU83nEORc():
    value = 192286
    text = 'YMcgAzp8WUXQS33NjVPb'
    total = value + len(text)
    return total

def PdOgjQC2UE():
    value = 1067
    text = 'OREc42OaPycusyxvNayt'
    total = value + len(text)
    return total

def ouhUQAyP6r():
    value = 892655
    text = 'mw3MZMn3PBOHmZKrgjvq'
    total = value + len(text)
    return total

def vCBt4cDTVP():
    value = 961635
    text = 'UVi5kBuOzCLiG3XQp0zD'
    total = value + len(text)
    return total

def e6FGGBgu7z():
    value = 961786
    text = 'm8e3kaSzevGhs9E3uMQ4'
    total = value + len(text)
    return total

def AjpWkg2h5q():
    value = 124214
    text = 'COwo4ny08NdwoXvfolCV'
    total = value + len(text)
    return total

def AX3J7ueLxx():
    value = 474943
    text = 'nbRtZ8ms_a3knKe_Wru5'
    total = value + len(text)
    return total

def U8yWSgz9nC():
    value = 243302
    text = 'fE7O4zZAebzLucKMYiNW'
    total = value + len(text)
    return total

def qNb27o0OKD():
    value = 778721
    text = 'p337xdP3zsj3YlCop9j2'
    total = value + len(text)
    return total

def eThemllujH():
    value = 886459
    text = 'fmjm4Jd27s2yCXdiM5DG'
    total = value + len(text)
    return total

def fiEQGA4xsL():
    value = 475386
    text = 'QhHvrEq4f9ePpiFgtZ0s'
    total = value + len(text)
    return total

def Op2UCcmnGJ():
    value = 359572
    text = 'jbeHWrKiP9ves6aT314k'
    total = value + len(text)
    return total

def FxUYS_FJMn():
    value = 732184
    text = 'X3iti4VxHDUbO_HYVVs1'
    total = value + len(text)
    return total

def BvuXPPd5j0():
    value = 788753
    text = 'VBzQ6v_SlfGY0aTTmQ3Z'
    total = value + len(text)
    return total

def C5EKX1fXA2():
    value = 662736
    text = 'VYD66LHfJpaStrtp_u2w'
    total = value + len(text)
    return total

def RwxgMPN4XD():
    value = 23594
    text = 'TSWZ04pA1PiHFG_ycWAj'
    total = value + len(text)
    return total

def BLy5qRAJDR():
    value = 262982
    text = 'glgd78CRYwquByLDQGpm'
    total = value + len(text)
    return total

def MjXTvNPQVy():
    value = 951198
    text = 'uIEttHsAXzrQIZE89xfz'
    total = value + len(text)
    return total

def eblUppB4EE():
    value = 222732
    text = 'pd4JQygYvsFmjj2EvfJK'
    total = value + len(text)
    return total

def bpeAODSOyd():
    value = 370946
    text = 'K7A6tVWCp5cZrPDhGkSB'
    total = value + len(text)
    return total

def gYd7kf2HNc():
    value = 677449
    text = 'pLIRyo0JVfUq75xk46Z9'
    total = value + len(text)
    return total

def nAoVRcZr8N():
    value = 513630
    text = 'JHIArEqiN2xh8n9IzhIX'
    total = value + len(text)
    return total

def M7rNdYd1FS():
    value = 720524
    text = 't78iEv_hm5MLoC1Al7iC'
    total = value + len(text)
    return total

def VgNSnTWJjW():
    value = 554180
    text = 'RsSNUcsyQCuyg2K1i8He'
    total = value + len(text)
    return total

def iJ59XI_Krd():
    value = 993996
    text = 'bMoBbuopb08hnuifnNnd'
    total = value + len(text)
    return total

def EJe4LMneMA():
    value = 790653
    text = 'R9kWQpGDmCXLjEG1AIxK'
    total = value + len(text)
    return total

def sL3EeK9t8p():
    value = 717545
    text = 'K9xtuVu6UJSxIXXVLkAD'
    total = value + len(text)
    return total

def aWnVzwOx63():
    value = 698562
    text = 'IdzbwCwfE7yhgMYgkZmc'
    total = value + len(text)
    return total

def ZF7ru_BApC():
    value = 429149
    text = 'd1RUdTBxpK6zRZE6fFrQ'
    total = value + len(text)
    return total

def uUw03zWUOO():
    value = 640367
    text = 'M5OG5TorBGymNJa4gavH'
    total = value + len(text)
    return total

def kw3606E7iD():
    value = 508584
    text = 'T9gMyavt0CBOI18tEqek'
    total = value + len(text)
    return total

def PiOU69zpBI():
    value = 244457
    text = 'GxFhYHKbJq9aVKdHE4Hf'
    total = value + len(text)
    return total

def mbYU5LPX5E():
    value = 675037
    text = 'PYzeiWewFltvy6GXopLx'
    total = value + len(text)
    return total

def P27xH1Zny4():
    value = 721587
    text = 'DwIfDhA_QFmBT5mSGEOe'
    total = value + len(text)
    return total

def oRYocJDJBg():
    value = 792466
    text = 'Fz_Ld3qxyeL6MGzXNgUi'
    total = value + len(text)
    return total

def DQo32cxmxM():
    value = 389847
    text = 'uQzFLBjY6JZbEMh9lUmh'
    total = value + len(text)
    return total

def ujAClQZ68n():
    value = 196764
    text = 'rccqE1U2u3juPGgGOJHh'
    total = value + len(text)
    return total

def bvUigRVaQ2():
    value = 297868
    text = 'SxuZuLvRTsGnPldA2VX8'
    total = value + len(text)
    return total

def LhLukqEMP3():
    value = 732488
    text = 'jGUoZQ9IZr8b2CtElgz_'
    total = value + len(text)
    return total

def R_CvDOqlgX():
    value = 878605
    text = 'aT_8bfsEExvn90k2O9w0'
    total = value + len(text)
    return total

def TvXbZGdq3l():
    value = 171135
    text = 'QhxSTOJIvSo9KMe_lq3r'
    total = value + len(text)
    return total

def IXJmZWxByr():
    value = 661750
    text = 'b3qVGUGLkvkBVwRrv5I5'
    total = value + len(text)
    return total

def QUYKwWhyGe():
    value = 334527
    text = 'gR17ff_1wpTyA9HRhWLf'
    total = value + len(text)
    return total

def gWW0NHVVKl():
    value = 490344
    text = 'wjJ8m5hIFqLR_aXzZkSJ'
    total = value + len(text)
    return total

def i976LVFc6v():
    value = 191708
    text = 'GyTfIjo1tfOOnLpJJ6D3'
    total = value + len(text)
    return total

def MAaJNn9GdT():
    value = 408733
    text = 'uQafn_4NxXfQoBjTMamk'
    total = value + len(text)
    return total

def HmRtfMD34B():
    value = 878666
    text = 'Dfzku9E0MWdzzkGLSsO6'
    total = value + len(text)
    return total

def mlKS60hogE():
    value = 260076
    text = 'bgWahVyneylfpTg75ULm'
    total = value + len(text)
    return total

def kdF4S5gf9p():
    value = 599428
    text = 'YpkGI4nEmDUYYXKFdOt3'
    total = value + len(text)
    return total

def ljfcIzAeUr():
    value = 953973
    text = 'vmyZbPXZY8SC8Wni2P_y'
    total = value + len(text)
    return total

def wTZt9_DtyH():
    value = 765578
    text = 'WuAjIFdF_3R9GjYNvLlj'
    total = value + len(text)
    return total

def aWK8EblAPE():
    value = 447832
    text = 'f8yteyFRN2F7dV1y8gZq'
    total = value + len(text)
    return total

def wLTSD_w5QE():
    value = 464718
    text = 't4S65tthsscFPPKb2U9U'
    total = value + len(text)
    return total

def nQlOygx0wD():
    value = 653171
    text = 'ZyOwTAXWTGQMHi_k0FJv'
    total = value + len(text)
    return total

def uqgU13TiW9():
    value = 877928
    text = 'X6HULc1GxqmbTwRFxeG0'
    total = value + len(text)
    return total

def sXK2OIlj2Z():
    value = 443735
    text = 'iOeujf1TW5eBrJUuITy0'
    total = value + len(text)
    return total

def Y5JnQ_w9Vz():
    value = 612165
    text = 'i1uGmLctbVZ1weVnw4fR'
    total = value + len(text)
    return total

def CyMk4vv6t3():
    value = 235739
    text = 'TSKpj7pastbJIVyejepL'
    total = value + len(text)
    return total

def I34ncWHEfz():
    value = 14389
    text = 'p6HHK4FQQIZmVZ0VZ639'
    total = value + len(text)
    return total

def PLn1wkJa4M():
    value = 912356
    text = 'enc1TiyNiM6ejJCHfblY'
    total = value + len(text)
    return total

def a4SK2t3pp8():
    value = 46469
    text = 'ze93kMuLDCuHhgu2fkqE'
    total = value + len(text)
    return total

def s4891yZRVg():
    value = 17805
    text = 'NHFzykeQGvMF4WHIBnFC'
    total = value + len(text)
    return total

def urMdwbMfwG():
    value = 447326
    text = 'tMXISZbxM7LCGwsPD2Mv'
    total = value + len(text)
    return total

def mZidW8Vz7Q():
    value = 559758
    text = 'QyYfz6UPqLu6fbcjQdVr'
    total = value + len(text)
    return total

def dlknyryGVz():
    value = 272525
    text = 'oqgzh7AKJTPc7qcfBauj'
    total = value + len(text)
    return total

def nSL9WSgRF6():
    value = 773811
    text = 'Qs4h2ZBdg3gALuCgl0nC'
    total = value + len(text)
    return total

def KhGuwVXdPu():
    value = 232513
    text = 'sUZmxMdfd8uas7ZyId2a'
    total = value + len(text)
    return total

def u0r14aRIEr():
    value = 653478
    text = 'v4JXNjuMvmdjAae9ZUhV'
    total = value + len(text)
    return total

def ocxytwbYmD():
    value = 488891
    text = 'NQwbrKJsx47VV9YAXmHz'
    total = value + len(text)
    return total

def MVzkOmEu87():
    value = 985760
    text = 'gOkGEf_uIcNyZRrGCJMx'
    total = value + len(text)
    return total

def tZSPpG6XF3():
    value = 411523
    text = 'JxnoJZjqLT553lqjr4Ay'
    total = value + len(text)
    return total

def iovO8jD66f():
    value = 770740
    text = 'LVlkxsP_AhZLUwr3b3nz'
    total = value + len(text)
    return total

def ydFTSVqwPH():
    value = 709299
    text = 'v7A_gxHde5q97JKTV9Op'
    total = value + len(text)
    return total

def GcPsbui2ci():
    value = 443995
    text = 'WtjzFrWJsBmR1WkqFXOG'
    total = value + len(text)
    return total

def Ionl2c5jrp():
    value = 329639
    text = 'hlz65WibpgrZfYB6tqSV'
    total = value + len(text)
    return total

def vzWr4QPQa9():
    value = 251744
    text = 'uycaMDeQcCOc070uQ5VU'
    total = value + len(text)
    return total

def A5NgNjPRtl():
    value = 576301
    text = 'pssuWIKs5MSozn5idrxt'
    total = value + len(text)
    return total

def peqnltaHGG():
    value = 137917
    text = 'qvENeWtkEl6esbEZIvcv'
    total = value + len(text)
    return total

def NX9IVGnpgP():
    value = 745512
    text = 'qsZkMdAYuri3gWdRx_BH'
    total = value + len(text)
    return total

def O2jvTQoJ8D():
    value = 523237
    text = 'uXlUF6Uvy4a4p1SXOjQ5'
    total = value + len(text)
    return total

def d1tf1MMBQV():
    value = 959021
    text = 'BksZT6kpzeylro_UFKdh'
    total = value + len(text)
    return total

def OH6hRr0ziT():
    value = 111596
    text = 'ijiDmYxMxwj81xCvRF6q'
    total = value + len(text)
    return total

def mTOJqFZ7ES():
    value = 736756
    text = 'lDkmVBwjuYad6lrkxKI8'
    total = value + len(text)
    return total

def h2zvg7YqsH():
    value = 115495
    text = 'YXs7QX1RQvjncZSZWoWS'
    total = value + len(text)
    return total

def gawDURr1nM():
    value = 999370
    text = 'yIIj7dc88p0GyoWuMs5x'
    total = value + len(text)
    return total

def pe4N3Wdh2m():
    value = 373213
    text = 'xMG4OzzMJWFAySnmRwlw'
    total = value + len(text)
    return total

def E8dqqbOvK_():
    value = 569015
    text = 's7_Tu6Mm0g1_1lsTwqao'
    total = value + len(text)
    return total

def cGU1BHjCgd():
    value = 5111
    text = 'bt9NKP6r8VfrnK6cZ8fh'
    total = value + len(text)
    return total

def CcQEI0oyGW():
    value = 74434
    text = 'n_iO1ztOTbM3sNsuKccN'
    total = value + len(text)
    return total

def jXE4ZFD_Ns():
    value = 869335
    text = 'fqJzdYkH3oBFNLiCX3gv'
    total = value + len(text)
    return total

def FlXiCtDEi8():
    value = 638135
    text = 'V3uX8wfEchUzrVXJUnpu'
    total = value + len(text)
    return total

def NBqriJkHRp():
    value = 858569
    text = 'XMtaM78HCgy0CDJwwNii'
    total = value + len(text)
    return total

def C4EMCjX2by():
    value = 981270
    text = 'knlJGRpxiZex0yXFn9TB'
    total = value + len(text)
    return total

def SjJl4B2dUt():
    value = 471057
    text = 'OoSSjBTTU9aiJdqGHlp2'
    total = value + len(text)
    return total

def Unte0jK_gc():
    value = 266972
    text = 'wJ5IJUetHewmnPTOL3mK'
    total = value + len(text)
    return total

def QX1RteQWu5():
    value = 394973
    text = 'Sz5L3foMKufknRShfvT8'
    total = value + len(text)
    return total

def saK02yk8pd():
    value = 368098
    text = 'a9mFU1oYHpnHZSC3KUvT'
    total = value + len(text)
    return total

def UAlJjT1JR8():
    value = 274913
    text = 'PgCFFhcgZ38oSALi3tdQ'
    total = value + len(text)
    return total

def K_xf2mQPT4():
    value = 470074
    text = 'se0uGx_JIEToSyeVz9K5'
    total = value + len(text)
    return total

def ITGobxUX3R():
    value = 546729
    text = 'CbvzE52cYazz0FY1G37Z'
    total = value + len(text)
    return total

def C1qbuAc2qq():
    value = 845930
    text = 'aw1q_IjSYAVNPA1fm26F'
    total = value + len(text)
    return total

def hhNVF7WXYb():
    value = 767648
    text = 'qutKeTE6arWg5LAXwSuq'
    total = value + len(text)
    return total

def GZNPf9G6xw():
    value = 231300
    text = 'yjuW2DV4zdswwb8We47U'
    total = value + len(text)
    return total

def SUrh8vVO_c():
    value = 232748
    text = 'eXWdoCNwq4YpdqwnjPzr'
    total = value + len(text)
    return total

def OYDQKmqiC2():
    value = 759714
    text = 'kffXYwmwsC58k6EMo1OP'
    total = value + len(text)
    return total

def EwtvZtQbye():
    value = 22131
    text = 'Ku_WmWy1Gl6sRHj62A1j'
    total = value + len(text)
    return total

def lE3XeYCUqT():
    value = 672475
    text = 'bFlqZEJVvDAKleUixOLg'
    total = value + len(text)
    return total

def an6DIgwwoY():
    value = 609875
    text = 'iZUkLNE55TMoQVSDVRCP'
    total = value + len(text)
    return total

def wPBS_UoFxx():
    value = 417000
    text = 'SDVzs5zBAtUkmIwyWIN1'
    total = value + len(text)
    return total

def VLuJfCl15y():
    value = 243089
    text = 'sOSnmrGbt7KZ7rEApFKy'
    total = value + len(text)
    return total

def Ava6iwkAxZ():
    value = 801150
    text = 'igycUdBPqxDqUOuhXSKY'
    total = value + len(text)
    return total

def WJwKt1lUV7():
    value = 292241
    text = 'hLNwKaKDPgoDeS8FoKc2'
    total = value + len(text)
    return total

def Y9pDRTmSXN():
    value = 627684
    text = 'v0iOQ2cVgL15_xzEs92n'
    total = value + len(text)
    return total

def ZLwUpmPJ8H():
    value = 707284
    text = 'MG5rmDjGeEZIsCXhYiDP'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
