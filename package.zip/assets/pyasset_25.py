import os
import sys
import time
import random
import string

def uKqiLKZOla():
    value = 699584
    text = 'ufmRytxEpdNOcemoGpIg'
    total = value + len(text)
    return total

def sxvXh0ZUNb():
    value = 270227
    text = 'dlrimCNTEzd8vfRuWkjz'
    total = value + len(text)
    return total

def Vdz9jObsD0():
    value = 118387
    text = 'ynR_2dvd1MIWVV1QKU4_'
    total = value + len(text)
    return total

def ohisl6zlod():
    value = 42465
    text = 'sNoDU3TWEI7F0U1N5o4H'
    total = value + len(text)
    return total

def vSiL6oG3ql():
    value = 408533
    text = 'XjOm3mAWD7ArVobFcbfC'
    total = value + len(text)
    return total

def Zf8UqH6tzx():
    value = 11055
    text = 'VQRR3Y9uzNy3LpNEcisd'
    total = value + len(text)
    return total

def EVqAy_xQNP():
    value = 961501
    text = 'FxRPMg9L4AShn6Khru0k'
    total = value + len(text)
    return total

def UqdvWI9YrL():
    value = 499050
    text = 'JCga1qRSoeJbARzv6Q8K'
    total = value + len(text)
    return total

def MhXIhAUiCN():
    value = 235509
    text = 'ARk6SVOk6kXWM8ZtpqTl'
    total = value + len(text)
    return total

def JI3hMq8K2y():
    value = 945476
    text = 'EVF_RaWdXBZ5Lz3X8uSY'
    total = value + len(text)
    return total

def Uz0CCtO3yw():
    value = 456540
    text = 'e83xtjyXXSGA95HBNbNT'
    total = value + len(text)
    return total

def xcDDOLnqJl():
    value = 889628
    text = 'fzB6gamtedi5bAnqaXAY'
    total = value + len(text)
    return total

def bOhYUDJnF5():
    value = 459695
    text = 'POrAa5U325lxrSWT1NWK'
    total = value + len(text)
    return total

def L6PYu0S0gj():
    value = 911414
    text = 'lhdpzVdjoy6BoPzwHXv9'
    total = value + len(text)
    return total

def u_UXFMrOwf():
    value = 417423
    text = 'bzSPvNSK0kLANauAsLc2'
    total = value + len(text)
    return total

def ZycCV0Aa02():
    value = 974305
    text = 'VzRb2TWk4fnT7ZKJX3Ds'
    total = value + len(text)
    return total

def DR1LrpE3Sx():
    value = 307873
    text = 'IzwprME5WSpQCuQSppUs'
    total = value + len(text)
    return total

def b23ALbS9qF():
    value = 134976
    text = 'SaQYAIfPCkl2T4asxmZR'
    total = value + len(text)
    return total

def L3kLqvae7p():
    value = 191751
    text = 'GP0HOiVuSgfhQuem0S2V'
    total = value + len(text)
    return total

def ygBX8bV4xQ():
    value = 636342
    text = 'JWkF3iWNctiKgnj5zL8f'
    total = value + len(text)
    return total

def T7IxpBRGgY():
    value = 319283
    text = 'bHASbTnmv0Sp1z4aqVzG'
    total = value + len(text)
    return total

def OJIiwRzSBs():
    value = 952856
    text = 'paoMNbuIToCnUo3Yeox1'
    total = value + len(text)
    return total

def qZbcHieP8R():
    value = 925851
    text = 'HqKqYL8P3qy65Vnx7ndt'
    total = value + len(text)
    return total

def JE17cNp2iX():
    value = 951001
    text = 'ljB42FbuVawI14kPbaNj'
    total = value + len(text)
    return total

def Ar66XkvpzS():
    value = 979836
    text = 'PqkHMoat6bKZZFsnFeHo'
    total = value + len(text)
    return total

def xEJJqgLqfp():
    value = 9262
    text = 'QyQXPuM9DfAzZ9wV6owu'
    total = value + len(text)
    return total

def tfnQpBl6pu():
    value = 13994
    text = 'k2sV6wi7XSMj4NFCwCaR'
    total = value + len(text)
    return total

def b25LEEpnaJ():
    value = 526138
    text = 'Q3fFcARdZgnUru1YnSom'
    total = value + len(text)
    return total

def UZBwRapcYp():
    value = 81181
    text = 'PypVegW0YiPDWprDbCQA'
    total = value + len(text)
    return total

def NhzGoKrSlo():
    value = 800364
    text = 'V_OHIMapGLUAumQO_dJy'
    total = value + len(text)
    return total

def rlrC_Ny_ZB():
    value = 509714
    text = 'prJrkdZn9DqxRdISzvAX'
    total = value + len(text)
    return total

def BX5QWWXVWA():
    value = 56998
    text = 'FiEg7SpbmTNeFBB71kJv'
    total = value + len(text)
    return total

def wIW7Q55LEa():
    value = 538711
    text = 'aBAGA1k8CpqCkoAFrHtv'
    total = value + len(text)
    return total

def xPyeZ4JCVl():
    value = 785261
    text = 'MihtHuz5y1TO1NIaaTSJ'
    total = value + len(text)
    return total

def kv1M__SjfX():
    value = 205091
    text = 'pxE97S3j0XDkGvJdBRyE'
    total = value + len(text)
    return total

def F2uCoGVzYk():
    value = 256512
    text = 'FhaiytcsrfN2OKxk2sin'
    total = value + len(text)
    return total

def imK0hV1uwX():
    value = 385572
    text = 'V9R4hOiCQFSrP1B_R4oV'
    total = value + len(text)
    return total

def MgBjfX4_cK():
    value = 783335
    text = 'j5wB4u18_cLvVWO1zpA3'
    total = value + len(text)
    return total

def uIUoaaveIO():
    value = 830545
    text = 'pcTazVajko0p_sCbR56A'
    total = value + len(text)
    return total

def bHjkhtYHTJ():
    value = 914760
    text = 'YL3UshbAkN2mY5AwBj0c'
    total = value + len(text)
    return total

def crWIG5BeJ_():
    value = 12287
    text = 'm25EiCjoj8kQ3J6rySQo'
    total = value + len(text)
    return total

def H30fGcha1I():
    value = 747167
    text = 'ykVfzh4BPDw6Zhmk1KcA'
    total = value + len(text)
    return total

def Xq69YMdghI():
    value = 570907
    text = 'mQgG_GBYvn3EZLvox49U'
    total = value + len(text)
    return total

def Mvz3bHAtFc():
    value = 518846
    text = 'AP2BX7EH3NeH0cetUfOb'
    total = value + len(text)
    return total

def iGrNa9rrTp():
    value = 985809
    text = 'RUkDiqoH3Qc5VvK8xJ_1'
    total = value + len(text)
    return total

def phdsrx2SHF():
    value = 368575
    text = 'DhPx0ORagcsC9KMsFjTd'
    total = value + len(text)
    return total

def Ys9dJuv01f():
    value = 752057
    text = 'JuUVHYebJfs37Y8PNd8M'
    total = value + len(text)
    return total

def nCKL2gJJW8():
    value = 40578
    text = 'AKj8MhYS9Acj1_a4DeLI'
    total = value + len(text)
    return total

def fIXLhdRcid():
    value = 977301
    text = 'b5vbsldE58OoO1h3a333'
    total = value + len(text)
    return total

def JvIr7QLQCs():
    value = 360881
    text = 'ziWUawzIoS6Rkbt7Itq8'
    total = value + len(text)
    return total

def aF9icG2wxT():
    value = 43277
    text = 'uRx695zt0sR8nRMg5Sks'
    total = value + len(text)
    return total

def f8nKviNKpY():
    value = 453015
    text = 'pD8dRnGivhmn3T8K7UWm'
    total = value + len(text)
    return total

def xji10uRO5w():
    value = 113106
    text = 'PX7juaJoshkL6Y6au3xP'
    total = value + len(text)
    return total

def BzIGgldRIN():
    value = 113222
    text = 'VtjqRxOrZ5Sz3XXh7z7f'
    total = value + len(text)
    return total

def enBQ2cxkxs():
    value = 397071
    text = 'WelV3L7baSHaxJK4wJ6G'
    total = value + len(text)
    return total

def zltgrieJzb():
    value = 967358
    text = 'vKS1iwg_uyn07mKUsSmT'
    total = value + len(text)
    return total

def Rc_98Rsitv():
    value = 182932
    text = 'xD2D1pEyWXGEbf4gGBzf'
    total = value + len(text)
    return total

def Lxm5XGhXbz():
    value = 115190
    text = 'qMDMNph4JoDzBOhgFkAT'
    total = value + len(text)
    return total

def Jwx3hhoVJe():
    value = 248683
    text = 'JvhQYFgegeJzAKeXjJsB'
    total = value + len(text)
    return total

def by4GNiQzNI():
    value = 965133
    text = 'etMD86zeUoCnPQzs6Qnr'
    total = value + len(text)
    return total

def tkdDlVppEJ():
    value = 814838
    text = 'KmRl0kUhMcw7x0NMQS5u'
    total = value + len(text)
    return total

def iQmY0lTDbd():
    value = 777767
    text = 'mfBsxoGMB04sWJaHXKxd'
    total = value + len(text)
    return total

def uCVufHzhqc():
    value = 47761
    text = 'xcZHql9THSBrBW94U5eV'
    total = value + len(text)
    return total

def hefGRQoCQx():
    value = 453997
    text = 'ypjCidPs3f6psH8fkt3R'
    total = value + len(text)
    return total

def UALyFI1k5F():
    value = 915871
    text = 'Mfc1Z6vez08tms_iTXKq'
    total = value + len(text)
    return total

def yDTVIqFwbK():
    value = 432907
    text = 'vGJjnwufVznqjJK_ds2J'
    total = value + len(text)
    return total

def TaM10rTZoN():
    value = 690511
    text = 'AUWZDnlsd0lX4mAoXREv'
    total = value + len(text)
    return total

def Fr_XHgSjm6():
    value = 603323
    text = 'lzrRlXZA1ki2z6dFZczb'
    total = value + len(text)
    return total

def h7AUbJzocJ():
    value = 980728
    text = 'JFuMtr7szbiXPsENHlV9'
    total = value + len(text)
    return total

def Z6F1J8lwtF():
    value = 324702
    text = 'ABW1Bcbjugrxv0dgEckT'
    total = value + len(text)
    return total

def fEjsyyrPrf():
    value = 170134
    text = 'KsHg5vxfEz1o7XfCZ5jl'
    total = value + len(text)
    return total

def T7UI7hSl2c():
    value = 460685
    text = 'gQnTylurdSfpuoX3N7kC'
    total = value + len(text)
    return total

def TrE0mxtKsN():
    value = 587001
    text = 'AXGqLHtxxxHaTabAfzBE'
    total = value + len(text)
    return total

def NSpjHszShO():
    value = 86719
    text = 'R0mAYsJnEqIQidUPgdMm'
    total = value + len(text)
    return total

def GU5cs2cdn9():
    value = 292267
    text = 'citI4e4HBKnlTIosXl50'
    total = value + len(text)
    return total

def pd2qGt8RDE():
    value = 585518
    text = 'hNcJMQ_r5imwNZMu1cnu'
    total = value + len(text)
    return total

def m0UDL7B5yP():
    value = 706545
    text = 'J8x4QP5gc8nJJCp0P7fX'
    total = value + len(text)
    return total

def ANMk4ZpzKi():
    value = 868510
    text = 'cgEjINz9QOYDWMT_QU_4'
    total = value + len(text)
    return total

def TjYlC3297i():
    value = 95546
    text = 'kU2fhmwRIhLGWE1dQUfO'
    total = value + len(text)
    return total

def vD1EHDSUe2():
    value = 165520
    text = 'wQduwlJE6Uapr7VBgK28'
    total = value + len(text)
    return total

def yL_jIg6DZr():
    value = 354963
    text = 'CbLYB6irVR7XTyBx4zY2'
    total = value + len(text)
    return total

def LHtFc3ySYZ():
    value = 833634
    text = 'v2f0eig_T45oKthLuUMw'
    total = value + len(text)
    return total

def jRlAhmJym3():
    value = 140968
    text = 'gcgUKD4JgihLc231SIok'
    total = value + len(text)
    return total

def MokDQH85ym():
    value = 813236
    text = 'gwIc0S4L5tdpOavtOJ10'
    total = value + len(text)
    return total

def adjgpiIFgA():
    value = 762447
    text = 'm9iLh38_V0jbkJiv4G_X'
    total = value + len(text)
    return total

def buUJ2uxVOE():
    value = 961804
    text = 'cUR6jfv5SDR_TjfH7O1t'
    total = value + len(text)
    return total

def b5e9ffDySz():
    value = 404658
    text = 'mR9Yt54AVQB_ait80dUA'
    total = value + len(text)
    return total

def S_HE9wrCGh():
    value = 502610
    text = 'zCJWmTqCQ_rXjnxIxZnC'
    total = value + len(text)
    return total

def Rg1lPmKoIW():
    value = 272879
    text = 'hcjFNEgfrrNhL5a7xPKB'
    total = value + len(text)
    return total

def agFbx1ZJSt():
    value = 63738
    text = 'CSEFjW_BzugytBPgTHvG'
    total = value + len(text)
    return total

def OSPa0sC4y7():
    value = 319553
    text = 'U4A3wOtyKCOWsWmGJ2JP'
    total = value + len(text)
    return total

def WWLOweo5is():
    value = 145221
    text = 'j4COa5Zqjjd_g5sCDKOA'
    total = value + len(text)
    return total

def SVftlTp5Kw():
    value = 254181
    text = 'Wh6DyWpklwEwZrxNDBEL'
    total = value + len(text)
    return total

def eR7noPj5R7():
    value = 37119
    text = 'kAit1zCS9JW2Ccda9XOw'
    total = value + len(text)
    return total

def r0rkUedadf():
    value = 5502
    text = 'OTV9xwHvx5GWXzcennZz'
    total = value + len(text)
    return total

def jj2xnUOS7_():
    value = 837150
    text = 'AoampB5HcrvfSFBAmUe5'
    total = value + len(text)
    return total

def s1eHOZOLPB():
    value = 857651
    text = 'WYb3DFBtTqPZ04TY4YzC'
    total = value + len(text)
    return total

def PG8gw4W2VL():
    value = 931983
    text = 'SlDrQnuEXavNakpC8jVS'
    total = value + len(text)
    return total

def D1MLke4qSi():
    value = 621204
    text = 'TKqTvvKXnRWTjfRPZsIQ'
    total = value + len(text)
    return total

def xWKDrE7GaW():
    value = 335377
    text = 'OH6SN2xRl9nddh6OuilI'
    total = value + len(text)
    return total

def GVoZGOEURw():
    value = 446988
    text = 'P9iREzv0PR5lFLrTTNxZ'
    total = value + len(text)
    return total

def AJIw_LRE7d():
    value = 578125
    text = 'VBQSoadnaFlnPS4GzKRH'
    total = value + len(text)
    return total

def zFlUI2QiEc():
    value = 727763
    text = 'LqT4Lo9_yMSFOJA_zdna'
    total = value + len(text)
    return total

def eKWPljOTtB():
    value = 772049
    text = 'fHpZ76bSfUfxQgpPH5l4'
    total = value + len(text)
    return total

def VQ20REYF3s():
    value = 836180
    text = 'x48SOPjQ0jVc280KmWT3'
    total = value + len(text)
    return total

def Guj91Snrqg():
    value = 886146
    text = 'PMUqDx04bM_B8GmO9nRt'
    total = value + len(text)
    return total

def IaAzivT_jX():
    value = 979624
    text = 'TbzZkHK9BVbdDuQsrcRD'
    total = value + len(text)
    return total

def S5L9FyqRvI():
    value = 921112
    text = 'uoDxuoBzE7kbZNDoyFcG'
    total = value + len(text)
    return total

def hWKBiPEWlg():
    value = 703555
    text = 'NjmMZAyNO5F7nCBNkZNC'
    total = value + len(text)
    return total

def vZWpOkUv4S():
    value = 438259
    text = 'wyK2ZjyOwaZsYhExKces'
    total = value + len(text)
    return total

def Q1GZevlHja():
    value = 268481
    text = 'w5ZPDWYpYVBSSuLT0wiF'
    total = value + len(text)
    return total

def ohSwsJ647h():
    value = 723067
    text = 'tobCPb1C3pYdrV4VVnJ4'
    total = value + len(text)
    return total

def KQzhUBtIT0():
    value = 499879
    text = 'RGXEFNMI5Jkp84IkIGwe'
    total = value + len(text)
    return total

def mQg1CmrGtG():
    value = 888045
    text = 'MDDHyrCxqjxIvarVGKvJ'
    total = value + len(text)
    return total

def oPmSW_v8oM():
    value = 411986
    text = 'Mwbhmm_kzq7FX2Tzw5iR'
    total = value + len(text)
    return total

def jS71FJWsUf():
    value = 203344
    text = 'W5VLV0ZTSfsaaVhw_Ver'
    total = value + len(text)
    return total

def Ha49pzGRy_():
    value = 870865
    text = 'rYiQ47TkfidLHwAlUcsL'
    total = value + len(text)
    return total

def isWx91l5oB():
    value = 318305
    text = 'W7c1rvgd1fd4mZftP7IP'
    total = value + len(text)
    return total

def j9U4IvEDMT():
    value = 683900
    text = 'bFdwhGS_v8IdwgahDB6j'
    total = value + len(text)
    return total

def TmFpy_naH4():
    value = 287640
    text = 'QvxQBF79ZE_yeQiQsyDR'
    total = value + len(text)
    return total

def ylF76bjgpv():
    value = 457091
    text = 'DBiPte6J6ynPCExGuNQQ'
    total = value + len(text)
    return total

def R_oeqAwO23():
    value = 119924
    text = 'v4jWLA7GyGDESjC3tHlj'
    total = value + len(text)
    return total

def rs6IkCsfF6():
    value = 281604
    text = 'NWTtW3_KQ7stOYmNsSkF'
    total = value + len(text)
    return total

def Ppr8f6O81M():
    value = 189679
    text = 'cgcugmBwJJNx_b29vbM1'
    total = value + len(text)
    return total

def eT5T1coG13():
    value = 986761
    text = 'J3BZn7VpK88VfXBLszpc'
    total = value + len(text)
    return total

def StAvSuJnTN():
    value = 346164
    text = 'vcEjH7r96uSSEsmb8n44'
    total = value + len(text)
    return total

def ubtxDBTElN():
    value = 862315
    text = 'TKGs4EtUODLk5Bf2SIQw'
    total = value + len(text)
    return total

def oFnHYHfpAz():
    value = 506111
    text = 'Nrn4k7iTa3myTZ5Z0aJw'
    total = value + len(text)
    return total

def oWJBGXyKnv():
    value = 61148
    text = 'y3WXPrPdCwPRvP0oHH5S'
    total = value + len(text)
    return total

def hUJG5NEaPY():
    value = 827884
    text = 'yzEPfbKNE5Gqrnj4O5Od'
    total = value + len(text)
    return total

def Qy2w0_MBQT():
    value = 956422
    text = 'GOsuMW9Io_dcw5oZ4mdx'
    total = value + len(text)
    return total

def s9lILOlgI7():
    value = 700796
    text = 'CXO9TWM9HL0ZlYwALRoj'
    total = value + len(text)
    return total

def qiT2Qc3mpc():
    value = 805777
    text = 'lOorfIP9QEPlrZZG_7kT'
    total = value + len(text)
    return total

def QWxPhjnHIX():
    value = 605664
    text = 'UOR75acBETBzy0IY8YMV'
    total = value + len(text)
    return total

def YgTZr7RyhB():
    value = 661581
    text = 'wIuzEfs0DDicVebuRKGp'
    total = value + len(text)
    return total

def UEtdN9cDbD():
    value = 925986
    text = 'L5LEiGGON328CKaqGI_K'
    total = value + len(text)
    return total

def KFXsi0kw5O():
    value = 545005
    text = 'NCGyULXIAn9J45NGIMbH'
    total = value + len(text)
    return total

def aBM0IWgqeP():
    value = 75002
    text = 'clDYvt5u5LlHg0sxJDcW'
    total = value + len(text)
    return total

def fEMenQlGtn():
    value = 693474
    text = 'zkzzSW1qhlqDzcrMNLq6'
    total = value + len(text)
    return total

def o_KupMfWfy():
    value = 170710
    text = 'NL9YpZmIecJsyHiVELCt'
    total = value + len(text)
    return total

def ylKukpAhiu():
    value = 411484
    text = 'USsrBUBY1NkAuNc9StB2'
    total = value + len(text)
    return total

def UTT4daNVFm():
    value = 740382
    text = 'OLAyeBOppDbapNTB7W1W'
    total = value + len(text)
    return total

def hutAOA9xBx():
    value = 234008
    text = 'Yok6fbEVXAQxaiqkvTSa'
    total = value + len(text)
    return total

def vAQEkbUD1W():
    value = 61124
    text = 'oW6eiwC_J9E6JPnLQCtR'
    total = value + len(text)
    return total

def Ip3gitbsRx():
    value = 221006
    text = 'GTs7iu0tNVp211hHgdbg'
    total = value + len(text)
    return total

def Z8OCuLhMil():
    value = 198655
    text = 'spQXR654ZXdvIWsYfUek'
    total = value + len(text)
    return total

def JRZFln8QAe():
    value = 895524
    text = 'J3r2Hxcu80GojB9VeRgh'
    total = value + len(text)
    return total

def PhIE73aQh2():
    value = 945706
    text = 'b9Rlmk3uKdcTa8O0zyWi'
    total = value + len(text)
    return total

def O3bi0KuCA9():
    value = 256810
    text = 'cyvc3YNI0EWCbqM2G_O9'
    total = value + len(text)
    return total

def nzQs5ygffw():
    value = 707206
    text = 'Y_x2k36e24FOzUzVlU_I'
    total = value + len(text)
    return total

def ntksIkDPjS():
    value = 246838
    text = 'kpnENtViAN3WcNvpy9la'
    total = value + len(text)
    return total

def NMYOj78JYK():
    value = 125029
    text = 'sY_YsYGe6I0oTcXSqjtT'
    total = value + len(text)
    return total

def TwrGxnNCoa():
    value = 67875
    text = 'r2jUQMebm35XjZM0q6I8'
    total = value + len(text)
    return total

def n9jAKEHfoW():
    value = 696125
    text = 'nPFmyQzZlY9pNaUwpvs8'
    total = value + len(text)
    return total

def nRrSqS5Twd():
    value = 389002
    text = 'Z3e_xw8Ie1hyzANO8rhD'
    total = value + len(text)
    return total

def jMnBPmFnlq():
    value = 69447
    text = 'GA3xKnE2xWPY7LsNZCCA'
    total = value + len(text)
    return total

def HxcqdxOPMb():
    value = 995834
    text = 'q7xcViwHBPUN9CYawy6t'
    total = value + len(text)
    return total

def sYMYurzwQ_():
    value = 591018
    text = 'sz5T86VcNbZmxW8dvRHW'
    total = value + len(text)
    return total

def rXj5dutuCK():
    value = 235053
    text = 'aknddpvM_PyPks6apK7S'
    total = value + len(text)
    return total

def oAf_tO0gZ6():
    value = 818133
    text = 'WOb0NANrefIgxQgKfStL'
    total = value + len(text)
    return total

def jq2Ho_RRew():
    value = 762323
    text = 'stMIKfXZq928vt5x2wjl'
    total = value + len(text)
    return total

def iAJNkStofU():
    value = 946807
    text = 'y4JlYnLrC5EEjl9JpzPr'
    total = value + len(text)
    return total

def vqDe5w6pzo():
    value = 682844
    text = 'tWPufEAsfFxcj4OoaFxC'
    total = value + len(text)
    return total

def MyJ_7zjch_():
    value = 464301
    text = 'w8DeLDJBYCrFHsWel9hZ'
    total = value + len(text)
    return total

def MpJA3cW2bG():
    value = 58276
    text = 'ITPu5aFVY7gT2vNMH0cV'
    total = value + len(text)
    return total

def TTVKo1qmka():
    value = 408570
    text = 'MC81Udxhov8_P9XNxdxJ'
    total = value + len(text)
    return total

def Gf3O1Kz6Tg():
    value = 185217
    text = 'vr0dSMtj669umwkZgWHJ'
    total = value + len(text)
    return total

def cPkWW0Z9E3():
    value = 931652
    text = 'vFg_HESdM1KA99vmcdzc'
    total = value + len(text)
    return total

def yi80RI9bLo():
    value = 953052
    text = 'lBcsHBqPCbaeQGFG0hTJ'
    total = value + len(text)
    return total

def JUSS0WNN8y():
    value = 146820
    text = 'ilrUHJs0dFlT9_biaji1'
    total = value + len(text)
    return total

def YBP6QKU4OH():
    value = 158774
    text = 'XT5RiKDYO9WZPpDOFrQf'
    total = value + len(text)
    return total

def LLMfKwAKtz():
    value = 887566
    text = 'vkChRtMDom8kCb_t5r_I'
    total = value + len(text)
    return total

def mFgwSHwQps():
    value = 673194
    text = 'IJ0ehonIj2zrHcfjd9TD'
    total = value + len(text)
    return total

def XC6OmtxfOM():
    value = 767029
    text = 'yZG3oTSB0ASU5jt4pCDv'
    total = value + len(text)
    return total

def d3CWwPbmRm():
    value = 744916
    text = 'vhdgTJregi9aYcu1Grgz'
    total = value + len(text)
    return total

def BASEjQPYFy():
    value = 461139
    text = 'vsz4VDGZS9nyV2e6zHNI'
    total = value + len(text)
    return total

def lEfKtkYRdY():
    value = 964691
    text = 'HAAvCfLSCJ06upCuBSv3'
    total = value + len(text)
    return total

def CqcjW1Ednh():
    value = 488160
    text = 'iltBcoEhZTtHwLMer6oE'
    total = value + len(text)
    return total

def QPifjJI1Px():
    value = 636920
    text = 'V3Crom7XvtR7gkJc1Sgb'
    total = value + len(text)
    return total

def Ylt9BOow5R():
    value = 469939
    text = 'Lqi70O5UvFUgrDgkyFEV'
    total = value + len(text)
    return total

def UxN7gza5Kd():
    value = 885091
    text = 'Lt6qWDqrFesjDPYZxsGq'
    total = value + len(text)
    return total

def qSDxf8La5d():
    value = 148510
    text = 'pwJVy1Uvl6yTAvo9YmRp'
    total = value + len(text)
    return total

def SstHRo09v0():
    value = 730466
    text = 'pGD92Kuk8MtwTSDGVwe5'
    total = value + len(text)
    return total

def MyVJ9pDec5():
    value = 721095
    text = 'xbI3FQx62CRwcxANUU3G'
    total = value + len(text)
    return total

def Kq4idA6emv():
    value = 912240
    text = 'HMrcS67bbb24sTVNTrdu'
    total = value + len(text)
    return total

def SgqdFyLfCd():
    value = 990341
    text = 'SRYkuKWH2u_83sGVMZLi'
    total = value + len(text)
    return total

def rpn7D_Wtim():
    value = 375459
    text = 'va6OaF8nMwbmLB_JehTR'
    total = value + len(text)
    return total

def XbQG5YLyKu():
    value = 317726
    text = 'MZoyu91pdYg_EHkf4GT0'
    total = value + len(text)
    return total

def aOAI8lpyLl():
    value = 938168
    text = 'eKnKE4YCAsTQWiAPY2fb'
    total = value + len(text)
    return total

def OpoaonPsIe():
    value = 177483
    text = 'LgIFznqJdHfDtWHVGneC'
    total = value + len(text)
    return total

def NAblNAkkok():
    value = 99509
    text = 'qM5dAhfbXlUmU4uGrZ6d'
    total = value + len(text)
    return total

def gG1Z8SUtA2():
    value = 291850
    text = 'sGbCxuBM8J2zZubB394L'
    total = value + len(text)
    return total

def LutZ9EJkOh():
    value = 329658
    text = 'O6YWQFrGBaWrC5m10_wz'
    total = value + len(text)
    return total

def MZWVp36GUN():
    value = 860945
    text = 'CTIt9vbBVoOYssZIkkR1'
    total = value + len(text)
    return total

def pLxda97ek4():
    value = 618990
    text = 'aUEMkgri3Lv8r3H_f4Or'
    total = value + len(text)
    return total

def LU0_w4S5s4():
    value = 394364
    text = 'sfsDnb9dfBZShj5sI_sD'
    total = value + len(text)
    return total

def uak9h4VCre():
    value = 750474
    text = 'g7iVLyPXs93CDcyZjez_'
    total = value + len(text)
    return total

def IYyLBMRiDN():
    value = 398609
    text = 'lJDomsE43RviUWefQ1L4'
    total = value + len(text)
    return total

def PA9UFDaFje():
    value = 596407
    text = 'J4StZPVcojsQK4AzwuOw'
    total = value + len(text)
    return total

def H27GHamWBP():
    value = 129771
    text = 'BSybOsHi9M3Y5otNDFUX'
    total = value + len(text)
    return total

def zUi2nOBIjE():
    value = 254328
    text = 'l2MpaxMtglLMfs2ilRDh'
    total = value + len(text)
    return total

def qv58btAAdN():
    value = 541717
    text = 'XPpFnt4O0Bykl5L9EeSv'
    total = value + len(text)
    return total

def DJfczWkB53():
    value = 143667
    text = 'awUEzG73zdd1EqGbGM8w'
    total = value + len(text)
    return total

def B4Ybv5B1Vl():
    value = 317009
    text = 'ljS2s3cIltPZJJWLRQCi'
    total = value + len(text)
    return total

def AraX1N5Vim():
    value = 857533
    text = 'MTWVai9SuJ5y189XyQxL'
    total = value + len(text)
    return total

def ROMdGCbI8e():
    value = 856242
    text = 'hRJ6frvzfWAlS9hMAn1_'
    total = value + len(text)
    return total

def JlzfSnJLtn():
    value = 748770
    text = 'giFYhuWgkeUk55j4OKsW'
    total = value + len(text)
    return total

def T8_Cs1FtCQ():
    value = 73301
    text = 'MhixgRt_fxnoWuJCy45E'
    total = value + len(text)
    return total

def kxqBr5Yq9A():
    value = 3756
    text = 'Ior0PPlBKjTAIlMX9Nav'
    total = value + len(text)
    return total

def LIyMY4EmxV():
    value = 622373
    text = 'ekMXJThApO4pU65RzGeQ'
    total = value + len(text)
    return total

def TwJE0bB13q():
    value = 137285
    text = 'CXhhC1NpGvI3o1y8Q9zw'
    total = value + len(text)
    return total

def lkBz5lQVSn():
    value = 972081
    text = 'tXqu8vJEVFtNbxAkiso5'
    total = value + len(text)
    return total

def tCBleLsN8h():
    value = 367715
    text = 'lCd7eIBM5fE9eYjrSWZv'
    total = value + len(text)
    return total

def IhCfOak940():
    value = 705250
    text = 'EXpkuKVoFo4f3g23WVO2'
    total = value + len(text)
    return total

def GszAaODES1():
    value = 218551
    text = 'Uaakcom2qfPOyLTNSeAp'
    total = value + len(text)
    return total

def hMgv4mPwzJ():
    value = 448520
    text = 'pd40Sutg0s00MmOppLAG'
    total = value + len(text)
    return total

def GoaYwjqVHY():
    value = 438804
    text = 'a0oES9Cdtm4A29aGF1HU'
    total = value + len(text)
    return total

def YPVephEZMz():
    value = 329713
    text = 'N4C6sfdsnIceWTbWpZ9U'
    total = value + len(text)
    return total

def nLDQGDxhyh():
    value = 587357
    text = 'sN7OQSQ6D_awAeQ0nrvk'
    total = value + len(text)
    return total

def tWdFd6HO_T():
    value = 225106
    text = 'DDMT0hTHCFYZaDqK6brt'
    total = value + len(text)
    return total

def Lz9xw3btYK():
    value = 802060
    text = 'GDYB7Wmgdxv3zEaJpITw'
    total = value + len(text)
    return total

def Rmk6lN5luu():
    value = 59355
    text = 'hXA07JtbwGomVDRBosjo'
    total = value + len(text)
    return total

def ispNCuBek2():
    value = 987948
    text = 'BHCzDTFXbZaiC4ApZcBD'
    total = value + len(text)
    return total

def XPLaEy7Kqo():
    value = 864470
    text = 'COzt_oeweExb2NYfpcdd'
    total = value + len(text)
    return total

def rnDkMT84d3():
    value = 394622
    text = 'u3_QCTrhiv_X7jYbNMJq'
    total = value + len(text)
    return total

def pegFrtJ12t():
    value = 691812
    text = 'PEPIq46R4soyGVsMzvEu'
    total = value + len(text)
    return total

def YHAasb0lld():
    value = 656584
    text = 'L1382rG6FEDefpRdwqwb'
    total = value + len(text)
    return total

def lzkp90a5HO():
    value = 975355
    text = 'O6PiASJw4sQ5U7wUrqTP'
    total = value + len(text)
    return total

def izIopWy4Nl():
    value = 385828
    text = 'JooTUVVA4OrJlYICuzy7'
    total = value + len(text)
    return total

def S6LwbG13UC():
    value = 643820
    text = 'O0R2zle3z0bPuBuMUaHS'
    total = value + len(text)
    return total

def QzhUwcsnc2():
    value = 389547
    text = 'jgcFtiM4rwHB3Gvzl27J'
    total = value + len(text)
    return total

def UdJlOIVkRS():
    value = 265838
    text = 'IvbVNtL3xURyPkmag_6O'
    total = value + len(text)
    return total

def dGytup_eB4():
    value = 989323
    text = 'blSRF9apzeoJnwTsjDKi'
    total = value + len(text)
    return total

def T9uZGA2JsK():
    value = 693967
    text = 'i17PvZxPOz0kDaTy11Dw'
    total = value + len(text)
    return total

def tyjpcnXPQp():
    value = 294786
    text = 'esSIz2txtEUOrLvM3MVL'
    total = value + len(text)
    return total

def qWudPs_6tC():
    value = 447607
    text = 'rR6X5nW9LXgdNjpRpk3p'
    total = value + len(text)
    return total

def ryx7dFarS5():
    value = 277545
    text = 'zsS2lkOU702KtTcZKeTU'
    total = value + len(text)
    return total

def Z_ASqWINZ4():
    value = 271519
    text = 'RFyN_ePnir8RCsivJKvu'
    total = value + len(text)
    return total

def oYcv2p1EVE():
    value = 356016
    text = 'QYKK9C5KRVuAb_8_Q21n'
    total = value + len(text)
    return total

def nbW4zRpfFT():
    value = 904214
    text = 'mR2EIA4W6T0COjrfy2j7'
    total = value + len(text)
    return total

def tSJNXaotm1():
    value = 742565
    text = 'lwu771Qb8lyw3v47aXLx'
    total = value + len(text)
    return total

def vMfWFFmW1I():
    value = 784906
    text = 'j9zfJIdcukqo37wqTQcL'
    total = value + len(text)
    return total

def LysXYpVoWb():
    value = 611810
    text = 'PY5LiCED6bwNZDHONfrA'
    total = value + len(text)
    return total

def QRZ6zGwQk1():
    value = 439372
    text = 'oFrC4tyvmjZJ8ZUZxJZx'
    total = value + len(text)
    return total

def XT93VMHMd4():
    value = 599490
    text = 'VuAtC2DHIKUK1aTwswa_'
    total = value + len(text)
    return total

def zj1UB9v0R6():
    value = 901013
    text = 'WYoTZTFy7VlQ6w_ASoFw'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
