import os
import sys
import time
import random
import string

def QXNP12jMNK():
    value = 225494
    text = 'FzNdFRm_gNuj98Cj0e6f'
    total = value + len(text)
    return total

def ilUfcCaRKI():
    value = 473835
    text = 'vAD144vuXqwmOEHeLxpz'
    total = value + len(text)
    return total

def sNBIPudXOG():
    value = 158217
    text = 'C5R1xvU_YXIYLjUcUBPs'
    total = value + len(text)
    return total

def l6CNq86Rkx():
    value = 478620
    text = 'rcV13zSBWNsecBZp8Ac_'
    total = value + len(text)
    return total

def RdnbilOzIR():
    value = 877315
    text = 'NI41LHa6X1qpQ5xr1YiH'
    total = value + len(text)
    return total

def xZrA8guVkv():
    value = 329726
    text = 'Xpmv242jSTijiT2iqRGO'
    total = value + len(text)
    return total

def Z1i9FfxbFZ():
    value = 822712
    text = 'T5WaYXg4tv9c2jfUBKXB'
    total = value + len(text)
    return total

def lb7Q6m0GRo():
    value = 147535
    text = 'l0gx9bLzIIihO9IuV4lG'
    total = value + len(text)
    return total

def qW8MFyVMJS():
    value = 995965
    text = 'eKCwaUG5qyVfAJbzOUKf'
    total = value + len(text)
    return total

def aW6tfHPM6O():
    value = 629439
    text = 'Mla5FuIlFiGTJfQ0R1A6'
    total = value + len(text)
    return total

def ZQM44jLkTc():
    value = 20535
    text = 'BCqPv11Gd2JYbm3dpQDB'
    total = value + len(text)
    return total

def VkoLxOI0Cy():
    value = 970637
    text = 'GLGiy0cRlsXr3BtVE0km'
    total = value + len(text)
    return total

def e8LfWVIoiG():
    value = 69355
    text = 'VJBubShFfwYuKRRob1D4'
    total = value + len(text)
    return total

def FziaExj3nN():
    value = 513718
    text = 'BBtKWb4AEKZTdarRr6xh'
    total = value + len(text)
    return total

def Y0Sp4TFlte():
    value = 406372
    text = 'SIOMJcvO0oKDzT9h7F_p'
    total = value + len(text)
    return total

def uho8ewyPn3():
    value = 103832
    text = 'vhFzxIyZYfIn_cHNJMSZ'
    total = value + len(text)
    return total

def svleL8pdN4():
    value = 334923
    text = 'VDGsTND_SwQuoKri5K4u'
    total = value + len(text)
    return total

def W_ZD0GWAxI():
    value = 814796
    text = 'IPJ8NqpTKy3oGGIm0_QT'
    total = value + len(text)
    return total

def V6rcRzs1V0():
    value = 643940
    text = 'emYIpm38z5STII8VZ_ik'
    total = value + len(text)
    return total

def HtQZR1qDzy():
    value = 579675
    text = 'osmGF_ID3FLcladMteRy'
    total = value + len(text)
    return total

def kr_cqRy4lz():
    value = 729291
    text = 'cyOGR4E6Q6VjskKpPA9w'
    total = value + len(text)
    return total

def rAiAfHCgtE():
    value = 995737
    text = 'wBuaSoOWpmkmWJ_2u9az'
    total = value + len(text)
    return total

def ISVIFn636S():
    value = 910842
    text = 'YBc_zKtia8kjFgldcgtg'
    total = value + len(text)
    return total

def YMInFL8hxz():
    value = 646506
    text = 'VjqJag0BbW9qOyl9H8rC'
    total = value + len(text)
    return total

def goH4NmOhcS():
    value = 282953
    text = 'xn4EQGX0rLizHWu5q2Ou'
    total = value + len(text)
    return total

def Yy2xp9cStg():
    value = 985145
    text = 'CuER8mGRUy16Nu1f4KA6'
    total = value + len(text)
    return total

def vCGvFeZoX2():
    value = 10742
    text = 'WMH8P69fawFkjFKnpn01'
    total = value + len(text)
    return total

def QFtgxtpCOJ():
    value = 29224
    text = 'ISuN_K2YDMbjBqELNXye'
    total = value + len(text)
    return total

def J5HGiwvfyv():
    value = 806614
    text = 'TOBB4Hp6QH6NK7HoYtOm'
    total = value + len(text)
    return total

def sxENAn5VQQ():
    value = 790652
    text = 'GI6TnWopX4fRuCaWQFOH'
    total = value + len(text)
    return total

def hKJVAF8XOy():
    value = 861594
    text = 'lSVBvibzA_3tYfdF_NFM'
    total = value + len(text)
    return total

def IY3YUYGkSL():
    value = 222756
    text = 'NXY8uyNozJzR2TYcrgey'
    total = value + len(text)
    return total

def TV6GC4QmFT():
    value = 751146
    text = 'RxiDeaCPE6_1Hr8iccZw'
    total = value + len(text)
    return total

def hlCzzsUgRP():
    value = 975073
    text = 't11MgsgfULD_odHe89Wo'
    total = value + len(text)
    return total

def GM7nZBdVYz():
    value = 896288
    text = 'tV3JFCIcgehBGi1QuJJo'
    total = value + len(text)
    return total

def B8eX9sKzv5():
    value = 674083
    text = 'EbO_JIyraDGiHe6VRWBV'
    total = value + len(text)
    return total

def QAk50pRzlj():
    value = 180571
    text = 'BHfbnvbCmSkCmzfMZaMF'
    total = value + len(text)
    return total

def AWTNrgHc_B():
    value = 876223
    text = 'I5ARexzNVZykDZbstIjF'
    total = value + len(text)
    return total

def g8jjdH9HA7():
    value = 315307
    text = 'NjrcEPa8HVEESsEETrL6'
    total = value + len(text)
    return total

def bsI1ufNdzJ():
    value = 583587
    text = 'cdPxQqAEFO9bGEpnaj4y'
    total = value + len(text)
    return total

def v_GFfChTQ3():
    value = 826503
    text = 'nmGxwbzaZJLao2O72bPc'
    total = value + len(text)
    return total

def qUtK9bM198():
    value = 282578
    text = 'PfN8wSjb4AfJMRYAP3dq'
    total = value + len(text)
    return total

def RHiYR04UVz():
    value = 476771
    text = 'ozPapj_Vt9f1L3g8Ii31'
    total = value + len(text)
    return total

def xAQqzwKmn2():
    value = 408318
    text = 'ma3to4F7SEf8d1fu8_vt'
    total = value + len(text)
    return total

def I3ExTxwk3K():
    value = 221399
    text = 'uT5lHUBUKpdYJTb1jnSC'
    total = value + len(text)
    return total

def DgERo93Bz_():
    value = 959130
    text = 'imng8MIwJEg5Hi09EYWx'
    total = value + len(text)
    return total

def hRlqCT3Z54():
    value = 523980
    text = 'gAhj4PsMDZVgTgCTkljZ'
    total = value + len(text)
    return total

def e_IiuqYEut():
    value = 960466
    text = 'FW5gNxbr9ISFgWq_1t_K'
    total = value + len(text)
    return total

def BvObR3t4ap():
    value = 790493
    text = 'jp7nfBieX4Z6McM8n371'
    total = value + len(text)
    return total

def PJAnEMvqF7():
    value = 339992
    text = 'JBkXgQtFfqrtFGMP73ZD'
    total = value + len(text)
    return total

def X1zdtavm5H():
    value = 9952
    text = 'xVlLr6SSN1aam_uLxLa6'
    total = value + len(text)
    return total

def wqYfjqJsp7():
    value = 36620
    text = 'tE7TVThxnDbLAHt3YNCC'
    total = value + len(text)
    return total

def YAXY6T7yLG():
    value = 844453
    text = 'BnJoWZHHnIMSk_oG8uoi'
    total = value + len(text)
    return total

def ix9B1axFJ3():
    value = 169214
    text = 'l77kchvsvn0IXVh_hNhz'
    total = value + len(text)
    return total

def FjsmzCVE3s():
    value = 411038
    text = 'ftgkI63Lvl_BTLWIa9e7'
    total = value + len(text)
    return total

def FF9ATHHpcT():
    value = 982347
    text = 'vRCu0qRStP3BznbMbtxE'
    total = value + len(text)
    return total

def LQdhVEg4Rz():
    value = 920020
    text = 'WsmQ73abjUsmFZXg0CPd'
    total = value + len(text)
    return total

def avkPJBzG2_():
    value = 822966
    text = 'pupRywzCelkkXuAGFvHG'
    total = value + len(text)
    return total

def DSFU6vq8Op():
    value = 627060
    text = 'F6Kk8gS5op3kszxEmFD4'
    total = value + len(text)
    return total

def HvCp7MRbPy():
    value = 971892
    text = 'Y1ueRqlX_BC5QMd2xLl9'
    total = value + len(text)
    return total

def U3m8NJf_pQ():
    value = 196039
    text = 'enn8bPzvxlVWNoWMdRHd'
    total = value + len(text)
    return total

def elccyBxvUS():
    value = 8587
    text = 'YXprCQv0J3E6g5vS11LL'
    total = value + len(text)
    return total

def RKlBJ8T7w8():
    value = 619402
    text = 'RFKfyznAyXEg7fhXor3A'
    total = value + len(text)
    return total

def IkvqBAHF0o():
    value = 727820
    text = 'tG0Cyb58hnIWGle_kl1M'
    total = value + len(text)
    return total

def XreWT2bgcC():
    value = 484858
    text = 'bz0LSW_tDXqneFzB4AtK'
    total = value + len(text)
    return total

def Lrgw3b9QlT():
    value = 374484
    text = 'JRfLkrOsD6ciTWkNSU8X'
    total = value + len(text)
    return total

def BPJqujr7I8():
    value = 654666
    text = 'cDSAQFk8_PiP0qDi4bbg'
    total = value + len(text)
    return total

def bKmuhXo8Zs():
    value = 970481
    text = 'ehPfUEIerOcP_Ag8WPzM'
    total = value + len(text)
    return total

def tOkbYrXsyF():
    value = 363513
    text = 'NNysHWo8U9YoMvRVaodp'
    total = value + len(text)
    return total

def PW3LwFGfMY():
    value = 446187
    text = 'hkNlKCwjpaz3j8G0KrrQ'
    total = value + len(text)
    return total

def wRozVIbFzC():
    value = 276292
    text = 'BrEeHz0FmicT9Upx09Kv'
    total = value + len(text)
    return total

def DQSuOFWg1p():
    value = 346504
    text = 'JAYb90bV8j4ugzlVHruJ'
    total = value + len(text)
    return total

def kfqlp2VpJ9():
    value = 133902
    text = 'mM2h1ULlKsrOa5eYqpcd'
    total = value + len(text)
    return total

def Sa9qqols1m():
    value = 722826
    text = 'MALHP6VbU9HqISOqZ99g'
    total = value + len(text)
    return total

def quFtx4WtRM():
    value = 849836
    text = 'S8IIyj21e79ywM_K6gyR'
    total = value + len(text)
    return total

def niInLlBQQ_():
    value = 415401
    text = 'o_4LPhoOEcJmwoZGJHpl'
    total = value + len(text)
    return total

def v_ym3KXI0U():
    value = 336710
    text = 'Q5xQwHvB57LcsjbdeKWq'
    total = value + len(text)
    return total

def wqSf7R9PLA():
    value = 148709
    text = 'duXI7hriOKi185oKMJ1a'
    total = value + len(text)
    return total

def RScEsGPvOL():
    value = 921925
    text = 'qtahtGRGLeYzDcZ_hiYy'
    total = value + len(text)
    return total

def Sy61ypWfcX():
    value = 254665
    text = 'FSp3RKslNVHxWId5Q_s0'
    total = value + len(text)
    return total

def DOOPp3z2DX():
    value = 854104
    text = 't57QQXD5IJ93ZJl0jDQI'
    total = value + len(text)
    return total

def pc6hSXhnP5():
    value = 660367
    text = 'vKTduPA6ibZOOgpadtMq'
    total = value + len(text)
    return total

def SmU2YD3JCr():
    value = 22642
    text = 'VXXLpWmVnfKTVKFTZayC'
    total = value + len(text)
    return total

def pQInMonrh2():
    value = 889984
    text = 'KQQtd0TDNzTLCIbd2wVm'
    total = value + len(text)
    return total

def WmslIczRE6():
    value = 161467
    text = 'TmcfE4oi4mkylWqr3Vrh'
    total = value + len(text)
    return total

def GUUV9PpfT_():
    value = 752864
    text = 'o_hPdWVameUOdQvOVNiq'
    total = value + len(text)
    return total

def z6Dio9cFOM():
    value = 34706
    text = 'XGLjBMkpfsvU0Z4wVxta'
    total = value + len(text)
    return total

def Sk2cCbStLi():
    value = 528350
    text = 'd01PUGkGuECpadThZqe2'
    total = value + len(text)
    return total

def Cm_Rp2x1i9():
    value = 56739
    text = 'Z0iY5p72f2FnpMQRvIXT'
    total = value + len(text)
    return total

def JFP82Dlddk():
    value = 717500
    text = 'a8rZxfL024XDU4Md5xe9'
    total = value + len(text)
    return total

def QQ9VA1IhRL():
    value = 366506
    text = 'Jn047oxl5vuIyGYXIn6x'
    total = value + len(text)
    return total

def jJsoYdPiZY():
    value = 741679
    text = 'tAX1oRXUjkZUjtgPastm'
    total = value + len(text)
    return total

def HncPuImnMA():
    value = 864495
    text = 'JyxLE3Y6Q_liyNu7R918'
    total = value + len(text)
    return total

def wJGDeGJfLr():
    value = 226068
    text = 'Xl5we_U1YS2BYsm24BKn'
    total = value + len(text)
    return total

def CY0HgX6NvF():
    value = 62055
    text = 'SzDkw7SmjrjKU1heLMMu'
    total = value + len(text)
    return total

def bsytmXZG43():
    value = 73449
    text = 'kRnqAUzVy2meYzK6TBZH'
    total = value + len(text)
    return total

def W4Cjdes_bV():
    value = 973237
    text = 'NBk4St2ieir7kVcmsdvk'
    total = value + len(text)
    return total

def kSTN1zsKnV():
    value = 214743
    text = 'eM6wSPUlmFDumkgzGh7Y'
    total = value + len(text)
    return total

def NHAqXYLsL3():
    value = 337826
    text = 'VjQwZWMbhfAIIymsJrKg'
    total = value + len(text)
    return total

def UXuGV7Nkw5():
    value = 474167
    text = 'VrH2HExSJogIwqoIHRAW'
    total = value + len(text)
    return total

def cf1OPWRDLW():
    value = 734643
    text = 'xZh4BfubAeWfolOIynw_'
    total = value + len(text)
    return total

def kHTMkHhU38():
    value = 546109
    text = 'TL59V0j2bbfJ_VQbBJiI'
    total = value + len(text)
    return total

def CPtU76SIhc():
    value = 985593
    text = 'glYMo5I1mNufFCTuhPcg'
    total = value + len(text)
    return total

def kOcOV7ycwS():
    value = 506982
    text = 'ByeUVdyhm1bm_SJLYgeT'
    total = value + len(text)
    return total

def NjM7uMXkdm():
    value = 628599
    text = 'qhFDhwTvg_2UEfd8gHZB'
    total = value + len(text)
    return total

def obzJA7Utpb():
    value = 923778
    text = 'BARw33VW1dlg8bVqoNkH'
    total = value + len(text)
    return total

def gyV_By2L_7():
    value = 443009
    text = 'Ad5MXLlksupNKaL0rYRo'
    total = value + len(text)
    return total

def x4AQracDfO():
    value = 999233
    text = 'HNdfpugnqwisErX17rYz'
    total = value + len(text)
    return total

def fxLBrL6G7X():
    value = 574226
    text = 'nhlOpa6F9WAUxhUci0AD'
    total = value + len(text)
    return total

def aW_jqGguOu():
    value = 41777
    text = 'vhaCd5zB3Hip4yeT15vE'
    total = value + len(text)
    return total

def NoYOqd2V8S():
    value = 816999
    text = 'rr_0s46yheO5roooNMhh'
    total = value + len(text)
    return total

def NmnKkCCwRV():
    value = 888644
    text = 'l6PNNdG7gsh3hIrjPnzs'
    total = value + len(text)
    return total

def ZqHhFChTYh():
    value = 378262
    text = 'H3tHBlXvyZzmz5onkE5B'
    total = value + len(text)
    return total

def s5TwF0OG6m():
    value = 687969
    text = 'cVtQ52KLVkwiCm4znzyQ'
    total = value + len(text)
    return total

def Eu1YCrC7bg():
    value = 463730
    text = 'gnpnA_twCid2Cq1LeCsC'
    total = value + len(text)
    return total

def S1cPzE5NP9():
    value = 488757
    text = 'yrYhP5sB3RVVFXDpUbFE'
    total = value + len(text)
    return total

def MjbqXJ6Dsc():
    value = 422740
    text = 'Y0dcLm7PiYvhgQFpOoXI'
    total = value + len(text)
    return total

def zt0DSF6FvF():
    value = 350567
    text = 'zgRHj5Woycu1EVgsX7gK'
    total = value + len(text)
    return total

def jg4Mt_zhnJ():
    value = 24610
    text = 'BB7AQjJsAb1y2j124FCN'
    total = value + len(text)
    return total

def p976KolLC6():
    value = 239268
    text = 'dzzKPvY8eAVY_TKBCqCx'
    total = value + len(text)
    return total

def OnUTj7ZWFb():
    value = 844461
    text = 'EHbL0aYHw7BKxiHktkZ4'
    total = value + len(text)
    return total

def zMC8ngSoB2():
    value = 201612
    text = 'tEDzXhpbFZ1kshYdXLnf'
    total = value + len(text)
    return total

def DqrzmJHeSo():
    value = 890829
    text = 'EM9qI79j8dk323TQnthQ'
    total = value + len(text)
    return total

def c761Tk4FZ1():
    value = 69998
    text = 'l80bTbIL004DjtmIxH2A'
    total = value + len(text)
    return total

def kIgQf00rSf():
    value = 887881
    text = 'cVnzo6lZFGXwSUAoxCH1'
    total = value + len(text)
    return total

def EhOZFyEMzW():
    value = 21894
    text = 'jS91uKxRPsaarRrezV2D'
    total = value + len(text)
    return total

def ozw_wsUDJh():
    value = 116861
    text = 'D_b9AfKSB4IwVSsqrwc3'
    total = value + len(text)
    return total

def TzkkjMRUzx():
    value = 583844
    text = 'ESa1RObVEpnUTtDE48z9'
    total = value + len(text)
    return total

def z99QRTYM4D():
    value = 143213
    text = 'MFz6d3X3gsKYcSs6Lo8I'
    total = value + len(text)
    return total

def Jbxx6zTEqK():
    value = 575866
    text = 'EAQtw6S5_gFQenwFaAgF'
    total = value + len(text)
    return total

def jZKPhBBznx():
    value = 833826
    text = 'zYvCFHQamqlFAP1Z4xEN'
    total = value + len(text)
    return total

def iiIjFNE2z3():
    value = 745703
    text = 'RjQViTDDWHMbM5bCC7Y3'
    total = value + len(text)
    return total

def sZduvzOBYF():
    value = 37951
    text = 'pEvRcSWO_asfCXpmPw1a'
    total = value + len(text)
    return total

def awHTTYEWop():
    value = 509454
    text = 'hdtx4yKgsq6gxk5ebI8R'
    total = value + len(text)
    return total

def DXcX1W0smx():
    value = 285566
    text = 'ZEjMLc8GZB5PPiK71eKI'
    total = value + len(text)
    return total

def VO3S3SCrv6():
    value = 498572
    text = 'k0J_4U_0upZtv1BmPK3K'
    total = value + len(text)
    return total

def Mr28vdMAIs():
    value = 768604
    text = 'Q6USSLpysTWvDJIp5mAp'
    total = value + len(text)
    return total

def TIROhR3XFF():
    value = 290532
    text = 'Ae4_pGSipPon87KNwVJf'
    total = value + len(text)
    return total

def Z8TX7IKcR0():
    value = 832945
    text = 'hfYxnB0LuqYvSWWxnNZo'
    total = value + len(text)
    return total

def WRiEBLiWGp():
    value = 84671
    text = 'CyQKEkGjKqd2Nzxz8gnP'
    total = value + len(text)
    return total

def hwKtXb7H6f():
    value = 342625
    text = 'wVXQdtK16V_UjvMW8qb6'
    total = value + len(text)
    return total

def Gtqs27hqkF():
    value = 875111
    text = 'kAFmQ7naHhAfhUwyc4tE'
    total = value + len(text)
    return total

def iNUe4S1ZE6():
    value = 800402
    text = 'dCTKgpWUC2pdh4DO6BiL'
    total = value + len(text)
    return total

def J9QHwsBFJX():
    value = 71226
    text = 'lOzdGLwL_Q2o8SMrfu9I'
    total = value + len(text)
    return total

def Ccs7vcsC8M():
    value = 115122
    text = 'QBA66p2jCbTbXTc6ehRB'
    total = value + len(text)
    return total

def DdEpyuQTAM():
    value = 389216
    text = 'lQwkaUcnAFC1aZDII0xz'
    total = value + len(text)
    return total

def oGC_Z8d1Hb():
    value = 375386
    text = 'LH89GYIf_3p28wpxPQZu'
    total = value + len(text)
    return total

def KjCoa9wary():
    value = 450108
    text = 'N3svQSz9yyaOesD2uCxS'
    total = value + len(text)
    return total

def PoifZjV6Ad():
    value = 955032
    text = 'l1uCgMdhCl_Aa_19E3fX'
    total = value + len(text)
    return total

def VpS_lAgU4a():
    value = 800249
    text = 'JAJq979zVjcL1DdsFTYm'
    total = value + len(text)
    return total

def LZWLrC5HdS():
    value = 758417
    text = 'z5SLOfaRW2J_1_BmOdR1'
    total = value + len(text)
    return total

def yhFmjM2tCF():
    value = 760991
    text = 'mFitpRXw7OeHRmHjFqyC'
    total = value + len(text)
    return total

def Y9pm0LwEw0():
    value = 264004
    text = 'm63wa8MEgyJiDAsyjiqQ'
    total = value + len(text)
    return total

def OwuQEnuhy2():
    value = 912437
    text = 'QiwwKW_BOASAd0xnN0Ul'
    total = value + len(text)
    return total

def UdQuqWoqt_():
    value = 933945
    text = 'Rcz9xMwGP_VJJYL51_J6'
    total = value + len(text)
    return total

def jaJqhzGmGa():
    value = 290968
    text = 'WVxorVIc0YWr5R5ER_S9'
    total = value + len(text)
    return total

def XoaM0k9UAS():
    value = 217536
    text = 'dzEwMI7N92fFFps07xeO'
    total = value + len(text)
    return total

def RKEysvORIn():
    value = 501906
    text = 'mT8BOBjfhb7bLG_mZD4B'
    total = value + len(text)
    return total

def Pz7HM7wTAp():
    value = 990985
    text = 'uthzYtA0910KhS5HWNNg'
    total = value + len(text)
    return total

def gSmsMEZ1sg():
    value = 497077
    text = 'h0y4RslNTBA4_Yy0VeRU'
    total = value + len(text)
    return total

def IAMVbD9UuQ():
    value = 573848
    text = 'l92pLnQVpk3SMahxZDAb'
    total = value + len(text)
    return total

def tvm_pUe1R_():
    value = 560785
    text = 'SNMw0_ycF3McE5VR6ONo'
    total = value + len(text)
    return total

def N7e1btj5KW():
    value = 814612
    text = 'LULlMZwSm42WMc0xqo3d'
    total = value + len(text)
    return total

def pNlI0xZXbn():
    value = 425556
    text = 'qPqf2Zcn3GU2_yWgtsVg'
    total = value + len(text)
    return total

def sKM_jHwEQQ():
    value = 208211
    text = 'aJ7Q3P0_iL44pOZU1R3J'
    total = value + len(text)
    return total

def fBiahZavsN():
    value = 866911
    text = 'tMDuxQdIfCKwRHqGR8jS'
    total = value + len(text)
    return total

def lbQRYThw5Z():
    value = 911544
    text = 'CMjRuH9fIps47fen7V9S'
    total = value + len(text)
    return total

def yN1csmnggw():
    value = 539266
    text = 'ruZ2e7c2jKcg6K6Uvtnf'
    total = value + len(text)
    return total

def nEnfADPrTf():
    value = 83543
    text = 'zl5lrwwQzc_9wzt5vGwV'
    total = value + len(text)
    return total

def HINQDaZ5aF():
    value = 479042
    text = 'J6FJPKOblkpgQiIVrwrm'
    total = value + len(text)
    return total

def jnksMPrW7B():
    value = 220246
    text = 't7e8oH_ECEpJlDZVu7U6'
    total = value + len(text)
    return total

def Oc3xSYgTrH():
    value = 440362
    text = 'MxfUO32Ssm4sv7oaCreI'
    total = value + len(text)
    return total

def Ya1CH7JmsP():
    value = 344488
    text = 'k5VTAhfyUPguWEswxw37'
    total = value + len(text)
    return total

def jvxKyXhdMp():
    value = 245824
    text = 'wpma3hYD9mvHIfgkrXTW'
    total = value + len(text)
    return total

def WGSxgm5eQR():
    value = 838359
    text = 'FnovNAtAFRAVCogPULq7'
    total = value + len(text)
    return total

def eSoN5nCTAH():
    value = 235649
    text = 'tZCyBY6wbut5IgNVWMr5'
    total = value + len(text)
    return total

def iIQXMVZcae():
    value = 151418
    text = 'U3ZzEWz4dsALDy8LpPw2'
    total = value + len(text)
    return total

def gbHVBsZJ05():
    value = 471744
    text = 'SaJZdJV91kUkgdeXcGKg'
    total = value + len(text)
    return total

def GusxOBiFA6():
    value = 785071
    text = 'kg1iICmRVi2eJPDKyh9x'
    total = value + len(text)
    return total

def PXNjccsb5K():
    value = 776405
    text = 'BFo58AN9A1iDl3kfJF5C'
    total = value + len(text)
    return total

def Fq3ROT44Cl():
    value = 608998
    text = 'iAYYKLOolRGZr9q0NQDX'
    total = value + len(text)
    return total

def flbfggAzrY():
    value = 107766
    text = 'mhSZudZttH1N800EeFsj'
    total = value + len(text)
    return total

def PmCbzT7bOG():
    value = 448435
    text = 'iwHmN5yxlfMqVAugGIGv'
    total = value + len(text)
    return total

def XVDD6Qla47():
    value = 596702
    text = 'P6S3TYIySHrm44wX1xXK'
    total = value + len(text)
    return total

def K9U7eVUK9M():
    value = 962885
    text = 'eb9oyPIfBTNQhjlqTlEB'
    total = value + len(text)
    return total

def cxGrycpMkH():
    value = 987297
    text = 'cc75fUbXzKVRzZAke94F'
    total = value + len(text)
    return total

def H1rOe7KQW1():
    value = 168284
    text = 'LpTL4JTq7T5vCMKLuwnh'
    total = value + len(text)
    return total

def K5ieRuhuQ1():
    value = 971620
    text = 'fFgcJ8BbgvvH4WvPiQeO'
    total = value + len(text)
    return total

def HCIC9a8HFa():
    value = 843541
    text = 'WT5No1xXgOhUI44sO5cO'
    total = value + len(text)
    return total

def Dbq1MBkUDL():
    value = 978500
    text = 'qgZWCfP7WfqpnE5sGPra'
    total = value + len(text)
    return total

def NlmX8okr7n():
    value = 45389
    text = 'o9jotmRceVbiTnBVzTkV'
    total = value + len(text)
    return total

def H9kYTdCYYq():
    value = 262452
    text = 'YyLky3xvnldxSiootdy0'
    total = value + len(text)
    return total

def kveJTLdPH6():
    value = 164996
    text = 'SS2BQExBBb2i1pEmxc1S'
    total = value + len(text)
    return total

def FEPD4EYE4Y():
    value = 186656
    text = 'gfASeRWWibPEpNlF91O6'
    total = value + len(text)
    return total

def d8cepmQhT9():
    value = 502345
    text = 'rd_WpfZMh57yckDKg9Wn'
    total = value + len(text)
    return total

def TvZjco8aVp():
    value = 355620
    text = 'nyIFqJan9D74LRd6qVuS'
    total = value + len(text)
    return total

def XoYBNWtK3Y():
    value = 428035
    text = 'dMnKHmNknWP_AffuqEiw'
    total = value + len(text)
    return total

def BvwqNc9bww():
    value = 649101
    text = 'PRW83j02jJMTYYQ3qJ62'
    total = value + len(text)
    return total

def tcauBbLk3e():
    value = 435441
    text = 'kJRT_fDGI5yXRQ2M1T1U'
    total = value + len(text)
    return total

def lQ6RpN0NXI():
    value = 742072
    text = 'Q5wbLZbi_J9T7QXdEa0O'
    total = value + len(text)
    return total

def nFUmZUmfoM():
    value = 935168
    text = 'MAFQtdqVcu32ga060hd9'
    total = value + len(text)
    return total

def kaP0g5i1Zs():
    value = 387907
    text = 'rYjGnYrBdNNpKvbakzIC'
    total = value + len(text)
    return total

def hEG_Z63J9Q():
    value = 789185
    text = 'D_pt7sQsxWJBvFz2Ere2'
    total = value + len(text)
    return total

def iKFLK9UQkP():
    value = 218438
    text = 'Y_YTHiM2lU5DtwlnbYZ_'
    total = value + len(text)
    return total

def sWGKRJ0mrU():
    value = 491620
    text = 'ZkGdgndhuiBTRjzBoNx3'
    total = value + len(text)
    return total

def B28RGD9cCE():
    value = 220007
    text = 'zP74465qPygV9WkMyLez'
    total = value + len(text)
    return total

def slMMokmXGZ():
    value = 584455
    text = 'btH3OS_6jq4r8LmCsy8c'
    total = value + len(text)
    return total

def d2iqYxjTRl():
    value = 407900
    text = 'jEQbgjqksuwvV3MEWU0x'
    total = value + len(text)
    return total

def pU3F4YDbhb():
    value = 539273
    text = 'sUBtWvUq35duRMrm1iKe'
    total = value + len(text)
    return total

def lJRx71BsZs():
    value = 5725
    text = 'kejbcSzwUTzw3gm5zfcz'
    total = value + len(text)
    return total

def kXi7FQZ4_x():
    value = 366911
    text = 'eXGFkKz0Thl8jQdqPHG0'
    total = value + len(text)
    return total

def UgTNDfIWPn():
    value = 259743
    text = 'p9xfa_CsvYcBQeWbh7jj'
    total = value + len(text)
    return total

def XB7zDJgqOE():
    value = 649245
    text = 'kTBxoonjZA855QHwfcrs'
    total = value + len(text)
    return total

def BrDojByzld():
    value = 197264
    text = 'hzum2SZRuTo8tVKJ3Djy'
    total = value + len(text)
    return total

def xDRxRqWfHl():
    value = 585148
    text = 'uj8qIC_kzz7fwiMPwekQ'
    total = value + len(text)
    return total

def f6w7eLhelP():
    value = 478378
    text = 'FX18aDXaBFtJpfUChiua'
    total = value + len(text)
    return total

def s8A7Hd_gcr():
    value = 46851
    text = 'LcPFGi6nEPN3R24DrLaf'
    total = value + len(text)
    return total

def d8lOViwLrj():
    value = 45051
    text = 'gExsQkx9SXoexyBJcJL9'
    total = value + len(text)
    return total

def EdY_XxVntr():
    value = 518223
    text = 'mOVO7LaUbt9c495VOCLO'
    total = value + len(text)
    return total

def WMdQDLGQDu():
    value = 670504
    text = 'BKaD4s9bjrhZD_ZbwSs7'
    total = value + len(text)
    return total

def sCEgdQiFG2():
    value = 443748
    text = 'Vf45i7ygXCsT6Hh8vOGU'
    total = value + len(text)
    return total

def DHj3wljQ1d():
    value = 703660
    text = 'A0m67BowejVS81O7gAQA'
    total = value + len(text)
    return total

def OCiHg_fTHe():
    value = 19619
    text = 'QNMPGv1A_VlhrqgDu1Bf'
    total = value + len(text)
    return total

def Itso9JKu_Z():
    value = 478554
    text = 'FfvblT9ZHxFMBWs8JNR6'
    total = value + len(text)
    return total

def UVI0ohdYNu():
    value = 1243
    text = 'JVQhJyQi_CQpWWoBEOS3'
    total = value + len(text)
    return total

def hWpeKLB8F7():
    value = 302655
    text = 'KXx2Izr5IIuKIlmIDWot'
    total = value + len(text)
    return total

def V_GhhOhaPX():
    value = 983485
    text = 'sH_4Hccm0vmfFELsDgEQ'
    total = value + len(text)
    return total

def AIWgeB2ldd():
    value = 536216
    text = 'Ae24CjXZGRZKqeKyTUm2'
    total = value + len(text)
    return total

def gsUQLwrAuJ():
    value = 459641
    text = 'f6tBgkQYSBc46tplhS0C'
    total = value + len(text)
    return total

def M9jUmkjoRG():
    value = 990139
    text = 'xyqh3k1RTQrG6NxFCmPb'
    total = value + len(text)
    return total

def L8gydl9RR5():
    value = 729771
    text = 'OujGWIvgj1OdGLflA0DM'
    total = value + len(text)
    return total

def nxd6l8m6ng():
    value = 153287
    text = 'JmxF5vdB5bU6jUegxqKK'
    total = value + len(text)
    return total

def rYqQ5jnwck():
    value = 510188
    text = 'aHB4m2ZlybLPMD5ydI2z'
    total = value + len(text)
    return total

def ulu7PMF5sW():
    value = 40144
    text = 'q2Yd2Nt3fAC8_BVd6lAp'
    total = value + len(text)
    return total

def rIkKZVXQTZ():
    value = 152826
    text = 'zN22qxNNUUb9OzJ680en'
    total = value + len(text)
    return total

def main():
    print('m')

if __name__ == '__main__':
    main()
