import os
import sys
import time
import random
import string

def sQYhobpKvN():
    value = 704133
    text = 'Ct1VRoDM0w9360vQ4vJn'
    total = value + len(text)
    return total

def Hc1YpnDtu4():
    value = 616107
    text = 'DP7Ub_46l9RyrIKmvQdG'
    total = value + len(text)
    return total

def yrfiVZn3mu():
    value = 545436
    text = 'zekW2J7WpbHQgcQSPq5G'
    total = value + len(text)
    return total

def TLRHU_GnmR():
    value = 863095
    text = 'k3JVg92d760w7XHnMwfo'
    total = value + len(text)
    return total

def hTPemVyJ2u():
    value = 382055
    text = 'o6iO_mq1Slw4CSldtCN4'
    total = value + len(text)
    return total

def hrPSQjnfjR():
    value = 718741
    text = 'Z1nSZebuDap_gpAcMyev'
    total = value + len(text)
    return total

def b3jgAl574P():
    value = 389084
    text = 'nJWXl7rOW4KceepmoXPA'
    total = value + len(text)
    return total

def Ya66XMxm8T():
    value = 983343
    text = 'vg8mgnLCyrr745CzUgCT'
    total = value + len(text)
    return total

def BKiW0JKOzO():
    value = 787252
    text = 'NvHIpa1WaMtl7D8f1qpA'
    total = value + len(text)
    return total

def f7JL104MdS():
    value = 696124
    text = 'IRMIjY4DRxacDuxZqm8v'
    total = value + len(text)
    return total

def ATppNEDMA8():
    value = 949022
    text = 'hK6EJOmqhqGcFBxRcHN7'
    total = value + len(text)
    return total

def pjYjueb9L5():
    value = 50778
    text = 'FoioxnFOXyjBUgS3iSrP'
    total = value + len(text)
    return total

def BT0T_PzO6j():
    value = 615928
    text = 'dXm7FBumhbjjQdEU3TMx'
    total = value + len(text)
    return total

def g8UQg8Y8xS():
    value = 948419
    text = 'Bm8Dfv1rrMsOalYDhrQY'
    total = value + len(text)
    return total

def tyBLqAjyIv():
    value = 441555
    text = 'VKw_zRV0wWwy9YOFmXpW'
    total = value + len(text)
    return total

def IIdG8QvkRl():
    value = 587532
    text = 'h21JR6nxhHmvbeaUkuAO'
    total = value + len(text)
    return total

def D6XsRUUSju():
    value = 247768
    text = 'sYwPfi4i8qjGLkpWSYPe'
    total = value + len(text)
    return total

def dWylmotEEU():
    value = 534424
    text = 'YdKg1XsBw9aPwQOfGk38'
    total = value + len(text)
    return total

def WdQyMGfMAq():
    value = 372743
    text = 'V0Wyyh61dYIY6I8zkbbl'
    total = value + len(text)
    return total

def v5Qlc0VO9r():
    value = 339605
    text = 'kaUGlXxMk56_AAFUmlME'
    total = value + len(text)
    return total

def pU8UMmSin9():
    value = 200132
    text = 'n2qhJjaqCAM5CShh3zM8'
    total = value + len(text)
    return total

def NE4dO4ZdZN():
    value = 651380
    text = 'gUXXpKifVPchSj8YkOK1'
    total = value + len(text)
    return total

def kk86HZwfOd():
    value = 418358
    text = 'B9bPxdODLFOGFcnyOPkz'
    total = value + len(text)
    return total

def ChXLstLfog():
    value = 172553
    text = 's4MjcogJpd7nEN716EMt'
    total = value + len(text)
    return total

def AVX1C1Zba7():
    value = 641603
    text = 'e7JsoPVXFCaE0oOYcPeV'
    total = value + len(text)
    return total

def sXWJO5IMA8():
    value = 795584
    text = 'hLcKfQg1W2PBmTzRU3V8'
    total = value + len(text)
    return total

def Q4KnV7vWqw():
    value = 104978
    text = 'CB7rt44QOCJnQpM2cYSN'
    total = value + len(text)
    return total

def F0PhdZDj6B():
    value = 362282
    text = 'fXL4c4AB9EOoKmkL7CP0'
    total = value + len(text)
    return total

def uUUnsaGRM1():
    value = 278140
    text = 'jOJhkDOvI_pP_c5sjIOp'
    total = value + len(text)
    return total

def Vho1rlaJc5():
    value = 69228
    text = 'vBKrK97LLlkNkeY8P6nS'
    total = value + len(text)
    return total

def DDRYKQP_68():
    value = 441956
    text = 'OB7HmrEdMBPbZ6od_EiN'
    total = value + len(text)
    return total

def ga2YqUgyk4():
    value = 506062
    text = 'bONuvpr4uevWOwH50p1Z'
    total = value + len(text)
    return total

def vIi6NRd2Ao():
    value = 379844
    text = 'aGRu7Ue6qX7cqVQSdWhJ'
    total = value + len(text)
    return total

def wX42FGiyVe():
    value = 997198
    text = 'PR7C3TkL7iVg8tnllRcr'
    total = value + len(text)
    return total

def zBGHozBFj4():
    value = 24046
    text = 'fiRJSXAkyBake_Pj7Rhu'
    total = value + len(text)
    return total

def biZhiIbRjX():
    value = 473440
    text = 'wksMKIU8xej_XqIpjbzE'
    total = value + len(text)
    return total

def LsiRdqZ6Ad():
    value = 894247
    text = 'zKR55EMNjdpC7KD6qERD'
    total = value + len(text)
    return total

def WPaO6lhzmp():
    value = 430334
    text = 'Q8sEz4oRtHTE8sbHoCID'
    total = value + len(text)
    return total

def noo7gW4HG2():
    value = 734437
    text = 'M64OwjuJDrnWBwf61EtR'
    total = value + len(text)
    return total

def a8LD_2DtlR():
    value = 218953
    text = 'P5cUPabAQq9wkdzIH81k'
    total = value + len(text)
    return total

def DMnUPau5jO():
    value = 428510
    text = 'cSzRQ8cBoFTD5DKCoRIk'
    total = value + len(text)
    return total

def IMl8SpOL6T():
    value = 885220
    text = 'Kzny7bd1PhxgXXHe5jUL'
    total = value + len(text)
    return total

def sema3YLteD():
    value = 275624
    text = 'laRYEEAeHRP1OWeXC5Vu'
    total = value + len(text)
    return total

def R8NQ1d4uFD():
    value = 461967
    text = 'i0XDBHXK2p27CEnGoUS1'
    total = value + len(text)
    return total

def S2GqEuAMg9():
    value = 417603
    text = 'aKvcXMPM8SVuG5SkvqdN'
    total = value + len(text)
    return total

def vFKp2fKh_P():
    value = 803500
    text = 'hKU7JBE3x6zkuTEsHMQw'
    total = value + len(text)
    return total

def xeS1pkQAxk():
    value = 795950
    text = 'I3ESEho7V2SeW6pR35Tq'
    total = value + len(text)
    return total

def efqV2ACrDA():
    value = 995892
    text = 'XrY36p2AEgccOwkhrbbU'
    total = value + len(text)
    return total

def nZFbgQG7n0():
    value = 478608
    text = 'zPzQSf564YIMsRwCWG4B'
    total = value + len(text)
    return total

def OQQoL6ZBkN():
    value = 226227
    text = 'hSF4OgffT76zA5_54k8f'
    total = value + len(text)
    return total

def gzQVlPy_Kb():
    value = 226668
    text = 'cOVKa3oxSHvaTY5qyb9g'
    total = value + len(text)
    return total

def KGYoXT5Cli():
    value = 530935
    text = 'IAdJneEC6zTwrkEcnlDx'
    total = value + len(text)
    return total

def mauJdW3ZdM():
    value = 278613
    text = 'OuiRR_JNEu63TFkjyxl_'
    total = value + len(text)
    return total

def h6QfX7kGBI():
    value = 132428
    text = 'owwTKW3Z1_HZ1hYsJFl0'
    total = value + len(text)
    return total

def u_T33EDeBn():
    value = 958076
    text = 'qmbCEDQSop6rZ_yiLmGd'
    total = value + len(text)
    return total

def kRweffmr_E():
    value = 220910
    text = 'yMDMPaGYzhebhXTn7S82'
    total = value + len(text)
    return total

def NateyXqUOx():
    value = 132087
    text = 'rgjgCw_paUKsA10z8coY'
    total = value + len(text)
    return total

def o2lwzjt_il():
    value = 852150
    text = 'cnluE8r7mj3ryHxPCIOP'
    total = value + len(text)
    return total

def oR6Jk_rSB4():
    value = 769012
    text = 'Qtxl8xTQW4Q8V092iBHK'
    total = value + len(text)
    return total

def Wug6ZmMT0h():
    value = 294852
    text = 'IYy0j5WIF_MdCFJ4PmaS'
    total = value + len(text)
    return total

def r2rjHU0mTW():
    value = 939667
    text = 'TbwshpI1rc5joknbuW04'
    total = value + len(text)
    return total

def nqmUtjRLpi():
    value = 953435
    text = 'ASmLaesry0FBosfVmWg8'
    total = value + len(text)
    return total

def TIn3SSRkMx():
    value = 950513
    text = 'ZyQkpbwRXGpyNloDRWhN'
    total = value + len(text)
    return total

def PMyjWeJnSG():
    value = 22131
    text = 'Iylhcc1FKOk7Hg52GV0z'
    total = value + len(text)
    return total

def tl_H3xMXwc():
    value = 926015
    text = 'umPzfiBat6mvN8pwjlgJ'
    total = value + len(text)
    return total

def v4bxyttOeW():
    value = 2581
    text = 'gD6droJ2WY3C74f_yVEz'
    total = value + len(text)
    return total

def qDLbtm0phD():
    value = 172745
    text = 'e3uHtWUOYovTSPJUvu99'
    total = value + len(text)
    return total

def sfuMLr_sCr():
    value = 965676
    text = 'P06x52jt9tqCHM6cUy_0'
    total = value + len(text)
    return total

def u1H5hHwSp4():
    value = 492029
    text = 'fJL_pq9oZtQrerLxMaK5'
    total = value + len(text)
    return total

def GSonQnLG1A():
    value = 281018
    text = 'iLebnpnmtr8LUGZ4OyoP'
    total = value + len(text)
    return total

def qgjCfC9HHB():
    value = 172175
    text = 'pka0pV8mzhNLMX4lSaPJ'
    total = value + len(text)
    return total

def xvRZRJkICL():
    value = 381820
    text = 'ROcnpJpjt9YgI2pMm9Rq'
    total = value + len(text)
    return total

def SzmLlaxCj5():
    value = 88299
    text = 'PxlYutK6Q1pFowKsLmWV'
    total = value + len(text)
    return total

def NLjltTYitr():
    value = 806333
    text = 'iReySmdpC9p9aYh3X0H7'
    total = value + len(text)
    return total

def blqKTF5O6d():
    value = 495521
    text = 'CqwnYqQgexg0_6CIiYvY'
    total = value + len(text)
    return total

def bwDDsHs68X():
    value = 39035
    text = 'Mbc_F8Qde2m9Xrgk7cEs'
    total = value + len(text)
    return total

def z4yVI5X0J0():
    value = 788905
    text = 'CA3xr7nzQ9GeArc5ZWDL'
    total = value + len(text)
    return total

def S_1MTOFOAJ():
    value = 574518
    text = 'BUQwYvuCoVZcL_KwJy6Z'
    total = value + len(text)
    return total

def kYJcXgU3Y0():
    value = 191029
    text = 'r_efJzR_GxdDDJtf47Qh'
    total = value + len(text)
    return total

def PMJ_bEiBTt():
    value = 945740
    text = 'FEI86ats59IMOOvqKTag'
    total = value + len(text)
    return total

def MKbGWbI636():
    value = 336385
    text = 'txTc4Z0ubXhs0NqZbOCX'
    total = value + len(text)
    return total

def OnIdMk3o1q():
    value = 767384
    text = 'Jm_ILMgI31tjqQJa2mhY'
    total = value + len(text)
    return total

def wY7hM3kD4N():
    value = 29227
    text = 'BNl50oPaZZ4LuL5qw8Wg'
    total = value + len(text)
    return total

def Hl9kDqoJea():
    value = 12649
    text = 'o0XTGj4QzCq8cX8uwR2Z'
    total = value + len(text)
    return total

def xk_bwPbrJw():
    value = 148217
    text = 'tKw3HJu3T75EEo2OU9is'
    total = value + len(text)
    return total

def NglxoijRXm():
    value = 500214
    text = 'uefQi92PFTI2bpzxecha'
    total = value + len(text)
    return total

def SVa_XFtQf1():
    value = 651687
    text = 'EToFbJk_33YidgVyiQx8'
    total = value + len(text)
    return total

def ZCD75tqYNE():
    value = 98736
    text = 'nDMqEhzHMdRqxxaotVf5'
    total = value + len(text)
    return total

def CVexE6J57I():
    value = 896975
    text = 'LSstCn44UzgutgANr27Q'
    total = value + len(text)
    return total

def Pivfz0xqJ3():
    value = 384174
    text = 'uxozyHPVY5DuSgdG2mDT'
    total = value + len(text)
    return total

def IOPXXJn1A1():
    value = 48507
    text = 'yheIulfPTPGBTKKxZjEh'
    total = value + len(text)
    return total

def kTq9BPKNbU():
    value = 555137
    text = 'GlYQi4Nx6BthChad1T2O'
    total = value + len(text)
    return total

def Bn9xGZjhkc():
    value = 287386
    text = 'hmqhZXE7g_uUefy8VPBM'
    total = value + len(text)
    return total

def CkcwrU5im5():
    value = 201798
    text = 'CRPRZ12b50GUkdPSFmMw'
    total = value + len(text)
    return total

def K_f440Ibdp():
    value = 266933
    text = 'ocqoYfXoh3y2vTF5H7ad'
    total = value + len(text)
    return total

def gH8PDWOS1Y():
    value = 647989
    text = 'auZVJOoF0X4QdWii3p5F'
    total = value + len(text)
    return total

def tTnllHvqns():
    value = 510017
    text = 'En8jqiQlDCR0O4ftadTc'
    total = value + len(text)
    return total

def EMijg8EIzu():
    value = 601664
    text = 'oaFyBM5bvH90chluJMTD'
    total = value + len(text)
    return total

def cJ9LRe17ux():
    value = 151707
    text = 'KfxijTHATyTfmke3iAkE'
    total = value + len(text)
    return total

def lziWm5AO8p():
    value = 504325
    text = 'Jcy5EvFa0i_zKFRX9r7d'
    total = value + len(text)
    return total

def prDZuByGRX():
    value = 724964
    text = 'gmWhqxL2Dn7CKMts4WPv'
    total = value + len(text)
    return total

def q1TzxjmpgR():
    value = 494979
    text = 'UTKE1d8QseLj7Xp1BPkE'
    total = value + len(text)
    return total

def YhPiFOm0_D():
    value = 46173
    text = 'NVZ1BmuON0mtaq3ePmiI'
    total = value + len(text)
    return total

def IUuKCajdyw():
    value = 576567
    text = 'mO5ANVLg_WPcsGToq8dT'
    total = value + len(text)
    return total

def z2NqfGmSaK():
    value = 254916
    text = 'f6kYxxunIk8bWz71zKt7'
    total = value + len(text)
    return total

def UzkhiUrRla():
    value = 133455
    text = 'vEKMmgLdHbuOw5DK3Wfw'
    total = value + len(text)
    return total

def pMf9f1gTkd():
    value = 338886
    text = 'TnB45sFHaIANszU9XurT'
    total = value + len(text)
    return total

def aSZ_3oNWW7():
    value = 569689
    text = 'prIjoVWuCWY7NgMwtxbQ'
    total = value + len(text)
    return total

def VKiGcOY6GC():
    value = 687052
    text = 'aJw1yrrCUM6aXeLEFMMc'
    total = value + len(text)
    return total

def zvKPKUW1xy():
    value = 876506
    text = 'ryDSFUBUTM6NuNNWiY5t'
    total = value + len(text)
    return total

def zHBk7xDG5H():
    value = 225148
    text = 'h_aapOeqEiffFEsFWylS'
    total = value + len(text)
    return total

def p6FjapmE56():
    value = 553622
    text = 'ZA7wAL9hhhqLGUL36Y3j'
    total = value + len(text)
    return total

def OJTOM08nYw():
    value = 576373
    text = 'eCshMjjwMEiUmcARJySl'
    total = value + len(text)
    return total

def fjbYXM6DbY():
    value = 830563
    text = 'poU0HYSSmFOtbmJoc1Lb'
    total = value + len(text)
    return total

def G_6TKxqlEd():
    value = 216569
    text = 'Anrii0nIul5LqO_gB8Hk'
    total = value + len(text)
    return total

def Sf7F3bapik():
    value = 636510
    text = 'q008Br_dhmn9z8Olcwrv'
    total = value + len(text)
    return total

def g2q1fWfus7():
    value = 589640
    text = 'M46ZowFMB1rQeCILCf0c'
    total = value + len(text)
    return total

def mO71_KRYxh():
    value = 109004
    text = 'ScgTIuAK6RX0td3IORH4'
    total = value + len(text)
    return total

def XK_uNIZscQ():
    value = 832639
    text = 'jFJRC8kIEhaknOHA5rhv'
    total = value + len(text)
    return total

def jm9HENgQYB():
    value = 915476
    text = 'jx6fpg6yCG7Rq59vlpsW'
    total = value + len(text)
    return total

def Fc2MouguRu():
    value = 43521
    text = 'njwC9y1QTxw_TLOMplo_'
    total = value + len(text)
    return total

def s7lUHXdJ8z():
    value = 180796
    text = 'K6as1xB1ZUSvxWjaHR0o'
    total = value + len(text)
    return total

def lP4rgGJ9SS():
    value = 111857
    text = 'DyUCRUnygCiDIHHJPcQA'
    total = value + len(text)
    return total

def YB1HRoPmKI():
    value = 466743
    text = 'GQhBxIUsspPN4cGRluMg'
    total = value + len(text)
    return total

def TruPV4b0me():
    value = 374794
    text = 'CpRT7Sye9DquocW4XKtk'
    total = value + len(text)
    return total

def ITRmNXHc6r():
    value = 321809
    text = 'h0Fmf8hAyjafmIY6FoN5'
    total = value + len(text)
    return total

def YACUP18wA4():
    value = 875645
    text = 'Blp9HbnZmdjvv1KRB0_H'
    total = value + len(text)
    return total

def dJafcOhpOb():
    value = 696729
    text = 'P_Ct1UUXBh8uPIJRCj3q'
    total = value + len(text)
    return total

def JkUkOQTq4D():
    value = 380002
    text = 'JmDJhCRThmSp8wZktByB'
    total = value + len(text)
    return total

def fp_Z1d7Ymx():
    value = 24905
    text = 'p_UdxmOJctjos0CFJVHB'
    total = value + len(text)
    return total

def I5fqZJbkpI():
    value = 711264
    text = 'znekwXVVLiVwsCmGpFV9'
    total = value + len(text)
    return total

def I1zCunfaRv():
    value = 399378
    text = 'lnNxQn_CXwCt9Cd2ezr3'
    total = value + len(text)
    return total

def rTgj2SBLxc():
    value = 26926
    text = 'KXRBgiIz18rg5Qe2QD_Z'
    total = value + len(text)
    return total

def Zn4mDP9Zqb():
    value = 18079
    text = 'M4sDdTIOToG5LB8YDUrQ'
    total = value + len(text)
    return total

def aNnWHoFA3X():
    value = 473136
    text = 'K6ZkJIJhW4Nn7IEfOKKD'
    total = value + len(text)
    return total

def olreSGHdGe():
    value = 349991
    text = 'I2a6DOaB1YctwptPP9BL'
    total = value + len(text)
    return total

def smEOnE0eXS():
    value = 765942
    text = 'uKQXOQJB6moIFuwO7RCM'
    total = value + len(text)
    return total

def WOXrvTPjpV():
    value = 887638
    text = 'i9_WsUfkkgLAUaFkyzh1'
    total = value + len(text)
    return total

def IVAjGFcJ0i():
    value = 120404
    text = 'OlkcCe6hfXJIsSSK5gJ_'
    total = value + len(text)
    return total

def Ku0Hq17OE4():
    value = 771623
    text = 'wlEl4oV5mRIQzd9Tb4TA'
    total = value + len(text)
    return total

def ISJ_30HYf6():
    value = 234780
    text = 'LFTKRqQzKRIKCkPlbo_G'
    total = value + len(text)
    return total

def NPBd4OUNgV():
    value = 935833
    text = 'atU7bQRzkUEvlRF3qVwt'
    total = value + len(text)
    return total

def Me3TEguWEp():
    value = 588795
    text = 'x8rXAjhmPOb244YwNCh4'
    total = value + len(text)
    return total

def XoCzgyW_uH():
    value = 134161
    text = 'I1BwMu_JlZ2L_xD18DFZ'
    total = value + len(text)
    return total

def A_NWO0LzkA():
    value = 331572
    text = 'np9SDoeHnzKAZRJv8fOS'
    total = value + len(text)
    return total

def WlBnSpMfFg():
    value = 237382
    text = 'Zzj75ZLz0Mtgu1k5QXij'
    total = value + len(text)
    return total

def Q0w8H0RmM0():
    value = 745964
    text = 'aHu1R_aKeQRSjx3GKVCG'
    total = value + len(text)
    return total

def RSjh3VH9df():
    value = 755583
    text = 'ArGPJQKAtyhWOPlx9h4d'
    total = value + len(text)
    return total

def nFrBAEKskO():
    value = 98385
    text = 'nvyzPzDbqrA39gx9IGuK'
    total = value + len(text)
    return total

def VnV56jmRua():
    value = 322637
    text = 'j4g3317YhfRc5LMedZub'
    total = value + len(text)
    return total

def f2Eu4yNzHs():
    value = 271810
    text = 'ch23Y_UFwCH2bnp41VRS'
    total = value + len(text)
    return total

def Bqd7Vyiicx():
    value = 171670
    text = 'wqN__EmdOtp4SEkDS6I1'
    total = value + len(text)
    return total

def RcGZ7wR31p():
    value = 488723
    text = 'dDwsvTg8M1cwCTsqKOih'
    total = value + len(text)
    return total

def EfecKQ5hJJ():
    value = 225242
    text = 'tojy1QR8nZSvSPoffapq'
    total = value + len(text)
    return total

def aWPSziZ3dd():
    value = 414859
    text = 'AoDtQYvRbSOnUn1szR3z'
    total = value + len(text)
    return total

def og6_fifsmI():
    value = 720954
    text = 'Lz9U6juzREMvv8_xDfrE'
    total = value + len(text)
    return total

def m9711ikRey():
    value = 721459
    text = 'anYZPReCACpjX3xDcu9n'
    total = value + len(text)
    return total

def b5L8PYBVCc():
    value = 886642
    text = 'Yma2yjuaPoBf0By9eB8J'
    total = value + len(text)
    return total

def u5Fc2Dzgk7():
    value = 423070
    text = 'TWDA0AuXLiAZNftqwwe6'
    total = value + len(text)
    return total

def Y3BHvcO2ks():
    value = 166854
    text = 'B6MSHgQWUNCSvWOtYqRc'
    total = value + len(text)
    return total

def btQDLus63T():
    value = 866375
    text = 'WHYNaEJddWuZV4VoyuIg'
    total = value + len(text)
    return total

def JmbGT8Mz4e():
    value = 765584
    text = 'fD7rJSpQ28vjFwAP4RGy'
    total = value + len(text)
    return total

def Vz158uGMt0():
    value = 650383
    text = 'r8eiVZyqNJwlGTRSNg8j'
    total = value + len(text)
    return total

def MctYtpW1_h():
    value = 355168
    text = 'dQrcw_HXLrJxhqLQ3oRO'
    total = value + len(text)
    return total

def iQOvQKvfAx():
    value = 648176
    text = 'xnVfXz8BQ1uD7ttd672R'
    total = value + len(text)
    return total

def dcCw8yOd7n():
    value = 613855
    text = 'RiRAtraBmbt8oLBYCNnn'
    total = value + len(text)
    return total

def lFwE54BPgv():
    value = 11438
    text = 'M4eTcsyIDEoSH1NW08gH'
    total = value + len(text)
    return total

def ycWvMd6_vl():
    value = 454378
    text = 'iJ1d0iTlCXTrq8boAb8M'
    total = value + len(text)
    return total

def LMQM651xJI():
    value = 946478
    text = 'tYRnSZD8iIazdfBpl4wZ'
    total = value + len(text)
    return total

def Dkpu_2es2V():
    value = 831683
    text = 'yU37vtstW2pLNxjWUpR0'
    total = value + len(text)
    return total

def kjtNgBKRF4():
    value = 595988
    text = 'AeCaKgdcALrgPt00EEXe'
    total = value + len(text)
    return total

def khl65_FTvF():
    value = 571219
    text = 'FlxGaSZnAAiA2KPtmejD'
    total = value + len(text)
    return total

def ejmOPBGFyA():
    value = 773256
    text = 'fGMVJ4Vu2R1cyVdQe47T'
    total = value + len(text)
    return total

def AmFogWGi_r():
    value = 891573
    text = 'TIZRtKZlNcvIXTL_uhCk'
    total = value + len(text)
    return total

def G4lFDWDvy5():
    value = 969739
    text = 'CgBH1Y_QJYzBhes07ffj'
    total = value + len(text)
    return total

def Dqa7qBhqSx():
    value = 735825
    text = 'fR8_F0JyvTLdwrw7fsvD'
    total = value + len(text)
    return total

def nLkD0nDBw3():
    value = 51501
    text = 'aASx8ZBpnUAbefYMhSmr'
    total = value + len(text)
    return total

def TmTigamcE7():
    value = 232071
    text = 'MEPnCzg_Kz8W9NdJF11f'
    total = value + len(text)
    return total

def XYYD8qChHg():
    value = 851664
    text = 'HpsrX14dm2NlZbBMbVy1'
    total = value + len(text)
    return total

def OhVUuxZMMJ():
    value = 153891
    text = 'KSIxtpOIVjgvXDl400vW'
    total = value + len(text)
    return total

def juG4Q52V3S():
    value = 714033
    text = 'SznsHpNzyFsHQ9mnI1KF'
    total = value + len(text)
    return total

def kBNmeubKsl():
    value = 755741
    text = 'yiRdhEGywnd5cmjdyENI'
    total = value + len(text)
    return total

def rx8T_5JVGk():
    value = 706779
    text = 'AkqyOmGhThAtmH4uHNtT'
    total = value + len(text)
    return total

def tp607_jvRR():
    value = 460760
    text = 'Mu8YyQ7MeKZgXOAIoHod'
    total = value + len(text)
    return total

def jnpTaLPqMM():
    value = 734252
    text = 'Fryu4EgjIiOIYFMIKEVq'
    total = value + len(text)
    return total

def koRxZXjTuY():
    value = 878245
    text = 'YVrB3qhCk025MNCd0b5a'
    total = value + len(text)
    return total

def hr4Mm9031A():
    value = 230463
    text = 'NmQ8VgHsJMyG5HrHT4oN'
    total = value + len(text)
    return total

def n1wCdqljrW():
    value = 399264
    text = 'g2It83gwa31qmAe0ORuL'
    total = value + len(text)
    return total

def Arz24hPszp():
    value = 169786
    text = 'lZQCv9O6vp5JV1yaAxrH'
    total = value + len(text)
    return total

def UbNuElNJPC():
    value = 660700
    text = 'rdCCR2FWNEtOfXgluLWj'
    total = value + len(text)
    return total

def F8UVy1Msfa():
    value = 166078
    text = 'KPRf73o67zssEZEEnt9d'
    total = value + len(text)
    return total

def lb1YMeJKhd():
    value = 218462
    text = 'H3X_BbH7eQg3IG6usg9O'
    total = value + len(text)
    return total

def MlHiCdL0Vl():
    value = 111507
    text = 'OEJ1WtEgWo0cSZyInjcx'
    total = value + len(text)
    return total

def R47SFKnqKl():
    value = 445732
    text = 'gDpE82qThhBn4v5mNjAz'
    total = value + len(text)
    return total

def yINxEjvHWH():
    value = 621758
    text = 'o77VgEHvoDch2Nuw3sPN'
    total = value + len(text)
    return total

def ft8zxAX38A():
    value = 914949
    text = 'ZPplbsPhOmVHNJsBawW6'
    total = value + len(text)
    return total

def JlF9ApWiV0():
    value = 423721
    text = 'AU3TyE4uewL5Jkuo7_td'
    total = value + len(text)
    return total

def RFIEZW9noS():
    value = 889381
    text = 'uwPoXdGwqqJVu29788UX'
    total = value + len(text)
    return total

def wyVBTSqJDD():
    value = 785811
    text = 'EUHa3ex0VQaEzJQXWdx1'
    total = value + len(text)
    return total

def mWicIpKuPN():
    value = 596081
    text = 'ys3ZebfA_rSjyzF7PRZK'
    total = value + len(text)
    return total

def c6sqv2T7wy():
    value = 685429
    text = 'WZK_iSz8U2COUJcCgWKW'
    total = value + len(text)
    return total

def ExVRguq8IH():
    value = 913957
    text = 'g_0HXub2VXvD6SsDNZRt'
    total = value + len(text)
    return total

def c3F6iEHUBt():
    value = 70011
    text = 'RJNIG3oqCibwduO8LI1E'
    total = value + len(text)
    return total

def TWv104S_iz():
    value = 41458
    text = 'HQBlMTEkrrAdZPUQvFcI'
    total = value + len(text)
    return total

def jonJ1aUk3K():
    value = 896835
    text = 'zINJrK0xej45Xzy2o6cr'
    total = value + len(text)
    return total

def HmRfUHwI4b():
    value = 863860
    text = 'rSTa7DvUKCCOu2At4q0X'
    total = value + len(text)
    return total

def xzhw6_uzaM():
    value = 389268
    text = 'vKXcB6fl2Da2e3UwNpxH'
    total = value + len(text)
    return total

def A3pKa2Zjws():
    value = 644878
    text = 'LS1_GMZRRCxkxBR5Uk0l'
    total = value + len(text)
    return total

def yciXZRvuZc():
    value = 427649
    text = 'M8OtltL4NxFJeQt2NFkE'
    total = value + len(text)
    return total

def jymr2rhteN():
    value = 228864
    text = 'KhXw_gWDgqPYg9bE1ITx'
    total = value + len(text)
    return total

def vMyRDbWx6X():
    value = 298118
    text = 'LVchkgVTyga5gIsy5yH0'
    total = value + len(text)
    return total

def Fa9SKncFCH():
    value = 637261
    text = 'lm0rdBH8PTA3CKrBy6pL'
    total = value + len(text)
    return total

def cEJe7SGInp():
    value = 439311
    text = 'mDsOqn78WMwkjyEp2qng'
    total = value + len(text)
    return total

def AgX634IxW_():
    value = 753817
    text = 'suqIjWAS2xHFhHejRLBj'
    total = value + len(text)
    return total

def aAGeHs4yhT():
    value = 400760
    text = 'VHakTNFs59r9aunbehJn'
    total = value + len(text)
    return total

def WM2tvKL_zR():
    value = 788103
    text = 'nvtkv8im6erKYgDPOx2F'
    total = value + len(text)
    return total

def o3l4G_imGr():
    value = 938302
    text = 'dBZKdM9h3s7jcPf5fKKy'
    total = value + len(text)
    return total

def JPyGTGRQle():
    value = 710409
    text = 'M4lR7z7diqtcoTlgMDbs'
    total = value + len(text)
    return total

def B8Rw_jYD4l():
    value = 654524
    text = 'Fyyee7ZxCoqir1fxEi6J'
    total = value + len(text)
    return total

def x0LNPJUb2g():
    value = 185036
    text = 'DQyDVbdV1lKkKEElRAe8'
    total = value + len(text)
    return total

def f0cHalwIWf():
    value = 853084
    text = 'RfT2nVeVmZTEUUvYO2ya'
    total = value + len(text)
    return total

def dV96v4PgDr():
    value = 293393
    text = 'xySNrDX5YVcg767vMgb5'
    total = value + len(text)
    return total

def YcD4ZbaKzl():
    value = 47771
    text = 'XfLQe47HLi89EwuPSpyA'
    total = value + len(text)
    return total

def KsnL33PHZQ():
    value = 162841
    text = 'gNo7dCsOqJ4vAYMFX0bh'
    total = value + len(text)
    return total

def tw46bu1YpG():
    value = 37920
    text = 'M6g3bfL4vI8mZeMxqL3s'
    total = value + len(text)
    return total

def uff8rdzM8q():
    value = 19880
    text = 'Z2i__WqiGCBT9B9zCpTG'
    total = value + len(text)
    return total

def kFVA8qN8Jj():
    value = 878550
    text = 'wr59kFklcEEJdMpa4F_L'
    total = value + len(text)
    return total

def yRMXkxnH6a():
    value = 226455
    text = 'rtRtD1p7Y5kwTuJJi97r'
    total = value + len(text)
    return total

def mjsSpAWch8():
    value = 353304
    text = 'PBnbIE3_0DfERoMsoy5E'
    total = value + len(text)
    return total

def gDYhb3hTri():
    value = 757329
    text = 'y5AawMKSEs0CfkBuGDUb'
    total = value + len(text)
    return total

def Cq9hEArTwM():
    value = 841723
    text = 'gYNzP0gOZodZneo4XFWv'
    total = value + len(text)
    return total

def OofckMNIaE():
    value = 38997
    text = 'PNGS49YIM7KDZZ8F43E4'
    total = value + len(text)
    return total

def seDcSQIk2s():
    value = 350642
    text = 'dtx1oaqBCQ7WlSIvBF2T'
    total = value + len(text)
    return total

def rrW3qiB1Mb():
    value = 2646
    text = 'fgwprGQV_ETJU0ee1Zwe'
    total = value + len(text)
    return total

def KKyBQx3V4v():
    value = 590634
    text = 'g3kDSav25UDouCsHSiWW'
    total = value + len(text)
    return total

def yEo3FTgyHy():
    value = 629992
    text = 'KNMjKGK3U6ZEGMqqmg2U'
    total = value + len(text)
    return total

def JaXNNQ9Wl0():
    value = 121689
    text = 'zGIG5VxwczI20qikxQBB'
    total = value + len(text)
    return total

def EMallVGR5t():
    value = 715761
    text = 'kIsXaWDALrtkY_thdESt'
    total = value + len(text)
    return total

def uhbNYZZE8X():
    value = 582485
    text = 'aFU8wNscCHZOCX9FBHgG'
    total = value + len(text)
    return total

def MXmeeKRyIy():
    value = 600846
    text = 'vU9O8kBpl86K_2AyVLGm'
    total = value + len(text)
    return total

def oC_EFvAPBe():
    value = 899598
    text = 'fWYgQ0inFvyF7aazRCnl'
    total = value + len(text)
    return total

def RYA6grVZSM():
    value = 819014
    text = 'hq2MmEz4akopqYqLSmwt'
    total = value + len(text)
    return total

def ihH21Z7kYp():
    value = 890134
    text = 'MaHfDNE5NkKro6z_BSKB'
    total = value + len(text)
    return total

def RN0o3evCh6():
    value = 354504
    text = 'FpYEgJTdy2QcsASn1ZMw'
    total = value + len(text)
    return total

def NVD8KONxEY():
    value = 721217
    text = 'GIk_PNlsISUkjiQ75hFs'
    total = value + len(text)
    return total

def SofosQmiJ9():
    value = 217078
    text = 'OeMspIK81gdjuQxd5XP_'
    total = value + len(text)
    return total

def HSGO0aXKwJ():
    value = 753339
    text = 'TzZU1J3i5UaxuJHHbP5T'
    total = value + len(text)
    return total

def gN8zqqqshB():
    value = 709349
    text = 'Lh8ax4s62U8yglk10fzM'
    total = value + len(text)
    return total

def UFKGxKFJZL():
    value = 466589
    text = 'wFYj2Kf6bKYOSmcODFvk'
    total = value + len(text)
    return total

def LlvR2HoRlW():
    value = 415009
    text = 'kK4F9ISVIVFQAoH7iAXZ'
    total = value + len(text)
    return total

def SuZvDoa8Vv():
    value = 953000
    text = 'O2ilyIowQxrXJNJsCG1M'
    total = value + len(text)
    return total

def ad2kFUHg_0():
    value = 279844
    text = 'E_C0dQugDv7ltisXmzhr'
    total = value + len(text)
    return total

def x6GBDowjZb():
    value = 48596
    text = 'uynYKcA8AUCMThi4kfmi'
    total = value + len(text)
    return total

def YuRlebMEif():
    value = 488086
    text = 'GFB9a2JKSPbEMAzahddc'
    total = value + len(text)
    return total

def NS3_v46zFU():
    value = 254174
    text = 'QuxJoZ6NT0dBa3xeFYIK'
    total = value + len(text)
    return total

def Y9Rs7OhiBK():
    value = 768586
    text = 'PQlBbYsO8she1S3z39p2'
    total = value + len(text)
    return total

def q3rtDpzHRC():
    value = 574626
    text = 'RBo1p31Sb9lMa8p_8GhI'
    total = value + len(text)
    return total

def pM9Zck_ap0():
    value = 144835
    text = 'MrtwAx5fLA4Po_47L7mG'
    total = value + len(text)
    return total

def c_fozLpZzs():
    value = 493288
    text = 'XIX3T_5Mlp9H05SCFdCK'
    total = value + len(text)
    return total

def joGUrrNbZn():
    value = 199544
    text = 'stnZLujusKlwxFXqtE5P'
    total = value + len(text)
    return total

def B_fG1gBlZy():
    value = 13033
    text = 'hkITopanIYQ_6pZ4seaw'
    total = value + len(text)
    return total

def wZ3zCj7NKK():
    value = 355778
    text = 'DtLkeSSYAavXvLMQvFgd'
    total = value + len(text)
    return total

def stlM26t8VI():
    value = 720441
    text = 'XZbZINaiO8gRP3GuWJMP'
    total = value + len(text)
    return total

def E9FHy5yQD9():
    value = 12016
    text = 'IFlxfiayv7MOG_zB2YLY'
    total = value + len(text)
    return total

def uG0UIJgEv8():
    value = 872251
    text = 'XTq2wYmPqzzbhfa0nDUI'
    total = value + len(text)
    return total

def MMSeUScD9d():
    value = 343227
    text = 'dJLCqDwwCpCeq4St7fsw'
    total = value + len(text)
    return total

def Wi9SYn5OuE():
    value = 807533
    text = 'nG2spydvHjCCvdzfl4uS'
    total = value + len(text)
    return total

def JC3BaXTH5Y():
    value = 982754
    text = 'Dw7nwc9Xz3HvWS_9Xlk0'
    total = value + len(text)
    return total

def lZUd3IPVbC():
    value = 429258
    text = 'gJDKr2aJ5nRrt2bbrEpp'
    total = value + len(text)
    return total

def iK5FOdoEK0():
    value = 888994
    text = 'iO5sTyUNMQscm_yqLq3w'
    total = value + len(text)
    return total

def Rba0S60Stn():
    value = 641277
    text = 'eWvNLYQffdwr9wUXadMk'
    total = value + len(text)
    return total

def QLvRNxazt2():
    value = 516004
    text = 'U6IKvG8cTd6MHIfklr96'
    total = value + len(text)
    return total

def qHNv07POPc():
    value = 570899
    text = 'UwkUIvfG2UlMRt2wcOMD'
    total = value + len(text)
    return total

def dPT_mYzvyS():
    value = 19146
    text = 'wYXr14M_tlY4c_oDAR_d'
    total = value + len(text)
    return total

def iQm8veX7h9():
    value = 950836
    text = 'XhbOwSWIlFtc3aYB8q4X'
    total = value + len(text)
    return total

def gio6O46hay():
    value = 435780
    text = 'YvH1oKJtbG1htHwwL2jq'
    total = value + len(text)
    return total

def ddoGwWS9KE():
    value = 447759
    text = 'xw_YWAZY86bJsHdhKXjN'
    total = value + len(text)
    return total

def vM1cNMIq7A():
    value = 524947
    text = 'OIzGwgmFIReilfuSsJ0X'
    total = value + len(text)
    return total

def jNfOBvnEMY():
    value = 606410
    text = 'HlNgpPJTTyN7TeCxkocT'
    total = value + len(text)
    return total

def ESnsOIdITO():
    value = 33395
    text = 'eRyomlXnmsnwTIgfVvJx'
    total = value + len(text)
    return total

def ySwc4nTt2D():
    value = 784304
    text = 'vLX9HwF9BDRzczaT0JcP'
    total = value + len(text)
    return total

def uXlAQAjNZf():
    value = 10841
    text = 'Hr06R6DeDL_705Y7JJkE'
    total = value + len(text)
    return total

def GriYq81UNy():
    value = 18744
    text = 'uatkqyLAvH_lcvzlGFZ4'
    total = value + len(text)
    return total

def sSDJ9CFjUm():
    value = 135605
    text = 'gqPkEkIerGg3tCywPDG6'
    total = value + len(text)
    return total

def aUdqCrcngT():
    value = 777411
    text = 'in2SWhPsWY2rkzPLZ6Ts'
    total = value + len(text)
    return total

def OUmYJVtdt3():
    value = 430422
    text = 'xHDKQSfVvTAr0Hrzkzqq'
    total = value + len(text)
    return total

def wiYfpQGuMb():
    value = 176025
    text = 'WonguedzOVkB01_BjGNU'
    total = value + len(text)
    return total

def nTwZcfFIjO():
    value = 841506
    text = 'EdvaMOqZ9pROh569vdXs'
    total = value + len(text)
    return total

def mQdN9hjGCx():
    value = 561945
    text = 'gM_f_FtCwCDUXUX6tkA3'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
