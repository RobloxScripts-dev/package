import os
import subprocess

DIRS = ["assets", "utils"]


def main():
    passed = 0
    failed = 0
    total = 0

    print("[loader] Starting...")

    for directory in DIRS:
        if not os.path.isdir(directory):
            print(f"[loader] Skipping '{directory}' — directory not found")
            continue

        files = sorted(
            f for f in os.listdir(directory) if f.endswith(".py")
        )

        for filename in files:
            path = os.path.join(directory, filename)
            total += 1

            result = subprocess.run(
                ["python3", path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

            if result.returncode == 0:
                passed += 1
            else:
                failed += 1
                print(f"[loader] FAIL: {path}")

    print(f"[loader] Done. {passed}/{total} passed, {failed} failed.")


if __name__ == "__main__":
    main()

