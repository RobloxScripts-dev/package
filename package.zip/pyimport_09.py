import os
import sys
import time
import random
import string

def Gor_14ocMy():
    value = 322783
    text = 'uYlPzpdirgQOUCrARzJN'
    total = value + len(text)
    return total

def v4ZmbkWaRQ():
    value = 847522
    text = 'tRQNWIrqmSKZDxreZBfR'
    total = value + len(text)
    return total

def LxdTRq6sFD():
    value = 255853
    text = 'xHFGndU9c9IeWZEmkfC4'
    total = value + len(text)
    return total

def kX7aiEiTnm():
    value = 887196
    text = 'GPbOZyYQjhWJWBpinhhr'
    total = value + len(text)
    return total

def qqlEzqJyAx():
    value = 53205
    text = 'O8ykgsyQMCeaX6ZD54yn'
    total = value + len(text)
    return total

def RBPK8D4hVr():
    value = 714068
    text = 'zihsO1SuUDwN_9oCkxf7'
    total = value + len(text)
    return total

def J8WC8U29j7():
    value = 827706
    text = 'CWij7tJxRrlzKcwtbGr5'
    total = value + len(text)
    return total

def mgGTgLdUwO():
    value = 554476
    text = 'lNPB_C71scWymEn6nk5w'
    total = value + len(text)
    return total

def vkqYrcD0tG():
    value = 357179
    text = 'OriwUBjFZ0c0dfpouA35'
    total = value + len(text)
    return total

def XtP7IbIfCz():
    value = 90447
    text = 'y5g6Tcs1ChJ4YL1guR0u'
    total = value + len(text)
    return total

def Kc1sa_sGwm():
    value = 659680
    text = 'rpQ_moDVRefvuJ9KSeX3'
    total = value + len(text)
    return total

def UPXmchY6NT():
    value = 89199
    text = 'Y1bxQEL3abOmZQ8J3WYI'
    total = value + len(text)
    return total

def xWxc7J5ZLe():
    value = 809107
    text = 'UM_UE5VwtYU7okhraRoM'
    total = value + len(text)
    return total

def NlATSxsgpn():
    value = 631655
    text = 'wCWljZ_ChIV8QlMPduZL'
    total = value + len(text)
    return total

def FpOJWzPBBu():
    value = 673069
    text = 'CTs2t6puiIG5wm3csZLy'
    total = value + len(text)
    return total

def JuuMwbgyOt():
    value = 859502
    text = 'MOVWefgvivMXHSMDrdme'
    total = value + len(text)
    return total

def rrG29N4ePu():
    value = 767871
    text = 'fJNk1t1Yf9NFAph1zpqR'
    total = value + len(text)
    return total

def Ktw6zAnGHH():
    value = 296546
    text = 'gZxyuCt1WvyXmVcwVeXk'
    total = value + len(text)
    return total

def GOs0rJrTva():
    value = 44529
    text = 'SpKBP8tyJdQJDrF5d7aM'
    total = value + len(text)
    return total

def UpEbVbGekw():
    value = 523499
    text = 'vHmJv505pDCuuSDOQbTB'
    total = value + len(text)
    return total

def JnN3Frojt1():
    value = 748381
    text = 'RhNKM2obUM9Vk9wdstHj'
    total = value + len(text)
    return total

def DMtAYguM1y():
    value = 307618
    text = 'uiOC_ZosHH6oC6gEeViW'
    total = value + len(text)
    return total

def TLSZH_0vHn():
    value = 414733
    text = 'ZOM5Qhn1NUAdSljVjseM'
    total = value + len(text)
    return total

def M97vqUKki1():
    value = 144039
    text = 'VcK7iXzTdzSjBhPF3jW8'
    total = value + len(text)
    return total

def wpSmqgEE2h():
    value = 607064
    text = 'YrmHbnw85BY3cJwFeVcm'
    total = value + len(text)
    return total

def gSI3bAtnGb():
    value = 16970
    text = 'yX7_AxOcrsO_BwSt9HoU'
    total = value + len(text)
    return total

def ip5pEpPYQ1():
    value = 513465
    text = 'AogG3xISdcYQG8vnMKb6'
    total = value + len(text)
    return total

def tM551lgAcq():
    value = 915658
    text = 'TqHmSUpF4orh3HImu4bD'
    total = value + len(text)
    return total

def p5vfTPdygy():
    value = 470706
    text = 'ty13WXo_62vgMWt9sbip'
    total = value + len(text)
    return total

def BYKk0ndc19():
    value = 896149
    text = 'iz84RSRfwjVBh__d_OCB'
    total = value + len(text)
    return total

def UVSOborRQe():
    value = 679161
    text = 'foRjhG5iyT4Q0eaqTzz2'
    total = value + len(text)
    return total

def sOWUKoO20j():
    value = 111756
    text = 'WaD2Fg5VBPIaUNON5zoj'
    total = value + len(text)
    return total

def S5LYGpIA14():
    value = 978416
    text = 'a2mMPWuEm37uG3JqPTuL'
    total = value + len(text)
    return total

def yXLM0UX1Pf():
    value = 360778
    text = 'lMZKfHe866aUDiemS6gz'
    total = value + len(text)
    return total

def uUPjgPAjJ4():
    value = 222599
    text = 'f4VCGn9D2wOSCa4oMbOa'
    total = value + len(text)
    return total

def lHGOAhGjHq():
    value = 430092
    text = 'RVVQc0fIoKzhCH4Ze5Sv'
    total = value + len(text)
    return total

def JJnlQbsCT2():
    value = 605416
    text = 'ux332bEDgJPhxKdNgcsT'
    total = value + len(text)
    return total

def SUeieXQEMZ():
    value = 107822
    text = 'u9SKvzgrAsG3iJN2o9I6'
    total = value + len(text)
    return total

def jffqTA46Tr():
    value = 713502
    text = 'UBjK086KAw_xjBCNLIGk'
    total = value + len(text)
    return total

def qs_kEBGjcJ():
    value = 495142
    text = 'F3qv3e2GbeTE8PGYfLU0'
    total = value + len(text)
    return total

def FueruIXiSA():
    value = 768689
    text = 'w17byoWZebEZ9SAjmU21'
    total = value + len(text)
    return total

def eWOk4qbMB7():
    value = 604706
    text = 'Aohqywoxajhq3KwIT9bB'
    total = value + len(text)
    return total

def FKfSmZtx4C():
    value = 153515
    text = 'm4adNyfqrT5YRT4BAlFx'
    total = value + len(text)
    return total

def z7qYWRAI35():
    value = 977061
    text = 'm9t6NhNWmH9T4v3CGQ3L'
    total = value + len(text)
    return total

def CH6CmytMeQ():
    value = 167865
    text = 'y1yjvQDyQrHX27AzFhtQ'
    total = value + len(text)
    return total

def D6FFrsw8S8():
    value = 981375
    text = 'aJtQVRzzlmZwwUa4oGhJ'
    total = value + len(text)
    return total

def j8gwGuQB2D():
    value = 106938
    text = 'v0uwlGoUnH3OW9EDtHsM'
    total = value + len(text)
    return total

def gAsq5SH3F2():
    value = 281854
    text = 'SPWfFZvEmylCvOxAdFt4'
    total = value + len(text)
    return total

def tMsIL21nZI():
    value = 560272
    text = 'x2BTbduXriIj3NIT8tmG'
    total = value + len(text)
    return total

def nXeqRhDX1N():
    value = 434796
    text = 'CLwgERit3QlTgZY7U15G'
    total = value + len(text)
    return total

def JlQpIXV1KK():
    value = 660047
    text = 'UE9EcIK26LrDQW8KPCxA'
    total = value + len(text)
    return total

def FXWbK7dyfp():
    value = 987865
    text = 'BA1j4cYaCjM8sZtQnO1M'
    total = value + len(text)
    return total

def NI0KIicwPV():
    value = 162725
    text = 'njEbsMiCOdyZRoxcMi_l'
    total = value + len(text)
    return total

def pgCz6Nwp7L():
    value = 674177
    text = 'QFbyqd2DoxJvvsnqKyKY'
    total = value + len(text)
    return total

def Pb4arwZeCm():
    value = 117762
    text = 'sbNWv17NnZy09HLupy99'
    total = value + len(text)
    return total

def fnz0bDaYwN():
    value = 849251
    text = 'YlVZ4cKOtYayosMo5Mx0'
    total = value + len(text)
    return total

def g6qBsFLPsO():
    value = 885947
    text = 'njow6mvS2IJzEEC2z0dA'
    total = value + len(text)
    return total

def S2ovH1JJG5():
    value = 458896
    text = 'j9yurLxfkALZtoW4AAFF'
    total = value + len(text)
    return total

def NhFAfI829A():
    value = 924369
    text = 'EJcToii0ecaMVvYzm9Y1'
    total = value + len(text)
    return total

def hqyF6MQ8KZ():
    value = 456666
    text = 'QEEU6xDL5uOUU9cnArQ5'
    total = value + len(text)
    return total

def d0Agf6Y3ja():
    value = 279197
    text = 'oxjKqf5_HIrT5dTDff1I'
    total = value + len(text)
    return total

def br_ZJ0bPC5():
    value = 442428
    text = 'rnmGtSUh_jUT0kGbAjua'
    total = value + len(text)
    return total

def mt5TxLe4Xt():
    value = 991495
    text = 'QP6EoOS98xIXf1htd2do'
    total = value + len(text)
    return total

def AhCoRPYSin():
    value = 2722
    text = 'I2ag8GzyFFwh_wu6sw9e'
    total = value + len(text)
    return total

def bvi0s3rGPC():
    value = 455571
    text = 'OBAhTWy_Q9pDbBYv5Kyc'
    total = value + len(text)
    return total

def Mvd5Vjb5mp():
    value = 96261
    text = 'OACX_uxsxVN6owlrtWSq'
    total = value + len(text)
    return total

def HxRbk5nDrp():
    value = 470932
    text = 'p9IyL7LhIc__0PJqbE6m'
    total = value + len(text)
    return total

def jEXbJlo1ym():
    value = 967941
    text = 'b4umxkOCrSgm0dSfXj6L'
    total = value + len(text)
    return total

def GsejTSeOBs():
    value = 681518
    text = 'wZsGQ35u2HZlcwxpJRiN'
    total = value + len(text)
    return total

def M6IIhEQlrz():
    value = 668326
    text = 'SQupq5QQpKB73mG4354X'
    total = value + len(text)
    return total

def fONWuqfRMJ():
    value = 806204
    text = 'A3XPxpgSX_mEjDSV7M3C'
    total = value + len(text)
    return total

def wBiuFhzRzN():
    value = 855900
    text = 'SxL1iWB5g3LdGGepmRlY'
    total = value + len(text)
    return total

def UcfC6V7vNj():
    value = 316765
    text = 'ZQWplk6iaM2Cxw9FM4Ll'
    total = value + len(text)
    return total

def Ot1D6LnxTI():
    value = 26158
    text = 'CJU4n9B3HRAj0cOE9Kx3'
    total = value + len(text)
    return total

def nNAxJ7v6JE():
    value = 323586
    text = 'EFUZQt8U1bNZKp6q5H9c'
    total = value + len(text)
    return total

def RWpJQpKgKk():
    value = 603773
    text = 'NGnds9D2_32KSuhJaYJY'
    total = value + len(text)
    return total

def IPlyEko_jy():
    value = 350268
    text = 'JIz4tqCZN0eZOW_lT3Ip'
    total = value + len(text)
    return total

def kPGB5GqShk():
    value = 171103
    text = 'uRKlF_NXNorn66Vzs9GA'
    total = value + len(text)
    return total

def Jlrleraf54():
    value = 33793
    text = 'BkM1GHjmQS_zdDC_NK5_'
    total = value + len(text)
    return total

def HRDZg09MBy():
    value = 617848
    text = 'ZVCQp0bwfbZi60uowbFR'
    total = value + len(text)
    return total

def S8HHJMqjbY():
    value = 158774
    text = 'bIpI13fw_sV_ZshdlJSW'
    total = value + len(text)
    return total

def lZB2OZQgzy():
    value = 299204
    text = 'lgjGHjVAIGXDWYb7dF1C'
    total = value + len(text)
    return total

def r5gEQlZuu5():
    value = 430546
    text = 'wX9qfcaSyNvoXJRCkEWY'
    total = value + len(text)
    return total

def kfJQMcv1hX():
    value = 601702
    text = 'DMbHPSSxjd6BQlhMUTnJ'
    total = value + len(text)
    return total

def rP4dJFz0Ub():
    value = 926702
    text = 'aDLhxMOsD4ZzqtWbxQke'
    total = value + len(text)
    return total

def XddCuyj1gz():
    value = 494794
    text = 'uicQTzcPT6satT0tQj0J'
    total = value + len(text)
    return total

def M32C7chUmM():
    value = 405729
    text = 'oyr9pV0C4cTnWUwY1SLN'
    total = value + len(text)
    return total

def lZTZycIpV9():
    value = 982568
    text = 'tt8ivpdT58uWTPyxU52p'
    total = value + len(text)
    return total

def oT3HanmCj4():
    value = 962890
    text = 'pnjtq_4UgfgxlG4IYEdE'
    total = value + len(text)
    return total

def hmf7NyHK6i():
    value = 286109
    text = 'AJnjrR85DmUcg4G9kOr8'
    total = value + len(text)
    return total

def ywDsJpGof2():
    value = 673460
    text = 'CMb3QgwztF1x8gaOddJa'
    total = value + len(text)
    return total

def M9TDPHDXRf():
    value = 59207
    text = 'F1WR_RipGL3Xh3Sp2xZY'
    total = value + len(text)
    return total

def tvqPOV_IN9():
    value = 123994
    text = 'Q4kvG0DYWa34JmdDT8u4'
    total = value + len(text)
    return total

def uvztPyyfCb():
    value = 622291
    text = 'FfwkxwY78WHgx5aJqsOr'
    total = value + len(text)
    return total

def i2834E3YDT():
    value = 37986
    text = 'Qlt9OgS24qP1H73jb1nc'
    total = value + len(text)
    return total

def R2B5AEtu5I():
    value = 280069
    text = 'qZ4_XxhKOnikcoC9X7NN'
    total = value + len(text)
    return total

def ZAOKk9Qcyb():
    value = 698339
    text = 'CwlOsw9gChMkHGVCMAk5'
    total = value + len(text)
    return total

def D8qQMTgcoF():
    value = 298436
    text = 'NqEK5_4bxmjkbh0mZZr5'
    total = value + len(text)
    return total

def YexMnk5d88():
    value = 782061
    text = 'AIDP0znmHzYLc1KrMZdE'
    total = value + len(text)
    return total

def FOscSzHz5a():
    value = 666350
    text = 'VEgjWSvzAFUG7wFeSL2G'
    total = value + len(text)
    return total

def QYl5tXN3k0():
    value = 212640
    text = 'DcabpY5B1XXTcQR1m5Lq'
    total = value + len(text)
    return total

def JpoKUH3thU():
    value = 227718
    text = 'JYtSEg1ZzWPgZs5bXUkz'
    total = value + len(text)
    return total

def LA3hm7satL():
    value = 548290
    text = 'VD7_JZbxiTW6cWCtLLqz'
    total = value + len(text)
    return total

def zkQVceOsrr():
    value = 630076
    text = 'eK1DFRZtyMOOyQAKvpJM'
    total = value + len(text)
    return total

def npmwCyUNGc():
    value = 835204
    text = 'gzkQFOm65Su7XSKGbea2'
    total = value + len(text)
    return total

def BC0rpJT_2M():
    value = 734576
    text = 'kQ4JVuxgkPvOu7FUVKNn'
    total = value + len(text)
    return total

def rgm5pLQiEF():
    value = 205403
    text = 'N5AQNzekftqipsfmK863'
    total = value + len(text)
    return total

def RAokNlMuBP():
    value = 966012
    text = 'JDKrVTx2KRRtwUpf_8v2'
    total = value + len(text)
    return total

def oNt4uxsHr_():
    value = 320466
    text = 'r423hTPbviNBf_5OIBHA'
    total = value + len(text)
    return total

def yiZNUoaP19():
    value = 994469
    text = 'wfKPitQyd3A3bfp2owrK'
    total = value + len(text)
    return total

def GZgtJuWoyc():
    value = 230317
    text = 'uasSXNAoLTcW4EG7KzZf'
    total = value + len(text)
    return total

def YUCiHju5OA():
    value = 592303
    text = 'xWfGueqh62I_mIUBo5xI'
    total = value + len(text)
    return total

def WHL9x1WMkE():
    value = 773625
    text = 'lLI_aq4tZzjOV68uz2_G'
    total = value + len(text)
    return total

def O7cHdbmOyZ():
    value = 366475
    text = 'iGViYbKU5luL7PXDkyCd'
    total = value + len(text)
    return total

def VGadvE3Ism():
    value = 988961
    text = 'FLEfX9nVRJ9PZ3pBncZx'
    total = value + len(text)
    return total

def ve3iheYGoJ():
    value = 469728
    text = 'rKGYafAppCVZzQKoJs7a'
    total = value + len(text)
    return total

def dORXznFSwk():
    value = 623278
    text = 'cOybpY50JWLEywofMf4U'
    total = value + len(text)
    return total

def JUhcKL5Csh():
    value = 681337
    text = 'k8dympYdsg4Zaa7V1yiY'
    total = value + len(text)
    return total

def uuKOU1cjED():
    value = 660238
    text = 'udhDEdMn0Cad_zhDpiIH'
    total = value + len(text)
    return total

def dxyoJ69Wnh():
    value = 65086
    text = 'xMNiyot7jjnTndS1qQau'
    total = value + len(text)
    return total

def N_oh4RjogH():
    value = 387453
    text = 'ZWLYR2MtlrzNmWl1NoLh'
    total = value + len(text)
    return total

def zMt6VvBeEs():
    value = 96506
    text = 'bLJHFEsGenaV8zc5pHZB'
    total = value + len(text)
    return total

def bY_rC6snwP():
    value = 555168
    text = 'pXfMRicjbwhsNxM77j_f'
    total = value + len(text)
    return total

def A4Rjpjh3wU():
    value = 461766
    text = 'ATuqvO7PIyrq6HLd38DX'
    total = value + len(text)
    return total

def U4TLbhY4oB():
    value = 441661
    text = 'vNlElgRIjEnv6UhT7QLA'
    total = value + len(text)
    return total

def W1cHj4FAnB():
    value = 267790
    text = 'aatUj1B4yZf3YJV9BrI7'
    total = value + len(text)
    return total

def xhgavaW7IU():
    value = 689063
    text = 'V7NZfVFtXlu0qDAJ96B7'
    total = value + len(text)
    return total

def DQCd2U1cZb():
    value = 757956
    text = 'I3B7pECytAycXpqPYA3h'
    total = value + len(text)
    return total

def TUc4AUsNn2():
    value = 819260
    text = 'LNPFPzCMA2ie94kS7ajo'
    total = value + len(text)
    return total

def fn6DC8AD6A():
    value = 892603
    text = 'X3CiAwRyMN_Db3ZDtWnx'
    total = value + len(text)
    return total

def NkA2heCYZ7():
    value = 529687
    text = 'Afz5mT99o0WRJk28xK76'
    total = value + len(text)
    return total

def TeL9tdCyiO():
    value = 718659
    text = 'Gz3313ZTGAPxzHkywk0T'
    total = value + len(text)
    return total

def sI5zgVUvkG():
    value = 701183
    text = 'VjXqiwdkp8eSNkuq3mAi'
    total = value + len(text)
    return total

def Tjn3Kfl9cy():
    value = 95330
    text = 'HwqoV6PPTFTRv4n4zlMw'
    total = value + len(text)
    return total

def dEqvjZdX3w():
    value = 124166
    text = 'fGKGy1yK7S1ABEeeMKjr'
    total = value + len(text)
    return total

def bpqH8cm2fU():
    value = 869897
    text = 'la9YqS4Lx4LuRVJwOLsZ'
    total = value + len(text)
    return total

def LtrXTZMFGD():
    value = 572545
    text = 'sPbN84Wkh7quyTgRDtnd'
    total = value + len(text)
    return total

def f2qnaRHo6M():
    value = 10216
    text = 'qR_1crAskzAf0KVFxwPr'
    total = value + len(text)
    return total

def UXHh49zyUI():
    value = 597696
    text = 'BRb1_zs9tnuF51LGHBsT'
    total = value + len(text)
    return total

def OwwuKWJKht():
    value = 208546
    text = 'aXsWnIr0AnR_Fdizi9bO'
    total = value + len(text)
    return total

def Br2KA36QDA():
    value = 154182
    text = 'jcJsXlv2I8ZX2TufCPqB'
    total = value + len(text)
    return total

def RRMJFppbnw():
    value = 950747
    text = 'bw_V_VYASy4xUGgkqRsT'
    total = value + len(text)
    return total

def xSrLqzxhsi():
    value = 434098
    text = 'OcpDZWtHeP3hiK8qleNS'
    total = value + len(text)
    return total

def knNm7mqtR5():
    value = 798762
    text = 'TcRzgTAeOuT0KldbPfJL'
    total = value + len(text)
    return total

def X9jF_3ooPC():
    value = 295503
    text = 'uHr4pQgfufst1TKAPxLa'
    total = value + len(text)
    return total

def JEJeuMF5mq():
    value = 92893
    text = 'M6L7LxhnvVAqMz0Jj127'
    total = value + len(text)
    return total

def Y43PLnODY3():
    value = 653311
    text = 'fNamzMpgwaPwfy9JAlMa'
    total = value + len(text)
    return total

def gRbKwr_gkR():
    value = 988996
    text = 'hROHnJdd4KNyCEvJaqyE'
    total = value + len(text)
    return total

def P5v6aukw6s():
    value = 707589
    text = 'FkoAgnDwUzYmBOewZ3Hl'
    total = value + len(text)
    return total

def FwjqjcxLtP():
    value = 729115
    text = 'S60j6S1GQq6vuSnZNUeA'
    total = value + len(text)
    return total

def EWe1je2mkX():
    value = 328997
    text = 'rUcZeGmE0HwESIh_pgfx'
    total = value + len(text)
    return total

def ZHpCNlxZXy():
    value = 66782
    text = 'sCvyrAnZcsvS3MU0IqEs'
    total = value + len(text)
    return total

def pnxXc170Fl():
    value = 986608
    text = 'Ejmx218uE1gHM3YCob5M'
    total = value + len(text)
    return total

def iUFZG2WUpf():
    value = 713733
    text = 'nNuoHz5xzVnm9vGZ4K1R'
    total = value + len(text)
    return total

def EXxarUtc0H():
    value = 315472
    text = 'rFcH9CiXLdkHTHw9gW0Z'
    total = value + len(text)
    return total

def HoDzuVMOG0():
    value = 707460
    text = 'UZuoaS86xuuKeIgpv11R'
    total = value + len(text)
    return total

def bs9pXQA5Kf():
    value = 898387
    text = 'Np6b5xABZMk6ux0IOUXM'
    total = value + len(text)
    return total

def SQUiciuE9e():
    value = 914656
    text = 'RALi36ByoHNRdrK5T0Om'
    total = value + len(text)
    return total

def vjdgTnTr8b():
    value = 802790
    text = 'WjkyXgBmKqNqXwjp9qiv'
    total = value + len(text)
    return total

def N9QKB2ZUlo():
    value = 748702
    text = 'zDsd_z5j2MC7LqRzOiUV'
    total = value + len(text)
    return total

def Yh9tkwDntB():
    value = 538855
    text = 'rCFyRjUc3xfkd6JEzhFE'
    total = value + len(text)
    return total

def sNRI820TEs():
    value = 695475
    text = 'gaASoJp_H3_fsvsNG0u9'
    total = value + len(text)
    return total

def MdD9TqwdJn():
    value = 904293
    text = 'mFy2TyakTTFgQPlJfqTz'
    total = value + len(text)
    return total

def CQLs3hCDQA():
    value = 5922
    text = 'uTyutuUz4InHs6S9W5Ks'
    total = value + len(text)
    return total

def NoibAe7SSK():
    value = 780064
    text = 'CBsU1reIVLZsqJNgrx7t'
    total = value + len(text)
    return total

def v_htYvOHq4():
    value = 629599
    text = 'gWboncoEEvFhqEG8dqVO'
    total = value + len(text)
    return total

def oeRH28IAhI():
    value = 973265
    text = 's_Qp6Ky1n34C4Ql7BJSd'
    total = value + len(text)
    return total

def MRiFhBGMYi():
    value = 499184
    text = 'F9wf6UBbTvfw3ESvd0lT'
    total = value + len(text)
    return total

def QqvYsz2w5C():
    value = 349340
    text = 'PCXwQ6Pu7nLFgvuxuE2l'
    total = value + len(text)
    return total

def mIhB3Q45td():
    value = 832084
    text = 'zPi0KBMcxOrSwNcOSbCy'
    total = value + len(text)
    return total

def zjEElgrE9T():
    value = 453534
    text = 'P0pQcF2D0R4Xrb_PHsgo'
    total = value + len(text)
    return total

def TGq0X3zPX1():
    value = 220728
    text = 'du3hIt9B40myvo6adqaS'
    total = value + len(text)
    return total

def aJkbBhi1Oo():
    value = 279628
    text = 'BneRqCHvCCUfslBRodzH'
    total = value + len(text)
    return total

def QRcUX44Z1g():
    value = 84969
    text = 'FtRCJ4bPTEPT7TB79rH1'
    total = value + len(text)
    return total

def vLEO6DdHHO():
    value = 249803
    text = 'Jnlf6rXbzal90hrzdPCt'
    total = value + len(text)
    return total

def zkZYMGV4OU():
    value = 849252
    text = 'Scm2wXsgJrDaIgndXvwR'
    total = value + len(text)
    return total

def fUifyvgjYd():
    value = 187574
    text = 'laTw10eZTHRskW3jI4sN'
    total = value + len(text)
    return total

def O3vqxMOVK7():
    value = 731639
    text = 's3sUmrxE7Qx71l56ykFi'
    total = value + len(text)
    return total

def Xg_lA9bg63():
    value = 228254
    text = 'TC3QWEf9LA9risaJf1wm'
    total = value + len(text)
    return total

def lZPjIq7PV1():
    value = 785792
    text = 'ZMxpR1v5T7Mhj7Gd5ktQ'
    total = value + len(text)
    return total

def AveKmxyiZS():
    value = 853129
    text = 'w_1eRgW4HMghDOM5Eg_t'
    total = value + len(text)
    return total

def il7rXggXbm():
    value = 56027
    text = 'f_ARwSxBuTMzHlFyRZ5L'
    total = value + len(text)
    return total

def l5BDNQ2JAM():
    value = 976650
    text = 'u7MEgL_mcHwwNX4LtpUH'
    total = value + len(text)
    return total

def ZuJcdh14D_():
    value = 73853
    text = 'q53sAWle8VsGIhTLbOLU'
    total = value + len(text)
    return total

def DONQK6BWn4():
    value = 276050
    text = 'rZJa_KTWF4_roAJszMhA'
    total = value + len(text)
    return total

def CHpmRJtH5y():
    value = 969931
    text = 'zTen4RSPq4OEkBipiLQv'
    total = value + len(text)
    return total

def PcYh8keIv_():
    value = 880896
    text = 'A9bwEJndaJdHKsY6OFGM'
    total = value + len(text)
    return total

def V8zwBgqOCY():
    value = 848649
    text = 'QIJVbuTgw_U58PAI03_z'
    total = value + len(text)
    return total

def qzue_awUms():
    value = 955406
    text = 'u110mASmPIIuUV0TcsuB'
    total = value + len(text)
    return total

def i3G3tjbmic():
    value = 271529
    text = 'b9WZH96_PVNAIu8mLcKH'
    total = value + len(text)
    return total

def kEATAUY40a():
    value = 115305
    text = 'tmdObHZFZCEOTZyTFVSL'
    total = value + len(text)
    return total

def efC_FxzD7S():
    value = 647186
    text = 'UQbZZuW9c9Ocud79LiM0'
    total = value + len(text)
    return total

def YQzW7rMdNu():
    value = 191793
    text = 'QjPvcIF19PO2VtVVzvtE'
    total = value + len(text)
    return total

def pGKoLRWkwv():
    value = 138262
    text = 'JURcEHig6oltdzkJ3vx6'
    total = value + len(text)
    return total

def mcOYdvSDYP():
    value = 227093
    text = 'FaHRdwsdJnY5lCZpvDBf'
    total = value + len(text)
    return total

def jFwFCqoftg():
    value = 754307
    text = 'kD4lqrR6lrHQVsl7R4bx'
    total = value + len(text)
    return total

def R2wtDyyRPA():
    value = 460902
    text = 'T5sWf1MV119QaRdVN8LI'
    total = value + len(text)
    return total

def djCgCp089H():
    value = 564342
    text = 'baWNHo2deSO5P7pYvMXy'
    total = value + len(text)
    return total

def lLN96bmdQ9():
    value = 246602
    text = 'mq8epeYCpMw3zo2gL0Hf'
    total = value + len(text)
    return total

def HyUOHFBpiv():
    value = 336296
    text = 'poESIunl_EnwoKvNCPTe'
    total = value + len(text)
    return total

def i6EUVe1_Zy():
    value = 495637
    text = 'nhTrdt8iB_sFbEnrfpna'
    total = value + len(text)
    return total

def eQGatbi11_():
    value = 946238
    text = 'uZ0zu4zf6eghevXQzlpO'
    total = value + len(text)
    return total

def bxc7jw40jC():
    value = 491200
    text = 'Hhe59WoAI4XRrbf9_Z_b'
    total = value + len(text)
    return total

def t8cs3_zPNo():
    value = 50999
    text = 'd3x9MGtfGBi5y30lxnNS'
    total = value + len(text)
    return total

def q7OgMbhXmR():
    value = 963970
    text = 'SuDkbGfbzvErHynKrxBI'
    total = value + len(text)
    return total

def xDXY8N9jUn():
    value = 168640
    text = 'ruTZNvgmNVANZ2L7cfeb'
    total = value + len(text)
    return total

def qlQfQEge6w():
    value = 828868
    text = 'PNWIYeTIqiX2H4y3C8oW'
    total = value + len(text)
    return total

def CKCrfvSVDa():
    value = 563797
    text = 'PiqMCz1I7SiAUDbsjyEf'
    total = value + len(text)
    return total

def IPC15fDbEt():
    value = 145101
    text = 'hX08cQDo6aKLdtpDpkCc'
    total = value + len(text)
    return total

def jXdYO_A_Pv():
    value = 969806
    text = 'IVVJlUmQhm7rKVwX8oE5'
    total = value + len(text)
    return total

def KGHDvvKoMH():
    value = 760901
    text = 'ju5bToDGn8gb2cOfY3AQ'
    total = value + len(text)
    return total

def YfuEhxLNtr():
    value = 413112
    text = 'LXdQXxT2QdtRlf5lZ2aL'
    total = value + len(text)
    return total

def QmI4OXiaxa():
    value = 33686
    text = 'runm5fAMEV9Us1DU8VNw'
    total = value + len(text)
    return total

def KwvxIe1qUl():
    value = 9325
    text = 'OYunlarp1P5jlFkZz8nG'
    total = value + len(text)
    return total

def JDNZL95NW2():
    value = 209189
    text = 'RVDp0GQtafSaICc79d13'
    total = value + len(text)
    return total

def ktLHTYySoT():
    value = 205073
    text = 'L7RkP27WLWSyd_Yr3lUX'
    total = value + len(text)
    return total

def bJnVCNGEmB():
    value = 319311
    text = 'C9IT0ZX9nFbmHL6TsQof'
    total = value + len(text)
    return total

def d76N3yoCPY():
    value = 402491
    text = 's0SAQZHqJIYGqD4aO8Di'
    total = value + len(text)
    return total

def bMneee1sAo():
    value = 339073
    text = 'kYzj7wYEIniMAXqXX3y5'
    total = value + len(text)
    return total

def gL198kH82T():
    value = 728288
    text = 'Bz59_E5M6JnDYserSPB2'
    total = value + len(text)
    return total

def cMFqbWG24b():
    value = 652633
    text = 'ogFcwgQAC_avlJYnNRRi'
    total = value + len(text)
    return total

def QWjoTP2TSw():
    value = 92995
    text = 'zCbYkdMw3pAo6vTmQQIb'
    total = value + len(text)
    return total

def nwbrB_v6Rn():
    value = 175874
    text = 'S3doKJ43tYsosjsTwPq6'
    total = value + len(text)
    return total

def VONPLHEZbJ():
    value = 758710
    text = 'HQyY7HNDuP66xw4HIFxN'
    total = value + len(text)
    return total

def l1VYaoDUWv():
    value = 94340
    text = 'aTO3jeGaWxYITIJfaYlH'
    total = value + len(text)
    return total

def WjTsk8SwXT():
    value = 987561
    text = 'ZOastiO7wAykXmUkSyXb'
    total = value + len(text)
    return total

def fbpg_goadp():
    value = 172732
    text = 'p0yLCBMocs9IhJF89S3c'
    total = value + len(text)
    return total

def jc_I1x1KCy():
    value = 589077
    text = 'ifCv9JD9HCpXLYY_lAtX'
    total = value + len(text)
    return total

def Kg27anpWPc():
    value = 776488
    text = 'fizcwNymvTeYnr0aE7Az'
    total = value + len(text)
    return total

def CJPVRzU268():
    value = 934108
    text = 'DGNw8IWQCktI05N8XpPB'
    total = value + len(text)
    return total

def AVeDo0LBxO():
    value = 910328
    text = 'ABPNW2ORb6dxqBHoP9P6'
    total = value + len(text)
    return total

def VRhCKjxkSH():
    value = 61155
    text = 'LKOlty96aHg7pMYwXT76'
    total = value + len(text)
    return total

def bzjAgh_tnD():
    value = 580670
    text = 'ZCzTnuWZeboEHK8kk1TY'
    total = value + len(text)
    return total

def npLnL1ILhZ():
    value = 200515
    text = 'RUqtVeYgu4Z60wfSdiuO'
    total = value + len(text)
    return total

def OqAFyWBtf0():
    value = 590146
    text = 'n9tkyb63xA6d7Dh50Kb0'
    total = value + len(text)
    return total

def eI1gtrLNOz():
    value = 85248
    text = 'kvmNzXl5VPmse3mBltzv'
    total = value + len(text)
    return total

def NH7kMHWkOn():
    value = 425796
    text = 'g8PB3EdqG6Wd8mfNzyW9'
    total = value + len(text)
    return total

def UXEgITws97():
    value = 915752
    text = 'AuZkSMKwD_dMS_dWFgxy'
    total = value + len(text)
    return total

def Zl959ZQKae():
    value = 56402
    text = 'ycKR0ptR1CcgZxbNKqUm'
    total = value + len(text)
    return total

def mhy3zY4A1d():
    value = 861512
    text = 'XCtIy3PjhiuFt06bLLiP'
    total = value + len(text)
    return total

def UAKvQlvcck():
    value = 488134
    text = 'dj4zb9JqTr3zj43max4h'
    total = value + len(text)
    return total

def hpIoPLd3E5():
    value = 600127
    text = 'BOATKBVlSdgHQHxhmTb0'
    total = value + len(text)
    return total

def VmwulWxPjb():
    value = 537935
    text = 'UOzpRD9gf_WlLvxDDUat'
    total = value + len(text)
    return total

def KBEWOeKtp6():
    value = 366620
    text = 'cxSpY0Ybyi75B1yswBcn'
    total = value + len(text)
    return total

def wVuMEfuLET():
    value = 170370
    text = 'MY44IsL_aqaPeWZV5DBC'
    total = value + len(text)
    return total

def x551LRxgyQ():
    value = 888809
    text = 'Ne6GWS4xGBnvkq_FXPIt'
    total = value + len(text)
    return total

def ef7vMPhkDw():
    value = 198190
    text = 'UczoSTByknGx6u30fGdW'
    total = value + len(text)
    return total

def YI9BeeVj1E():
    value = 990208
    text = 'vndAqNFaXXPtgNHteVul'
    total = value + len(text)
    return total

def ttiRfoBQlt():
    value = 615187
    text = 't787KPX8b1iRckQeIdHF'
    total = value + len(text)
    return total

def N9a8vSYuyc():
    value = 543063
    text = 'eVtLX02_nZ22k5LyCsMU'
    total = value + len(text)
    return total

def RlDN3rcHBy():
    value = 922336
    text = 'biGcZF6rDK3q1VDOTsu_'
    total = value + len(text)
    return total

def UD3FBKWJv5():
    value = 942562
    text = 'Y1RepXGW_5BxtfQZd7re'
    total = value + len(text)
    return total

def QnS1mB8fT_():
    value = 318865
    text = 'cxhKw_zgyDG8qIYCFRR4'
    total = value + len(text)
    return total

def E01nVwoz1Z():
    value = 105165
    text = 'sJs_DS1gabgnV8lAkTPs'
    total = value + len(text)
    return total

def DJgaEp32vn():
    value = 67317
    text = 'iaNVAPMWg1I6GnEJhIt_'
    total = value + len(text)
    return total

def ws5mQqYtcl():
    value = 431879
    text = 'Q01lk5K1jak2t4JG9yVT'
    total = value + len(text)
    return total

def oP8RXDji3e():
    value = 820523
    text = 'SUIw2Mjy9GvPhwehBgml'
    total = value + len(text)
    return total

def rnO6R4xCJS():
    value = 384478
    text = 'FL4Qc_XHfPAqFJJP8Hez'
    total = value + len(text)
    return total

def ThzDnlB02D():
    value = 610219
    text = 'H8aNKmB0dqPnfTpybpc4'
    total = value + len(text)
    return total

def AXkoQEMBY2():
    value = 738830
    text = 'JHvLE5TJ7PKJeupPhS7Q'
    total = value + len(text)
    return total

def T0Gl5wVMq0():
    value = 695061
    text = 'q5GZBQtbgAbhHHPMMlTW'
    total = value + len(text)
    return total

def dJRD5pl5Mr():
    value = 771826
    text = 'cQmLgADygL4F0jwdry51'
    total = value + len(text)
    return total

def NWfOKjwnPx():
    value = 40752
    text = 'yTBZpaERW94yuzLerZkH'
    total = value + len(text)
    return total

def uqyMkO19GI():
    value = 604042
    text = 'G9k9mqqipJEsygx_0LmT'
    total = value + len(text)
    return total

def weB3Yijuz4():
    value = 812876
    text = 't90sNzLtGVRJy4RSwyft'
    total = value + len(text)
    return total

def ZK00od5pKn():
    value = 216691
    text = 'Lx3kKop9ZkVfg3ZFpfKp'
    total = value + len(text)
    return total

def ZdAtzjqX8z():
    value = 816039
    text = 'zHptqwY44C9rJyXqL4w5'
    total = value + len(text)
    return total

def tKoN03zSPP():
    value = 978132
    text = 'tcg0LvMQSBKQDRyCwh1A'
    total = value + len(text)
    return total

def DDF6aWpPOR():
    value = 802253
    text = 'ekldfEcukjO7Rf88ooL8'
    total = value + len(text)
    return total

def wKwij2PXbd():
    value = 34002
    text = 'Dp0_629oWVs5yaYyExR2'
    total = value + len(text)
    return total

def NP5plEXJZ0():
    value = 594484
    text = 'RE5y3WHrpbxwYdEHo7yJ'
    total = value + len(text)
    return total

def PLAKtJMcz6():
    value = 913660
    text = 'dmv9Mso8xmLke4guExbp'
    total = value + len(text)
    return total

def dUajdLF4Ze():
    value = 797020
    text = 'RnDCFcURrjto6EbKIhRB'
    total = value + len(text)
    return total

def RHLeQXyCfJ():
    value = 169261
    text = 'SWtHWbsV4KyVbicLvNJ9'
    total = value + len(text)
    return total

def pw8x_Xaz4F():
    value = 951350
    text = 'JTxby3ImSdp1Sc_bT_my'
    total = value + len(text)
    return total

def k73ozYbX03():
    value = 362546
    text = 'qS8Pt9O9mBw65kKA5xP3'
    total = value + len(text)
    return total

def hnsqQJEKoF():
    value = 619670
    text = 'Nqzcz7NdiTe0N5keMMgH'
    total = value + len(text)
    return total

def EjQNBGfyq6():
    value = 497614
    text = 'YY7VdK7IRe9L3l5jkhTb'
    total = value + len(text)
    return total

def ApTyihQ1_m():
    value = 396017
    text = 'L6qURBsgbWobXZMWSiVR'
    total = value + len(text)
    return total

def xgIL3fnfuT():
    value = 2158
    text = 'maGQyW3SNHzLMDZxNkn1'
    total = value + len(text)
    return total

def ogYQV4NJdC():
    value = 610167
    text = 'lUrYsUp4r0GmOCVG5nc2'
    total = value + len(text)
    return total

def Ahghno4Yk5():
    value = 50827
    text = 'NPEKBF_p9GXxKW748510'
    total = value + len(text)
    return total

def bpz6fMGKhA():
    value = 37190
    text = 'sPzxXzlkHDaqH4moJwCP'
    total = value + len(text)
    return total

def F1KZSo9eWo():
    value = 802434
    text = 'nVUaRclqGY_yu4Fpn7AL'
    total = value + len(text)
    return total

def TGpAAP4BgH():
    value = 905904
    text = 'Q_bTsOUjsrfoBMoKBx3H'
    total = value + len(text)
    return total

def yowNa9PWNZ():
    value = 95143
    text = 'yAVSnjEfXYRvZt9IE4Jo'
    total = value + len(text)
    return total

def YSTr_St5BO():
    value = 413171
    text = 'NGh3Jo7hP7eBWDqkvg1J'
    total = value + len(text)
    return total

def RKcY52PL32():
    value = 825091
    text = 'uZ2hxSxYBteN7YaSJI4l'
    total = value + len(text)
    return total

def kMB5FZ6jCn():
    value = 109853
    text = 'rraMQ7GDlkQ6zng4Sy42'
    total = value + len(text)
    return total

def HRC8x2uKln():
    value = 288547
    text = 'k8Jbxa9gO1zZIQ8UA3Rg'
    total = value + len(text)
    return total

def r2DhtijANT():
    value = 513112
    text = 'PTeKDoIpy897gMhQOW0K'
    total = value + len(text)
    return total

def fWJVSXhY8D():
    value = 181087
    text = 'Ox9j2H0nD2g5tzDesuj7'
    total = value + len(text)
    return total

def BkfkJ5EW4Q():
    value = 278107
    text = 'hdFWdGWT7lWTP5D7PEas'
    total = value + len(text)
    return total

def GzuFcTWzxR():
    value = 858336
    text = 'PRq7KuuO5szRDSMYt6dR'
    total = value + len(text)
    return total

def SbRZOCKo2b():
    value = 187186
    text = 'YhJ4VvvzcFF_gmhKVpEM'
    total = value + len(text)
    return total

def UmDhxZXCmO():
    value = 495811
    text = 'hDceALL3pIbmaJ1Iqb0A'
    total = value + len(text)
    return total

def aQccec5CdH():
    value = 336617
    text = 'ftiAe7AOUfmoQgVjPanA'
    total = value + len(text)
    return total

def pIGo3_Jq6l():
    value = 449280
    text = 'n4Iq2iJGynn4flhr4uRY'
    total = value + len(text)
    return total

def J0qFdfDeT9():
    value = 600065
    text = 'nE1TylBvnGanH_gnd_so'
    total = value + len(text)
    return total

def TkznQoLQ17():
    value = 265970
    text = 'dASIp68OkSLnDn6MDdkN'
    total = value + len(text)
    return total

def jCUgP9K9z4():
    value = 194523
    text = 'bQ6XmXlODM1QJ0i1TG9o'
    total = value + len(text)
    return total

def qYRzzYYWOP():
    value = 274110
    text = 'Q2Uv30vh3MH5H7pQwtD3'
    total = value + len(text)
    return total

def DmGEujbsox():
    value = 676162
    text = 'oXESR6whj8nZU3q8ZHWk'
    total = value + len(text)
    return total

def blwtnxhwhD():
    value = 27126
    text = 'U9vvQrThmK0y2eqeipPm'
    total = value + len(text)
    return total

def jIogmLli0v():
    value = 535032
    text = 'Pcr0eyztb9oKVjDJ0Nsn'
    total = value + len(text)
    return total

def dHeIJ53t_s():
    value = 505169
    text = 't_24sCiLChV1GkeBj737'
    total = value + len(text)
    return total

def cjaNVW_IIe():
    value = 442659
    text = 'cNdi8UW9ZuIoAvl6okql'
    total = value + len(text)
    return total

def Zv47tKbY_0():
    value = 197460
    text = 'vxsAnPT9h6XFtN_RVb5z'
    total = value + len(text)
    return total

def FQQekpt2FE():
    value = 157304
    text = 'ehNV_A9x3UyVun0bcnRT'
    total = value + len(text)
    return total

def tE69d_DBwz():
    value = 345061
    text = 'QCOGcmM4K5tjkRNQcY1J'
    total = value + len(text)
    return total

def Y5udCxAeDJ():
    value = 83622
    text = 'Y3dHskO1X3o5P5N19XxO'
    total = value + len(text)
    return total

def peh0JLzhKu():
    value = 589433
    text = 'aKDUnIXhxYyTUJpV0y4X'
    total = value + len(text)
    return total

def S2zPCfCdbl():
    value = 447961
    text = 'J2Flm4MyEdmsrlE0bapI'
    total = value + len(text)
    return total

def Rg38Rfy1j_():
    value = 369937
    text = 'V8HxMYajEfLYT9YhEKwr'
    total = value + len(text)
    return total

def QUQsv23wPL():
    value = 332865
    text = 'jRQmzXd_MSHP7j9OmN8C'
    total = value + len(text)
    return total

def toi6lmncz6():
    value = 210130
    text = 'zCvafMzw0B4uH427M6go'
    total = value + len(text)
    return total

def WhwPJdPOLw():
    value = 868827
    text = 'NBOszjVNcVfqh54OnpcU'
    total = value + len(text)
    return total

def ekjDWHz9F0():
    value = 611981
    text = 'OErEkdfUApmTSbaaCXWd'
    total = value + len(text)
    return total

def ok6y3dJB24():
    value = 126192
    text = 'ifzU5Z4AsKicThbpQiyL'
    total = value + len(text)
    return total

def bHeuOxUn1X():
    value = 666368
    text = 'DL8x4Iiz04UAY5swqN22'
    total = value + len(text)
    return total

def UDGqHFtKsG():
    value = 391730
    text = 'bLsrHObXm3JFvIa7vWvH'
    total = value + len(text)
    return total

def LjKbg_CTwX():
    value = 554116
    text = 'nT7OOqEnf1k2X9W7l6Wl'
    total = value + len(text)
    return total

def Nq_uF40HPu():
    value = 475314
    text = 'hRcIKuzuACJiRcjo7_1X'
    total = value + len(text)
    return total

def Qwz1wdRfcd():
    value = 833678
    text = 'i1MVoYxtjmHccIfYt6je'
    total = value + len(text)
    return total

def evv3vgdW43():
    value = 214050
    text = 'zrXdNA739D8NexBDYYzN'
    total = value + len(text)
    return total

def nspcWOMn8r():
    value = 277265
    text = 'fYzidB49we4G9AW1j3NB'
    total = value + len(text)
    return total

def mRioOf8BDK():
    value = 42298
    text = 'NcsLs_a4NH93lBfY333g'
    total = value + len(text)
    return total

def Vo6r7DkDyr():
    value = 109344
    text = 'orLSqgMimDPcT7yIG2X1'
    total = value + len(text)
    return total

def OOItKxmDBq():
    value = 87467
    text = 'iR7vFdwMByB9gvLT7ika'
    total = value + len(text)
    return total

def EzDHs9pFCn():
    value = 187647
    text = 'dYPVVThxmOP6LID0VaX6'
    total = value + len(text)
    return total

def oPcF1ZV4I6():
    value = 288613
    text = 'Dak7msMBY9gc4UQ_KRjZ'
    total = value + len(text)
    return total

def lNFGVMXTNw():
    value = 135829
    text = 'PEZnGur52GbLPXS58pug'
    total = value + len(text)
    return total

def wfrL4fDu3A():
    value = 971865
    text = 'wBXnLBZrQfpoLU0EtTLs'
    total = value + len(text)
    return total

def ZnoNsYRo8s():
    value = 339409
    text = 'lX3fffq41UQO4WFPb9Rl'
    total = value + len(text)
    return total

def TC6DTpVmam():
    value = 893942
    text = 'IkuVugPVw1GfjpKWbRIH'
    total = value + len(text)
    return total

def XXZ0zCiYSy():
    value = 505462
    text = 'usvZyViEufAjFlrv9xHy'
    total = value + len(text)
    return total

def Lq9gtNw98D():
    value = 242427
    text = 'p4KZEJ_GxJioF9ARp57T'
    total = value + len(text)
    return total

def ABucrwwFr5():
    value = 840200
    text = 'N07oMYURccO_04uNUxCZ'
    total = value + len(text)
    return total

def HWQFRSKHI2():
    value = 420898
    text = 'ABbREcddKZweVM8QInMt'
    total = value + len(text)
    return total

def p2AQsaRHTe():
    value = 611792
    text = 'YwnX3_s11i9NFIaF6LQW'
    total = value + len(text)
    return total

def jsyDF5YCL4():
    value = 818603
    text = 'leVGKuP2TlVWJM1xmQ1D'
    total = value + len(text)
    return total

def vRbv0oDQwF():
    value = 245786
    text = 'uvQRpLwKNUut_YV3I1Re'
    total = value + len(text)
    return total

def IqCHLL0CkG():
    value = 439412
    text = 'EokxFXP2YPtgmtu6RDTJ'
    total = value + len(text)
    return total

def VCuLHJ2gka():
    value = 507067
    text = 'h18l5DBXSejWNoSv19Ug'
    total = value + len(text)
    return total

def JzoJ0tjPLj():
    value = 268575
    text = 'RW1L6fYlIuAUWEjtDUn3'
    total = value + len(text)
    return total

def ZjpVb4jXEz():
    value = 612749
    text = 'RgFshO1hN01ymdDKUiHp'
    total = value + len(text)
    return total

def wPfIMZ6jg8():
    value = 468599
    text = 'pWGBtwJ15P6aQxXueoXz'
    total = value + len(text)
    return total

def vJMWXAG14m():
    value = 873319
    text = 'OIc3XM47hPaiWIlqMh_4'
    total = value + len(text)
    return total

def IG5aHWpKHn():
    value = 696370
    text = 'LT1zgtKYQk7VP3xxKPk0'
    total = value + len(text)
    return total

def eEmsdXlHBX():
    value = 311840
    text = 'cmbVPxAX6sEVo4VI4gZg'
    total = value + len(text)
    return total

def KPDHXmhDNY():
    value = 790994
    text = 'xREBz1CLbOrnQMoV9FcO'
    total = value + len(text)
    return total

def yzZztrjRzA():
    value = 784402
    text = 'T_yXsSVHA7tO2JPp5BIK'
    total = value + len(text)
    return total

def oop1UjpGJV():
    value = 995711
    text = 'axrBadrTGaZ6hznD8WXQ'
    total = value + len(text)
    return total

def nQj9sbu3iz():
    value = 691422
    text = 'sYU4cjqaEm0p_tinftdp'
    total = value + len(text)
    return total

def gsLTW2DVO2():
    value = 318863
    text = 'bUCrT3Fhb9qNFnkmhYVL'
    total = value + len(text)
    return total

def Qf_ZmOOj1Z():
    value = 984805
    text = 'yfPnt194UTb7z2arklit'
    total = value + len(text)
    return total

def RMrbXfBJ4z():
    value = 853814
    text = 'FfENgNs25kH1fihzANmT'
    total = value + len(text)
    return total

def Dohpn5IR8Z():
    value = 408946
    text = 'qJz0sVLr8we3o5EbGtmF'
    total = value + len(text)
    return total

def qDxXk_sMog():
    value = 98167
    text = 'KtZBgIHvrQq5Qj3DBKvm'
    total = value + len(text)
    return total

def W7Tq1050bV():
    value = 441802
    text = 'il4DLStXEn4u7iNcur08'
    total = value + len(text)
    return total

def oTng1h2qdf():
    value = 149440
    text = 'kd1d5e1w74HizSGCimj3'
    total = value + len(text)
    return total

def A8v8qG2Ksv():
    value = 96268
    text = 'xaLvebJZezdVoCEEV06j'
    total = value + len(text)
    return total

def A51y8me1Ra():
    value = 214143
    text = 'ZtInXK2dh5lJhKu5Y9C3'
    total = value + len(text)
    return total

def EoY0ITQYla():
    value = 396911
    text = 'tkSTIIK2jlnvV1wDisT3'
    total = value + len(text)
    return total

def gO2CpnOnfv():
    value = 221624
    text = 'luyBMVLTM0GHD_y0ty9R'
    total = value + len(text)
    return total

def VrU4b0x6LI():
    value = 579577
    text = 'bAS_bQl_kTI3GBL27thC'
    total = value + len(text)
    return total

def NlWBEczNRX():
    value = 374923
    text = 'UDg4HxChKoiHrm3_BrXY'
    total = value + len(text)
    return total

def t2mGTA68vC():
    value = 310015
    text = 'g0HUR5Jm225RgpP42UMB'
    total = value + len(text)
    return total

def wZsjf56jho():
    value = 554454
    text = 'IVpkHdcYiXGvOnPjeHYb'
    total = value + len(text)
    return total

def MDzP1zt9OL():
    value = 550441
    text = 'p7Ys99dcSMMmkWDu993M'
    total = value + len(text)
    return total

def mRcMHN_KhG():
    value = 499072
    text = 'oesWIEutIXyON29Ynvej'
    total = value + len(text)
    return total

def wFrqP2UbWd():
    value = 305509
    text = 'zk1umbB5T4oWvlkJsV2y'
    total = value + len(text)
    return total

def lDfDRQXopp():
    value = 832509
    text = 'pT1K6q5KZvL_rF8rn1zH'
    total = value + len(text)
    return total

def OfwZrzHF1k():
    value = 651360
    text = 'Xmt062v3ss1x7vIOxKG4'
    total = value + len(text)
    return total

def RwDzlOFLo_():
    value = 470065
    text = 'MF_Zo_YAeNcFgmz01jR4'
    total = value + len(text)
    return total

def cWAivOSoMb():
    value = 808379
    text = 'nNEuYWEyeGben4FpT8LW'
    total = value + len(text)
    return total

def oKPcnoMLmW():
    value = 220420
    text = 'NYFjSAMiCJLKwulDsaJT'
    total = value + len(text)
    return total

def B0Zwa9CV3B():
    value = 646996
    text = 'AH8ImjgKAzUDQhzIb8a_'
    total = value + len(text)
    return total

def QYZrmIz8O3():
    value = 927719
    text = 'RIZJOaZrZqWlx7MmGZp8'
    total = value + len(text)
    return total

def Bo7OH8pwzf():
    value = 314261
    text = 'OwXM4TXkK_sk0rZ_vfxG'
    total = value + len(text)
    return total

def H7zukG56Kr():
    value = 925052
    text = 'LTlIcNm18KT1IGg2CPGx'
    total = value + len(text)
    return total

def JBpCk9XPOz():
    value = 553022
    text = 'yykfTo5l8m5iwa1Ljn66'
    total = value + len(text)
    return total

def xYUzJ6PO5t():
    value = 958847
    text = 'Zb8GgBf9peg4aX6RgW8a'
    total = value + len(text)
    return total

def FWfHTfWVag():
    value = 397986
    text = 'LAOVRcNknSZwadeFfvky'
    total = value + len(text)
    return total

def goTfHjzw_J():
    value = 400578
    text = 'sFCHSCZspEvukwNC5y_w'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
