import os
import sys
import time
import random
import string

def R3JZDMP8kP():
    value = 539019
    text = 'R4dszxYmnxlCV4IzotT8'
    total = value + len(text)
    return total

def Bc0cPkglcx():
    value = 355806
    text = 'si7VI2k3PgEyP_r1lo14'
    total = value + len(text)
    return total

def UwjVGyhhuG():
    value = 826392
    text = 'BhoJttbVBnVJUyXYqb8D'
    total = value + len(text)
    return total

def zdyN4i3Zki():
    value = 672921
    text = 'Hv4H5AuokwJyFcPnyeRX'
    total = value + len(text)
    return total

def xyTVuluPTc():
    value = 717905
    text = 'dQMRoJIyvUicOxlkwxqv'
    total = value + len(text)
    return total

def hAp77qN2fO():
    value = 30443
    text = 'Uoa7FjraY8kkBMwx_uuM'
    total = value + len(text)
    return total

def k6uHVOYk9_():
    value = 408175
    text = 'bCaoJkHSOGTjDx4Dgo_b'
    total = value + len(text)
    return total

def rugcUPdNhC():
    value = 155391
    text = 'Podk4oYvGy6MPFFBr0vf'
    total = value + len(text)
    return total

def Vno5XoNT0d():
    value = 87003
    text = 'jOWlHoJZ5Ub81VCbCHjI'
    total = value + len(text)
    return total

def YadVhzebnq():
    value = 317017
    text = 'Fgv_52x5ki3N7DBGFKvK'
    total = value + len(text)
    return total

def W9F0MHCtNK():
    value = 663483
    text = 'TwO15ObRc8vaEAGWNwpQ'
    total = value + len(text)
    return total

def HCsXvSnD_W():
    value = 821484
    text = 'uZ2LZa0XQWE31nCJwKUv'
    total = value + len(text)
    return total

def gKmpQmsZLB():
    value = 796257
    text = 'TUtVBDZQyi_8CKbybMcm'
    total = value + len(text)
    return total

def QUl8FDzgky():
    value = 796292
    text = 'BmYfwbvHmgW8jtyj03u5'
    total = value + len(text)
    return total

def OXLDUcxtdt():
    value = 29209
    text = 'KsFesdKncOVvm9Ltu2rt'
    total = value + len(text)
    return total

def GJ36GqW5ie():
    value = 209403
    text = 'vMHqTspu0FuA4fRgC4Wb'
    total = value + len(text)
    return total

def jHJCVfzcCa():
    value = 743813
    text = 'UTd0oQ0TmE7r5B3XkuoM'
    total = value + len(text)
    return total

def dmcCUwbsL_():
    value = 759143
    text = 'tABT0I59n_fR9VxQBb4E'
    total = value + len(text)
    return total

def gOp9WRLCdG():
    value = 849175
    text = 'iQA8zcBGRkoBJs33jS_F'
    total = value + len(text)
    return total

def RMKwkkAeer():
    value = 215478
    text = 'BP58b8kMrabBj71ddjSh'
    total = value + len(text)
    return total

def v45vuPvUz5():
    value = 399510
    text = 'h4N3sBpEPKILYkjfKxNX'
    total = value + len(text)
    return total

def CCPyAoUxds():
    value = 997173
    text = 'tS_04p00wGsLRLQn62T2'
    total = value + len(text)
    return total

def hs1qzLu_np():
    value = 152055
    text = 'R3bHpqa9WW_Tfc_sExTP'
    total = value + len(text)
    return total

def K1mEgfoBoi():
    value = 417508
    text = 'BzWsFsDJwFcOLT9QKmbT'
    total = value + len(text)
    return total

def qrns4A1QCV():
    value = 143914
    text = 'wU9ifhDK0qQIlmsJ68W7'
    total = value + len(text)
    return total

def Cub6PfvqkN():
    value = 435906
    text = 'MDvrxikegf8Ngec8RqGe'
    total = value + len(text)
    return total

def aeMaDFad3R():
    value = 958171
    text = 'CwFXY2v5fFh4pL7eWoMT'
    total = value + len(text)
    return total

def v7ZrUbh9hC():
    value = 7439
    text = 'K7DxQ6Q3jvWjdFmgcfl5'
    total = value + len(text)
    return total

def RsEI1xpB_6():
    value = 562102
    text = 'UqZf6TkcfJuaFZK7643M'
    total = value + len(text)
    return total

def B68Hj9O8iF():
    value = 84263
    text = 'sZQeCgYIgAHbc1ximxyW'
    total = value + len(text)
    return total

def XyXgGFERAF():
    value = 868466
    text = 'ow3daEvevzCrFoEUfDYW'
    total = value + len(text)
    return total

def y4BgerNhT8():
    value = 895932
    text = 'UbhLJzpSF1AYFKjnJvbg'
    total = value + len(text)
    return total

def gyvFOYbtDk():
    value = 538417
    text = 'QV8XeFgVBAK5PozdIiux'
    total = value + len(text)
    return total

def CXYOuCY_Um():
    value = 779284
    text = 'SFP6sqUTIaDiWySAJXSk'
    total = value + len(text)
    return total

def UkyRiJuWQa():
    value = 750815
    text = 'ifLUBsFEQaV0_LeluMUl'
    total = value + len(text)
    return total

def Btb9nknLin():
    value = 396968
    text = 'MuN46rJ58xyGjsVY1RXt'
    total = value + len(text)
    return total

def NW2DYM_5dD():
    value = 707038
    text = 'cxQKVkekw_1WWjiF_8W4'
    total = value + len(text)
    return total

def Q30xGlHlzR():
    value = 543814
    text = 'wgXVYgM2Kr9XylwrlRM_'
    total = value + len(text)
    return total

def L4LGjCOHZM():
    value = 226595
    text = 'JUOKgI1saPK0x0zMIsti'
    total = value + len(text)
    return total

def ZACM4glluk():
    value = 492909
    text = 'nneB4BLumAK3cTSTjGHQ'
    total = value + len(text)
    return total

def mPWXwtVAh5():
    value = 352929
    text = 'h12pXtWWho4tU2BgdXFt'
    total = value + len(text)
    return total

def HlCknd96XW():
    value = 360842
    text = 'yil8NS5x3YigLC6rIr4x'
    total = value + len(text)
    return total

def cqMnUW6NTw():
    value = 731273
    text = 'tMHMttFOmSALcBP2crej'
    total = value + len(text)
    return total

def L1x2vyqild():
    value = 603522
    text = 'PP2e9uyYdVo8X_2sw_a4'
    total = value + len(text)
    return total

def RVwaFRURg5():
    value = 681166
    text = 'p0UNR3K1hIdRvpXzbYfk'
    total = value + len(text)
    return total

def RaiiFKDf6L():
    value = 230941
    text = 'EkassbZILdSH0DjEAHPX'
    total = value + len(text)
    return total

def neZiZpMxBL():
    value = 634431
    text = 'I45IlUHD4sZcpKtwfx6u'
    total = value + len(text)
    return total

def W0M6EVByGQ():
    value = 801204
    text = 'pKkCr5AXrx2AIjYgirTt'
    total = value + len(text)
    return total

def C3FBzYC7aN():
    value = 27634
    text = 'Uuv4D0gQ45vRuDJuwnjM'
    total = value + len(text)
    return total

def WO9f75WgMt():
    value = 148520
    text = 'woz9CG6x3BsiDvfSq7NV'
    total = value + len(text)
    return total

def INgf0TQBsB():
    value = 523527
    text = 'jZXh2FCP6nR5sEuOcppo'
    total = value + len(text)
    return total

def EjCal2Mx3N():
    value = 293216
    text = 'YRFQuMg7t7Uc_DU4QJ89'
    total = value + len(text)
    return total

def UQbeMa0xJ3():
    value = 188341
    text = 'Iae7IdSl6q0F4qDv8B01'
    total = value + len(text)
    return total

def mAEqRAcK0m():
    value = 331655
    text = 'a2U383gU9KhVHFEVsFtl'
    total = value + len(text)
    return total

def alBZHZDQgY():
    value = 399971
    text = 'nF4aRv7Oro_f8UfggBZJ'
    total = value + len(text)
    return total

def L0_QLz9KnU():
    value = 714666
    text = 'n76CLy_D7a84ArtWcHOI'
    total = value + len(text)
    return total

def P2DBPC2APE():
    value = 468809
    text = 'HLBxvusPgGiisIXkhwEQ'
    total = value + len(text)
    return total

def HNg28xxSuU():
    value = 300440
    text = 'U43C6j85A_pTfF2nZ3S9'
    total = value + len(text)
    return total

def NgWgHdqIQF():
    value = 683004
    text = 'K3GeSUCXbe0tIOGluOhk'
    total = value + len(text)
    return total

def WjEeVNa33E():
    value = 576348
    text = 'OX_2oq_uCKFG6U4eifkM'
    total = value + len(text)
    return total

def m3XfTJn8zO():
    value = 111312
    text = 'k_HWl4cTq6veqwK7Dnim'
    total = value + len(text)
    return total

def gE_23szXGr():
    value = 401178
    text = 'u3QV8cRw5SGI9HNIkRsr'
    total = value + len(text)
    return total

def wQq4x3XpKp():
    value = 372056
    text = 'FKwUxga6CrrkvUQ1nQF_'
    total = value + len(text)
    return total

def xMGdOV6qEP():
    value = 970951
    text = 'xWxUjy9FV_GwrrQaWghq'
    total = value + len(text)
    return total

def S92qcogrBo():
    value = 714633
    text = 'bBlUzUbLimvga8mypMXP'
    total = value + len(text)
    return total

def ueZ8nM5DUi():
    value = 993604
    text = 'FxLD_dmv1_fO14WOhn2w'
    total = value + len(text)
    return total

def OnxA1pAJrk():
    value = 552011
    text = 'dZ1OPgycujVi2iSXa7SH'
    total = value + len(text)
    return total

def nUZfuMo63n():
    value = 524146
    text = 'nSHdpKYUlAXf0LMFaraZ'
    total = value + len(text)
    return total

def yFGWXYt8ZI():
    value = 874945
    text = 'uemM5Jls7iXk6CIMEcap'
    total = value + len(text)
    return total

def VtdHNGHF4c():
    value = 406001
    text = 'qn3uMHFequ9D_qOO_5Lk'
    total = value + len(text)
    return total

def VVfou9aGCR():
    value = 830203
    text = 'eXrgp1zGvcHQpLNA4c9i'
    total = value + len(text)
    return total

def oLbVzuv5VN():
    value = 609402
    text = 'Hn4khlHCtpsCVM8OQ1AK'
    total = value + len(text)
    return total

def JQQzZ8Jl3I():
    value = 144215
    text = 'eQ_TzJZUyt3e3dZpT4Mf'
    total = value + len(text)
    return total

def yrC3Vd6cV8():
    value = 863969
    text = 'gj97UZDgmTyuSlw5CUeg'
    total = value + len(text)
    return total

def DbznxphCDm():
    value = 812656
    text = 'nqdxcUQvkVDDrbpdpQsz'
    total = value + len(text)
    return total

def kwv0RwKyQ0():
    value = 16471
    text = 'XOwhfX1TlP9VFTrv7s8c'
    total = value + len(text)
    return total

def jUXk7k4tmP():
    value = 827513
    text = 'T5iYQUIE0IhCTI85hCTy'
    total = value + len(text)
    return total

def c_Uy6Ry8xv():
    value = 50445
    text = 'Rqwr4QAHSedWFmIHoU4o'
    total = value + len(text)
    return total

def TnRY31o_Cu():
    value = 826041
    text = 'TtiUyKDkKEGE2EnSpvtn'
    total = value + len(text)
    return total

def Yv4U4bDNDG():
    value = 856388
    text = 'Bur92rdaEP2Vp6FWG4ZW'
    total = value + len(text)
    return total

def XUBovaP2N8():
    value = 755182
    text = 'LIG2jreFHKAGtWhhzkIH'
    total = value + len(text)
    return total

def lKdJUI6ATx():
    value = 827575
    text = 'xFncA46tEOWOmLS1lB8a'
    total = value + len(text)
    return total

def LQ7sPf2BfB():
    value = 451636
    text = 'PWwBppaMrYgAzH7m2rtn'
    total = value + len(text)
    return total

def qNv9ghLfJ5():
    value = 806603
    text = 'aNvyMQ1YG82IjjkF4Wv5'
    total = value + len(text)
    return total

def aMmTafN7yC():
    value = 51891
    text = 'pvaHLJRhA6wSVHtGaw_Y'
    total = value + len(text)
    return total

def M46pBhY2EI():
    value = 465398
    text = 'WB1mXuDTkYFwZbRpno3f'
    total = value + len(text)
    return total

def WKk795bv3W():
    value = 376539
    text = 'lW18uHBUFF27bKxwMw_n'
    total = value + len(text)
    return total

def IZuNPBdzCl():
    value = 142118
    text = 'h_pifS7N0QJukrucY4tW'
    total = value + len(text)
    return total

def IBLuvoRlwt():
    value = 168083
    text = 'oSMOUgCcrlgA7FgsP3_o'
    total = value + len(text)
    return total

def iDsJKxOQp_():
    value = 674738
    text = 'UnMpvdsCw1RgXYZhO_Nw'
    total = value + len(text)
    return total

def ywQzTBgY3U():
    value = 888359
    text = 'p5JROaWlpMjnBgAIBwgN'
    total = value + len(text)
    return total

def NOhrIZd2ID():
    value = 795684
    text = 'vYCl1fH4O0PfrlNeGouk'
    total = value + len(text)
    return total

def rkY8zQFAWF():
    value = 447614
    text = 'FRLsPsGk7uJRFospuCoP'
    total = value + len(text)
    return total

def wFiKEetcUX():
    value = 627944
    text = 'MWhZ8fy3fCJ4FpPkces0'
    total = value + len(text)
    return total

def Muu_D0rAXZ():
    value = 534565
    text = 'GvcJFSvw_AUiRr7EbaSd'
    total = value + len(text)
    return total

def gdDEpkL9Id():
    value = 96397
    text = 'Y7N7zJWVm0w4lBRk9IDI'
    total = value + len(text)
    return total

def GYgIInMLUJ():
    value = 440843
    text = 'qFyFWbh6BNkfBXl6hiVp'
    total = value + len(text)
    return total

def ydYHj0OYAP():
    value = 27886
    text = 'ZcVKlJM7EkwwOuV00wC4'
    total = value + len(text)
    return total

def Fvv16dNz0V():
    value = 676673
    text = 'ZwJzYjh8t2JWu7tcfT03'
    total = value + len(text)
    return total

def Uva1k5MPYh():
    value = 274744
    text = 'uitHw2z6bOL0L7lBLB66'
    total = value + len(text)
    return total

def zPnlmxF6Ll():
    value = 125555
    text = 'RzlWEugBOfhU5MqJ5O3E'
    total = value + len(text)
    return total

def NpBwCsvRWN():
    value = 711668
    text = 'PBA6_F2mwMfQ4kSzB1eD'
    total = value + len(text)
    return total

def m5K7oqy3w8():
    value = 407125
    text = 'EAMmBi0d_XepQO7q5RTF'
    total = value + len(text)
    return total

def WKC3zEOKUh():
    value = 778453
    text = 'TlSA9Oo4f1dB2t9sbu_N'
    total = value + len(text)
    return total

def q6G1ZIlUWc():
    value = 990327
    text = 'yKnNoOsJ_MJVKGcVcQPV'
    total = value + len(text)
    return total

def lTn5bjqqHF():
    value = 751331
    text = 'ClYw4tgG92MIxgwghAE5'
    total = value + len(text)
    return total

def fdG8x2ePNq():
    value = 454052
    text = 'OnTImSRN_Z8HtstcgJtn'
    total = value + len(text)
    return total

def ozjUP7gm_y():
    value = 351523
    text = 'w7aeCa3sMJfJwGaE7e6r'
    total = value + len(text)
    return total

def ZznClXyBkC():
    value = 10408
    text = 'PXHSI9IwTdw_cuKEPegd'
    total = value + len(text)
    return total

def Up5NaSuAsL():
    value = 122351
    text = 'EB0XnsP80w8R9rr052mv'
    total = value + len(text)
    return total

def aV_aTnTEdu():
    value = 986731
    text = 'SIZBc1EyRozeJ4jwPS3h'
    total = value + len(text)
    return total

def bnC1_JHvSH():
    value = 626319
    text = 'FS0VybD0nRhgHbhmHOYQ'
    total = value + len(text)
    return total

def m5kiRObvqf():
    value = 899913
    text = 'jpJiiUywphpdtHYMP3Qa'
    total = value + len(text)
    return total

def tkUu88e6Xm():
    value = 523314
    text = 'QtNNj0sUOefzcTt98BiC'
    total = value + len(text)
    return total

def HExK1G8jHm():
    value = 315834
    text = 'LQ1oQzH3ssWDK_XPqqKB'
    total = value + len(text)
    return total

def BFt3HyBGg4():
    value = 62404
    text = 'BKkzPna4VIHsv5R5CV1E'
    total = value + len(text)
    return total

def FdVWJzSwGh():
    value = 720902
    text = 'zAia9Vl46lE3B6j3fROc'
    total = value + len(text)
    return total

def OzfzDcDDSU():
    value = 293894
    text = 'PVMzV_bxqw0hkD3l3GW2'
    total = value + len(text)
    return total

def c24wUfHQDS():
    value = 495438
    text = 'vNmSI4WyTwrNcWIWWURX'
    total = value + len(text)
    return total

def fSHvU71RBY():
    value = 295191
    text = 'GumoGCTKR8Ehw9FKth19'
    total = value + len(text)
    return total

def mV6CXlTMvJ():
    value = 744989
    text = 'dZu4e5tjpbD8Hnqwo8I_'
    total = value + len(text)
    return total

def ZzvO_QH8m1():
    value = 16129
    text = 'qhGi8SKUX4MGwMts4KvQ'
    total = value + len(text)
    return total

def JY65SWvPzf():
    value = 893847
    text = 'AV2qaswcq4ihD11l0gHh'
    total = value + len(text)
    return total

def wPJguj6asm():
    value = 969971
    text = 'yhlRcXyF6ezTjJoZjhRL'
    total = value + len(text)
    return total

def yP5JEwda3M():
    value = 153916
    text = 'nyv9vuRhM8om9wGTftdw'
    total = value + len(text)
    return total

def nkEYHxWsCe():
    value = 98489
    text = 'dTlzQwgmBSSVVX2NkhJg'
    total = value + len(text)
    return total

def QepkYKO1oZ():
    value = 515373
    text = 'Xnykyto8z3sN1bNBH1g7'
    total = value + len(text)
    return total

def YBT1ZNFtEy():
    value = 810568
    text = 'piP4n6jq4I50gmlxBT3P'
    total = value + len(text)
    return total

def dSLsWdJD1A():
    value = 613471
    text = 'SVuUBvUq08eAxU0CYko0'
    total = value + len(text)
    return total

def SRHJihh1F1():
    value = 408460
    text = 'UXb8tkDtxxRNVuF72Yhm'
    total = value + len(text)
    return total

def htwXoOrPXf():
    value = 989754
    text = 'NEy8Nr5aCkHYY1DuqkTB'
    total = value + len(text)
    return total

def OVtv2a2WEe():
    value = 712407
    text = 'W1aNHtbCc9_p2XsLbLS0'
    total = value + len(text)
    return total

def rCUrmYiY0D():
    value = 387786
    text = 'H5nmE9xEY6AbKRG9bQGA'
    total = value + len(text)
    return total

def dnTFU4IOd3():
    value = 710157
    text = 'fbHJvNBHtZjN7bUYWL23'
    total = value + len(text)
    return total

def PtHA3SjIES():
    value = 262145
    text = 'eDyYwAIJdBTvSy3_ksA2'
    total = value + len(text)
    return total

def d3xccCCbbg():
    value = 285852
    text = 'kTZ3b_9vlBZ5U0MFQzYA'
    total = value + len(text)
    return total

def yFm_aUOw88():
    value = 531302
    text = 'TrCxjGjcQzWkBaPm5A8h'
    total = value + len(text)
    return total

def nptv71an89():
    value = 416191
    text = 'wefDlq0Ohg1h5gjys_7H'
    total = value + len(text)
    return total

def rSmt58eWM4():
    value = 76829
    text = 'KHa9Mcc7G7OXThffsCV5'
    total = value + len(text)
    return total

def IlR9CpK7ZC():
    value = 915855
    text = 'PRNmfhN7PzbNayvb1dwh'
    total = value + len(text)
    return total

def wwVQCQHCbj():
    value = 60543
    text = 'vNwWEsgkbudG6N60Wshb'
    total = value + len(text)
    return total

def h8G59TPVK4():
    value = 525518
    text = 'cu4L8xJh55Y8SdGstblq'
    total = value + len(text)
    return total

def NAVzSGoMsb():
    value = 977678
    text = 'lbdTVM8RiAFb90BfDiXi'
    total = value + len(text)
    return total

def KMvXD55vY8():
    value = 463193
    text = 'kk_by0MR25TcJVAWmQtb'
    total = value + len(text)
    return total

def CgcNU7FQBd():
    value = 52859
    text = 'ccEak1BAfrLNij780JCc'
    total = value + len(text)
    return total

def M09oCD1tgv():
    value = 719771
    text = 'tgWyXKpm69r5k_Qlr2Gw'
    total = value + len(text)
    return total

def dKJIXauqux():
    value = 538348
    text = 'hIhWo0Z5p9u98DptxZdB'
    total = value + len(text)
    return total

def ps2e0uepmb():
    value = 216224
    text = 'STvgkWz1z9K19wo1sKep'
    total = value + len(text)
    return total

def X5Q0sYQdvg():
    value = 150929
    text = 'NoQ_zn8X2zoL505RUkvR'
    total = value + len(text)
    return total

def VZ7VPpdEYV():
    value = 603947
    text = 'SIWzf1yxVc2cq1slvaFX'
    total = value + len(text)
    return total

def Xil6TBZYtp():
    value = 196424
    text = 'eRE4L5_qz72kK92CXzer'
    total = value + len(text)
    return total

def hPqC2h6rUc():
    value = 919699
    text = 'ieV4ZEOxSb91nPJIQqTH'
    total = value + len(text)
    return total

def w1Fe3HQyGx():
    value = 290387
    text = 'BXWjTZ6r6uw3PHShTx7A'
    total = value + len(text)
    return total

def L0GqmT_qa5():
    value = 979070
    text = 'HdVZfzdp6QyRZeKLIQiA'
    total = value + len(text)
    return total

def SPJiAtuRBe():
    value = 566539
    text = 'fNPyXaXR6lRG1hRJ7BPr'
    total = value + len(text)
    return total

def DQROo_asYS():
    value = 825760
    text = 'hpDeRB3O3END4y1WCH9e'
    total = value + len(text)
    return total

def B7XHMlz0Yw():
    value = 124091
    text = 'zEGFassn06QFQWI_Idw1'
    total = value + len(text)
    return total

def rY98Q5nSsS():
    value = 726801
    text = 'la4pziySQNoSeYvthLgJ'
    total = value + len(text)
    return total

def TT8DD6fueb():
    value = 242983
    text = 'WPYJPlGMdLDOTF4HawV1'
    total = value + len(text)
    return total

def pY8HUvMxBT():
    value = 167994
    text = 'Hj1Ur7TfOXKI4sAfjdba'
    total = value + len(text)
    return total

def ZQ5ZzTRr4W():
    value = 10101
    text = 'yMGI2tSWM_zuneQhjNUQ'
    total = value + len(text)
    return total

def zoegYViZdY():
    value = 295392
    text = 'xeQ5j3nwNdpIMG9aWKQ8'
    total = value + len(text)
    return total

def Q_X0ehV9W3():
    value = 293321
    text = 'nQSydnM0FnrnIMQxv5Km'
    total = value + len(text)
    return total

def t3FzRiEuxz():
    value = 349391
    text = 'BImVScYTe_6D4KhCHrMy'
    total = value + len(text)
    return total

def SFqsszlsNG():
    value = 394625
    text = 'OyWmdM3I6BK3LUNwErCN'
    total = value + len(text)
    return total

def pRhxny9t6Q():
    value = 353717
    text = 'RpOYhW07PWy8LJxcshbu'
    total = value + len(text)
    return total

def gedQgjkI_p():
    value = 206499
    text = 'Xo6hZzpzlJIH9HktNI8J'
    total = value + len(text)
    return total

def X80CzEeOGd():
    value = 98404
    text = 'EHHFXgG75FpBX0p1Meui'
    total = value + len(text)
    return total

def in0kpslbJi():
    value = 649104
    text = 'zPZSSnaCnHg1QAUlVeQM'
    total = value + len(text)
    return total

def iYwaEdd2pj():
    value = 445191
    text = 'HoZZvBS3KrMqZNeZPU8h'
    total = value + len(text)
    return total

def RXF4Mfkf3D():
    value = 407936
    text = 'J2IMmvbaavnJg3K_1UmF'
    total = value + len(text)
    return total

def h3cDxMG54h():
    value = 105676
    text = 'vfp1ikSsSkMuFXT3NX78'
    total = value + len(text)
    return total

def BFdTmNMbNn():
    value = 651748
    text = 'G8uP_7mERlGHxDCGqgGy'
    total = value + len(text)
    return total

def l_AmLG4uOF():
    value = 611865
    text = 'iXxYOrqJnuirxogQ76IX'
    total = value + len(text)
    return total

def H3PI27dnqL():
    value = 511696
    text = 'm1nRAfqhZ26neXy2kz2A'
    total = value + len(text)
    return total

def a6QXTZv2Pj():
    value = 627853
    text = 'uLxZfSizAKUYjsAimElI'
    total = value + len(text)
    return total

def hY18Y1HSM9():
    value = 181607
    text = 'QxuojgQgNtoBM2M6YGt7'
    total = value + len(text)
    return total

def gtKKyxFGqo():
    value = 141591
    text = 'hcs44XrghXwrxw6LZ7vd'
    total = value + len(text)
    return total

def aKdUTNHXi_():
    value = 214714
    text = 'nzqOa8d0p29jyhN1FIhI'
    total = value + len(text)
    return total

def obXL3hu3Bh():
    value = 272041
    text = 'npK0wJd7sUbEBKMKzjxW'
    total = value + len(text)
    return total

def c4TaHr3mte():
    value = 781209
    text = 'z57Lhs_c3pRq_lZ2lzB3'
    total = value + len(text)
    return total

def AwEo4pvch5():
    value = 815513
    text = 'RuVeaMH5Wp4JBJdrM17w'
    total = value + len(text)
    return total

def LpYUqo3Y_7():
    value = 185832
    text = 'jVNIpoxJRhVUirGzT8nB'
    total = value + len(text)
    return total

def ACRrN7Q8pI():
    value = 724904
    text = 'vvxcBtEfj_vRtZESpFON'
    total = value + len(text)
    return total

def avpFUxGdUf():
    value = 638503
    text = 'e83UrWKoT5NxySrgu2Id'
    total = value + len(text)
    return total

def kwaizt4m1Q():
    value = 399626
    text = 'uV7Mmtvk7zngEyhgVXOY'
    total = value + len(text)
    return total

def nHYslh0ft4():
    value = 58541
    text = 'ZvjAGSgT1cxCafGx2pzC'
    total = value + len(text)
    return total

def hTrBIG2ETp():
    value = 215543
    text = 'ju5U0t52OtBZUpHAmovR'
    total = value + len(text)
    return total

def GtqHyBEAWR():
    value = 694548
    text = 'Cw7Vyy0WdqIsnptTfgwm'
    total = value + len(text)
    return total

def g8hoBtKjaH():
    value = 512258
    text = 'msZ_OhrNU798rBVS6VSj'
    total = value + len(text)
    return total

def u7dIthA8KP():
    value = 527436
    text = 'uCnvQfngDraVnSMBax2M'
    total = value + len(text)
    return total

def ZXH1X4MLOP():
    value = 49742
    text = 'UiEm9jvn5yl20CkwsgfR'
    total = value + len(text)
    return total

def Jjgt5tP3E6():
    value = 792645
    text = 'PgK2cBwFSqrPYMs0jhr_'
    total = value + len(text)
    return total

def RGU4UYAMST():
    value = 929431
    text = 'Bvsq5Ur0pDtNkfzW757T'
    total = value + len(text)
    return total

def TIDvx08Fqp():
    value = 842422
    text = 'E60afXD9_69OhnC5szuJ'
    total = value + len(text)
    return total

def LxgY3B58qa():
    value = 219356
    text = 'mLUBFSA3NlZURqME3lyi'
    total = value + len(text)
    return total

def Wsd8tQDQVy():
    value = 113121
    text = 'jqz6858hLvZ2hZSMDPup'
    total = value + len(text)
    return total

def kErY5J5KNI():
    value = 792968
    text = 'EwkNtmRi9PLaPnVi_v6u'
    total = value + len(text)
    return total

def UUkMvaFKtR():
    value = 945013
    text = 'Q9OKNB0i9CKKZwEbQIoI'
    total = value + len(text)
    return total

def HMOmC_uB_c():
    value = 910336
    text = 'PzPoPkcfRZ91i_keCuA_'
    total = value + len(text)
    return total

def I2P7caGNDc():
    value = 874531
    text = 'Cb2xY0qvtmsZ0OJW3c44'
    total = value + len(text)
    return total

def nQqvSGemVs():
    value = 923226
    text = 'uslXQVtcwgvNuz1WdNOV'
    total = value + len(text)
    return total

def yPobbvZgA_():
    value = 245942
    text = 'LJ7ooxMwz3eflktMMC1M'
    total = value + len(text)
    return total

def adcMTrfG8o():
    value = 610524
    text = 'gkrYOjm3ncubN0I9Ir4x'
    total = value + len(text)
    return total

def rRcrf4iD8V():
    value = 750986
    text = 'oSrAfrNK1WvdVQAVtwo4'
    total = value + len(text)
    return total

def jJdhHbAJkR():
    value = 816934
    text = 'og_94BM3BqieXkMVD3sV'
    total = value + len(text)
    return total

def eZBMjBBKQe():
    value = 453866
    text = 'ZwyUk79rM5QQPOEtpQUd'
    total = value + len(text)
    return total

def gzypEjLMa9():
    value = 185476
    text = 'o8wpb2p7_W6oye4AL6Zv'
    total = value + len(text)
    return total

def Y8hP54LYPL():
    value = 800932
    text = 'EKT5CVYZS8SqnDNMAEpg'
    total = value + len(text)
    return total

def dDisdL4L0r():
    value = 463886
    text = 'QXuc1iUOn3NSQsJmGq8g'
    total = value + len(text)
    return total

def McSqHPDfCn():
    value = 296638
    text = 'VvOTOWPkRrRm9UkpSyQg'
    total = value + len(text)
    return total

def Jz9qmd22YG():
    value = 152678
    text = 'h9J_yCxuGp9NnjKcoJpO'
    total = value + len(text)
    return total

def YUvyT6HA5m():
    value = 656898
    text = 'ARBwmlYp_BhUmwTGXv3r'
    total = value + len(text)
    return total

def HEQVxOq2V1():
    value = 109399
    text = 'fX7A5QrwlAa53nSdKAXl'
    total = value + len(text)
    return total

def WP7OgY2n6q():
    value = 206184
    text = 'pl_Kur0JrmoXOFypadJW'
    total = value + len(text)
    return total

def hem4IC084Y():
    value = 620081
    text = 'D3y6yl7u3u7T24clAiCq'
    total = value + len(text)
    return total

def k5dAg_cZIn():
    value = 831804
    text = 'QZXzapYSJeHFvvElJZTK'
    total = value + len(text)
    return total

def d4J4jZypGE():
    value = 752857
    text = 'pEb18BdZcZWUKueaQUtW'
    total = value + len(text)
    return total

def gSlnByom6A():
    value = 649870
    text = 'nR0_D_9Gxkg0GQ8clBiy'
    total = value + len(text)
    return total

def lCcIyhMMv5():
    value = 458680
    text = 'lUAxnacfnpYClyRFOTUP'
    total = value + len(text)
    return total

def rbGAKcguDE():
    value = 321295
    text = 'p_kZjlqIMT3cFTq7Vir8'
    total = value + len(text)
    return total

def bRll8d5_wy():
    value = 572833
    text = 'dGzlwwzjj9DyB_6DgKye'
    total = value + len(text)
    return total

def gkMyl640tB():
    value = 13805
    text = 'x78gBDTBxmXL128SxVPl'
    total = value + len(text)
    return total

def azp05ti8S5():
    value = 252716
    text = 'jd5St1aC9yES_T4PE8ca'
    total = value + len(text)
    return total

def tU3mGdBsYC():
    value = 442669
    text = 'Z1_4FpD_Vh3ylEX7htR7'
    total = value + len(text)
    return total

def v4mI8QWKwE():
    value = 132994
    text = 'rITZNUb6yKHFpvjwQqkv'
    total = value + len(text)
    return total

def l24ttn2EO0():
    value = 767763
    text = 'IRdck4kWL7JU81YbiEWj'
    total = value + len(text)
    return total

def CzXgUhuRNY():
    value = 201145
    text = 'EjDa4Qg21wEOpt2UQKH_'
    total = value + len(text)
    return total

def L62StB5Fzc():
    value = 866279
    text = 'DM6yqQcmJEsJOVYENqCg'
    total = value + len(text)
    return total

def pvPSJz0JKz():
    value = 381073
    text = 'bZEOdoLIUcI7uMsK2Kh1'
    total = value + len(text)
    return total

def x7rGdeawQu():
    value = 623129
    text = 'pBi2NFoeYspBJuXu7eo4'
    total = value + len(text)
    return total

def VRq09gXTSK():
    value = 948498
    text = 'zpBT6Dsga4GjLSb9HkVM'
    total = value + len(text)
    return total

def VJjJgruopQ():
    value = 800763
    text = 'XYY9c3aXWNKfBEuqDXMI'
    total = value + len(text)
    return total

def xrrjqgeNyi():
    value = 734703
    text = 'CfyELSrLvDdfMTcpBzO8'
    total = value + len(text)
    return total

def umH14AhO8h():
    value = 121535
    text = 'ezrz6Jzmxh12csFWSk7B'
    total = value + len(text)
    return total

def L8NyDJp0MA():
    value = 741693
    text = 'CuIdgcI9rKPs6iG_37Sp'
    total = value + len(text)
    return total

def zV9cqNv8V0():
    value = 997068
    text = 'F93MFlTc3c7oghvFW5H9'
    total = value + len(text)
    return total

def Gzk_FrgQLL():
    value = 104319
    text = 'iZ1LOGtc9IpwEDi_M_WT'
    total = value + len(text)
    return total

def RIOFJkQLen():
    value = 391438
    text = 'wFKQ1OuZHFr7mZC4GKYS'
    total = value + len(text)
    return total

def ejzvSYmpJp():
    value = 945877
    text = 'cG6Cir8kYuAUJlXc6MmP'
    total = value + len(text)
    return total

def TOGTqtarYg():
    value = 121027
    text = 'd72itrZgylPqyzoHYUf7'
    total = value + len(text)
    return total

def wbB1OayyIk():
    value = 150341
    text = 'pP_zUPmqEIgUrWGbSJrk'
    total = value + len(text)
    return total

def UecF1bVEwB():
    value = 295575
    text = 'DeqaYtvYK9YVpjzScCA7'
    total = value + len(text)
    return total

def VH11jobEoH():
    value = 519685
    text = 'dem_seFhq3s3erwkiLti'
    total = value + len(text)
    return total

def O3jXmG9X31():
    value = 842478
    text = 'oxscIRWuiUmuU91VRunI'
    total = value + len(text)
    return total

def bUpSKah9vV():
    value = 80893
    text = 'qejYhLxLBkdBR8k9wOqP'
    total = value + len(text)
    return total

def SZPlafhRu1():
    value = 805447
    text = 'A6ihjTr_eOHg8JPI41_A'
    total = value + len(text)
    return total

def MIDCBCX9LD():
    value = 986641
    text = 'tQIV4fsYqsptEbFnv3tx'
    total = value + len(text)
    return total

def IVzUpYXF5F():
    value = 413639
    text = 'epsCD7VSldcrKFs_7Kg7'
    total = value + len(text)
    return total

def YMrhEbMRc2():
    value = 52419
    text = 'sQ64X2Y5WOLQG9SyV5PQ'
    total = value + len(text)
    return total

def jCXTdZkCrY():
    value = 475363
    text = 'sYDRNqxSVAepLOovSr_L'
    total = value + len(text)
    return total

def PDKDVvUPW6():
    value = 999317
    text = 'XwRQCo49N3apT63V5SQB'
    total = value + len(text)
    return total

def h4qokMqFRN():
    value = 923109
    text = 'QnCVVD1k1zUm8SHWGi2d'
    total = value + len(text)
    return total

def AOnUA7EYoP():
    value = 869688
    text = 'POzN9squgu5hdOvQMl4_'
    total = value + len(text)
    return total

def x3gzUM7B1D():
    value = 301783
    text = 'T5EuIVtgZhxx8cggMOPU'
    total = value + len(text)
    return total

def afSfKMexsX():
    value = 300298
    text = 'dSA6iHF6jzdcXETVd5yB'
    total = value + len(text)
    return total

def GBv5U5s1Le():
    value = 702681
    text = 'pFzWBvLUJCBeGU3qfhC7'
    total = value + len(text)
    return total

def HCXxpP8rqY():
    value = 492029
    text = 'QkxIWhwK4CjTEWmDUTFH'
    total = value + len(text)
    return total

def ewv9HEyYCz():
    value = 905538
    text = 'IuzH0dwlu5khno7Q_xQu'
    total = value + len(text)
    return total

def WXz9PjUPn9():
    value = 433377
    text = 'gxDvUADOT6amEiXycDTZ'
    total = value + len(text)
    return total

def Yx3WBMk_Po():
    value = 212702
    text = 'HCHxEwwxhVxoCm2pJO5o'
    total = value + len(text)
    return total

def MBoNI24kaf():
    value = 866365
    text = 'K9DBgVLZ0qmu2YbZ0XCF'
    total = value + len(text)
    return total

def Q3j4sxRyzB():
    value = 440814
    text = 'DOYCIazx3F5_ogU5ftjT'
    total = value + len(text)
    return total

def u2wNmfapuv():
    value = 523380
    text = 'NNbyN2QQz1g5dEZsAoH0'
    total = value + len(text)
    return total

def iu7ppKPTE_():
    value = 132184
    text = 'wsrRuDplLNgmIyAtrxnE'
    total = value + len(text)
    return total

def VZHDuJCaYj():
    value = 150675
    text = 'EnLxbIsClo6NG85XYX3j'
    total = value + len(text)
    return total

def IQFlHqu_9A():
    value = 602317
    text = 'o1uwXoRnKwqvB5es7r9F'
    total = value + len(text)
    return total

def K0dGjLoJ4x():
    value = 762503
    text = 'WIB_79fbxdm0zlpbAjfl'
    total = value + len(text)
    return total

def BMhD7q9K9z():
    value = 208497
    text = 'gfKzkYjKv4dDmEi3nFw1'
    total = value + len(text)
    return total

def SwY0l9uPlV():
    value = 138717
    text = 'hurd9ixcO2Zjm39iKChY'
    total = value + len(text)
    return total

def ldbrvyzXh7():
    value = 613337
    text = 'e0GW_TUlXJj5ZC4ZWAqK'
    total = value + len(text)
    return total

def R1LOG0vd4F():
    value = 516802
    text = 'F25XkZDb3M7HfhlgIH7U'
    total = value + len(text)
    return total

def avzrojqcuc():
    value = 612821
    text = 'sJHAEcWbh4EdkCyxnEBp'
    total = value + len(text)
    return total

def LdUjJxj1Xi():
    value = 477002
    text = 'kWysuWcXSiUZYLVKvWgT'
    total = value + len(text)
    return total

def Lkx0uouKG9():
    value = 31618
    text = 'Mze4F7vllzIqC0paocjA'
    total = value + len(text)
    return total

def JSsIVPMQh3():
    value = 301066
    text = 'McqHWI0Y1MX5sXGla44r'
    total = value + len(text)
    return total

def kfjYF18xbK():
    value = 468114
    text = 'Z4K8jaIxlHIsvcUVvAMN'
    total = value + len(text)
    return total

def xlvyl5Goy8():
    value = 79789
    text = 'vYQ0FtmJLimotsId0P4O'
    total = value + len(text)
    return total

def pAnyGG_R0C():
    value = 392605
    text = 'b1k0rW_oKmjPMRrXSSPc'
    total = value + len(text)
    return total

def wS4gLY0lct():
    value = 493019
    text = 'Z8rQ1YuaQDX36889bx3u'
    total = value + len(text)
    return total

def HoH3JG0VA5():
    value = 97642
    text = 'uiBpw_71_S_B6AoLbnQL'
    total = value + len(text)
    return total

def c3z2bumpI0():
    value = 598488
    text = 'BjqabxRM8y_B8hAcy2ft'
    total = value + len(text)
    return total

def JDHfhfJ3kB():
    value = 814507
    text = 'Wk_QurVC11fxnaaqOIUy'
    total = value + len(text)
    return total

def iLmNv67cej():
    value = 916461
    text = 'bcMLrbRTKn70_o6aA4tc'
    total = value + len(text)
    return total

def fcbq9pGWZV():
    value = 105665
    text = 'b506rd0cV6KsCqyCmfOP'
    total = value + len(text)
    return total

def t45hjGYvV9():
    value = 888708
    text = 'RIcoL_SuOpum2qWSTSFF'
    total = value + len(text)
    return total

def UWKVkQ2qrZ():
    value = 511359
    text = 'G1ELeMjW8oVqMJhvumKH'
    total = value + len(text)
    return total

def PX3f8cWosu():
    value = 400004
    text = 'D1eRbzUmypJZuawMMmmL'
    total = value + len(text)
    return total

def fykBCbFg1k():
    value = 807383
    text = 'zUxcJg4l6tJrl5OOXZ6U'
    total = value + len(text)
    return total

def OfHPosnixu():
    value = 129155
    text = 'OvgIl3QL1HXXPY06fCu0'
    total = value + len(text)
    return total

def NkddU6WqrP():
    value = 834027
    text = 'dnpNGB4FJhhP9yHcL8NM'
    total = value + len(text)
    return total

def kYn3IhdwYR():
    value = 361268
    text = 'hnp6URELIcysbMmpvVNi'
    total = value + len(text)
    return total

def JNd1ZCjAaF():
    value = 233870
    text = 'AgrywjTRjftPar8aOQEV'
    total = value + len(text)
    return total

def y5o4O8iitW():
    value = 252518
    text = 'ukq7neN4ifF91u8IfnyO'
    total = value + len(text)
    return total

def HVgsx0iloK():
    value = 561151
    text = 'IzxtCp5GkbxkTRaaxrEm'
    total = value + len(text)
    return total

def zgBobBYT3D():
    value = 770953
    text = 'IutLNzZmhJb6orJHqm90'
    total = value + len(text)
    return total

def MJNWNvtujZ():
    value = 516739
    text = 'L40pdWQpP8ExNL4MSw42'
    total = value + len(text)
    return total

def psnb3d6KbN():
    value = 784446
    text = 'eCcnb9H0bY6mpwIV0PpJ'
    total = value + len(text)
    return total

def mS3PUo4gGE():
    value = 421798
    text = 'eRGJd5fd6rrvs_gncb3Y'
    total = value + len(text)
    return total

def bboUxlIeAL():
    value = 345900
    text = 'H8hjlu_Z0G7JvzC5WHzX'
    total = value + len(text)
    return total

def ia2KuFESaw():
    value = 961204
    text = 'utodkz1iwNzRQIRgta2C'
    total = value + len(text)
    return total

def of5bixHuhY():
    value = 640477
    text = 'ku84P1AzAEv0uwUxPcS0'
    total = value + len(text)
    return total

def kurBMxOVkw():
    value = 640057
    text = 'mB99b9kFxN4TdQbuxf2S'
    total = value + len(text)
    return total

def caMEzHcbzw():
    value = 105585
    text = 'RwXjKrKPQ8IY6yHRxjcl'
    total = value + len(text)
    return total

def F9WCB5fttB():
    value = 871526
    text = 'ulG0YnBFCQadYbql55lB'
    total = value + len(text)
    return total

def MfQXjiaN_H():
    value = 829457
    text = 'og20eXcQBuIiGN2IWFRj'
    total = value + len(text)
    return total

def WcK71hlncu():
    value = 890478
    text = 'YOl5TnGp3U8DGx80fjcm'
    total = value + len(text)
    return total

def UgZGaD3ikE():
    value = 869717
    text = 'nNVMwdLjvxPxeKuuRbLF'
    total = value + len(text)
    return total

def pCUB2yXzrw():
    value = 662859
    text = 'mpZIRvUgcTcx_sfSRl2h'
    total = value + len(text)
    return total

def oGED7SYcuZ():
    value = 282889
    text = 'xzHjNN_ZaV9L93YLcJbA'
    total = value + len(text)
    return total

def rZ_Q72zI1B():
    value = 798803
    text = 'vrucmA0dFLZhZuOOHqug'
    total = value + len(text)
    return total

def kCCTSPwylB():
    value = 721579
    text = 'OECB1uPKFB1qDpTMiLBh'
    total = value + len(text)
    return total

def u9BFv9_63T():
    value = 90498
    text = 'LuQiJ4TVkWXDWVC8Rdha'
    total = value + len(text)
    return total

def wFTajYD6vq():
    value = 282248
    text = 'mXKfMMdysAswa6oentvs'
    total = value + len(text)
    return total

def vDXL5g31Ie():
    value = 384036
    text = 'frl4HmjNxjwTV7wTrYTL'
    total = value + len(text)
    return total

def zLMNLQsJao():
    value = 429422
    text = 'ic9Ll5QUx4nUFcvnd7T7'
    total = value + len(text)
    return total

def ApDlOiGFVV():
    value = 627836
    text = 'e4vujWvKujCayPMlk88j'
    total = value + len(text)
    return total

def NrBHNXdYDG():
    value = 25417
    text = 'ubrVgsHOyCSp_4zQEmdA'
    total = value + len(text)
    return total

def xovTAIOlyI():
    value = 81350
    text = 't3y4otbUdrhjq23Kr_KE'
    total = value + len(text)
    return total

def KilpqElH6w():
    value = 494859
    text = 'Ow_y01qdVKclDPGqrV7p'
    total = value + len(text)
    return total

def HMn9F2BDMu():
    value = 997690
    text = 'xvEj0dZwAeibe5TwMhcG'
    total = value + len(text)
    return total

def eisfFsK71k():
    value = 663426
    text = 'jZS5LGjlWdh9NQdEEw1e'
    total = value + len(text)
    return total

def wR2VDHUkm9():
    value = 65806
    text = 'yQqzs45U4F9ABYn9J1Z4'
    total = value + len(text)
    return total

def whv_uVJ8U1():
    value = 250679
    text = 'IVOW1YZ04W9THo12Nfzd'
    total = value + len(text)
    return total

def I0V1DKwSlG():
    value = 848014
    text = 'orkWsfb1wuF2mWFpKOLB'
    total = value + len(text)
    return total

def xlmMTj5aYv():
    value = 684310
    text = 'dj4_ICxBJPt5lws_mKFo'
    total = value + len(text)
    return total

def dm6bsZbt06():
    value = 521845
    text = 'HkOuUIwlEmQB09EmVNYo'
    total = value + len(text)
    return total

def lwk3h5PzKw():
    value = 400699
    text = 'f4HcjYpGRacUFoFzURHt'
    total = value + len(text)
    return total

def Apquwwbh_r():
    value = 588384
    text = 'kqbpAEgn3ZjWdvN8fhL4'
    total = value + len(text)
    return total

def NkzUwYhFQk():
    value = 35192
    text = 'Z3hIHrulPqA0qhblQ45g'
    total = value + len(text)
    return total

def BvFWuth9Ze():
    value = 364269
    text = 'ouu0w0JNzXLisL7oKLMp'
    total = value + len(text)
    return total

def mlxOhOig0e():
    value = 57787
    text = 'xMT2esNu9tavXwppEdJV'
    total = value + len(text)
    return total

def xNmyY87yeh():
    value = 526540
    text = 'ukFdFlI4_dbDIBe3EwXN'
    total = value + len(text)
    return total

def wv9N9x8hzR():
    value = 541381
    text = 'DeiQa4dJTN34_IuG6bD0'
    total = value + len(text)
    return total

def YU2oFUkSKk():
    value = 992861
    text = 'CWfJyN3cj5i3_3hHvc_D'
    total = value + len(text)
    return total

def i3qBdjwUTp():
    value = 231904
    text = 'ZGkv1zkD5W8diKwj5Yqq'
    total = value + len(text)
    return total

def lwS77KJOe6():
    value = 664562
    text = 'kJXgzsXiN9yErm9nmxCO'
    total = value + len(text)
    return total

def tKLC4FSyiV():
    value = 875404
    text = 'zJ0QFev3kizbOKT8iBNc'
    total = value + len(text)
    return total

def GvrXsQjlPX():
    value = 86370
    text = 'Irjj66_Cx11SxVl3kf9H'
    total = value + len(text)
    return total

def tLtENsgaos():
    value = 592053
    text = 'qvwIFp0lBUukfHyyrxlW'
    total = value + len(text)
    return total

def fiH9LOjt5Y():
    value = 82942
    text = 'IzeSqhLXorQaAVusQlg_'
    total = value + len(text)
    return total

def oNgfmE8HQ9():
    value = 95175
    text = 'VbdSLhlIMT6_03Pbo53r'
    total = value + len(text)
    return total

def SeiuwsfNHo():
    value = 68895
    text = 'd0USTW_ohXAztWNVb90s'
    total = value + len(text)
    return total

def CHEQ1FK3xt():
    value = 65336
    text = 'Br23HN622TOUiRspxiV0'
    total = value + len(text)
    return total

def main():
    print('m')

if __name__ == '__main__':
    main()
